[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [string]$GameDirectory,
    [string]$WorldDirectory
)
$ErrorActionPreference = 'Stop'
$gamePath = (Resolve-Path -LiteralPath $GameDirectory).Path
if (-not (Test-Path -LiteralPath (Join-Path $gamePath 'options.txt') -PathType Leaf)) {
    throw 'Choose the Horizon instance GAME folder containing options.txt. Launch the prepared instance once first.'
}
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss-fff'
foreach ($entry in @(
    @{ Source='ashen_frontier-0.7.0.hmod'; Folder='horizon-mods'; Destination='ashen_frontier.hmod' },
    @{ Source='ashen_frontier_gameplay-0.7.0.hnmod'; Folder='horizon-native-mods'; Destination='ashen_frontier_gameplay.hnmod' }
)) {
    $sourcePath = Join-Path (Join-Path $PSScriptRoot 'mods') $entry.Source
    $destinationFolder = Join-Path $gamePath $entry.Folder
    New-Item -ItemType Directory -Path $destinationFolder -Force | Out-Null
    $destinationPath = Join-Path $destinationFolder $entry.Destination
    if (Test-Path -LiteralPath $destinationPath) {
        Copy-Item -LiteralPath $destinationPath -Destination ($destinationPath + '.backup-' + $stamp)
    }
    Copy-Item -LiteralPath $sourcePath -Destination $destinationPath
}
$switchPath = Join-Path $gamePath 'horizon-mods.txt'
$lines = @()
if (Test-Path -LiteralPath $switchPath) {
    Copy-Item -LiteralPath $switchPath -Destination ($switchPath + '.backup-' + $stamp)
    $lines = @(Get-Content -LiteralPath $switchPath | Where-Object {
        $_ -notmatch '^mod\.(ashen_frontier|ashen_frontier_gameplay):'
    })
}
$lines += 'mod.ashen_frontier:true', 'mod.ashen_frontier_gameplay:true'
[System.IO.File]::WriteAllLines($switchPath, [string[]]$lines, [System.Text.UTF8Encoding]::new($false))
Write-Output "Copied both mods into: $gamePath"
Write-Output 'Next: build this instance native mods in the Horizon launcher, then create a new test world. Read START-HERE.txt.'
if($WorldDirectory){& (Join-Path $PSScriptRoot 'Install-Biomes.ps1') -WorldDirectory $WorldDirectory}

