[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$WorldDirectory)
$ErrorActionPreference='Stop'
$worldPath=(Resolve-Path -LiteralPath $WorldDirectory).Path
if (-not (Test-Path -LiteralPath (Join-Path $worldPath 'level.dat') -PathType Leaf)) {
    throw 'Choose the closed Horizon world folder containing level.dat. For a new world, select the datapack in the world creation screen instead.'
}
$packFolder=Join-Path $worldPath 'datapacks'
New-Item -ItemType Directory -Path $packFolder -Force | Out-Null
$destination=Join-Path $packFolder 'imperium-biomes.zip'
$stamp=Get-Date -Format 'yyyyMMdd-HHmmss-fff'
if(Test-Path -LiteralPath $destination){Copy-Item -LiteralPath $destination -Destination ($destination+'.backup-'+$stamp)}
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'datapacks/imperium-biomes-0.7.0.zip') -Destination $destination
$settingsPath=Join-Path $worldPath 'datapacks.json'
if(Test-Path -LiteralPath $settingsPath){
    $settings=Get-Content -LiteralPath $settingsPath -Raw | ConvertFrom-Json
    Copy-Item -LiteralPath $settingsPath -Destination ($settingsPath+'.backup-'+$stamp)
    $enabled=@($settings.enabled | Where-Object { $_ -ne 'file/imperium-biomes.zip' }) + @('file/imperium-biomes.zip')
    $disabled=@($settings.disabled | Where-Object { $_ -ne 'file/imperium-biomes.zip' })
    $settings | Add-Member -NotePropertyName enabled -NotePropertyValue $enabled -Force
    $settings | Add-Member -NotePropertyName disabled -NotePropertyValue $disabled -Force
    [System.IO.File]::WriteAllText($settingsPath,($settings | ConvertTo-Json -Depth 20),[System.Text.UTF8Encoding]::new($false))
}
Write-Output "Installed Imperium's biome datapack into: $worldPath"
Write-Output 'Open the world with both Imperium mods enabled. New chunks use the province layout; existing chunks retain their terrain.'
