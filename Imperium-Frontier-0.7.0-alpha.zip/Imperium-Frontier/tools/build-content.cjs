const fs = require('fs'), path = require('path'), zlib = require('zlib');
const root = path.resolve(process.argv[2] || (path.basename(__dirname)==='tools'?path.join(__dirname,'..'):'outputs/Ashen-Frontier')), dir = path.join(root,'content');
const ns='ashen_frontier';
function write(p,v){p=path.join(dir,p);fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,typeof v==='object'&&!Buffer.isBuffer(v)?JSON.stringify(v,null,2)+'\n':v);}
function crc(b){let c=0xffffffff;for(const x of b){c^=x;for(let k=0;k<8;k++)c=(c>>>1)^((c&1)?0xedb88320:0);}return(c^0xffffffff)>>>0;}
function png(w,h,fn){let raw=Buffer.alloc((w*4+1)*h);for(let y=0;y<h;y++)for(let x=0;x<w;x++){let p=y*(w*4+1)+1+x*4;raw.set(fn(x,y),p);}function chunk(t,d){let b=Buffer.concat([Buffer.from(t),d]),n=Buffer.alloc(4),c=Buffer.alloc(4);n.writeUInt32BE(d.length);c.writeUInt32BE(crc(b));return Buffer.concat([n,b,c]);}let ih=Buffer.alloc(13);ih.writeUInt32BE(w);ih.writeUInt32BE(h,4);ih[8]=8;ih[9]=6;return Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]),chunk('IHDR',ih),chunk('IDAT',zlib.deflateSync(raw)),chunk('IEND',Buffer.alloc(0))]);}
let seed=7263;function rand(){seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;}
const lang={},blocks=[],items=[];const id=n=>`${ns}:${n}`, title=n=>n.split('_').map(s=>s[0].toUpperCase()+s.slice(1)).join(' ');
write('horizon-mod.toml',`id = "${ns}"\nname = "Ashen Frontier: Content"\nversion = "0.1.0"\ndescription = "Relic crafting, ruined frontiers, furniture and expedition gear. Requires Ashen Frontier gameplay for world generation and RPG features."\nauthors = ["Ashen Frontier contributors"]\napi = "0.2"\nside = "both"\ncapabilities = ["registries"]\n`);
function texture(n,color,kind='stone',item=false){write(`assets/${ns}/textures/${item?'item':'block'}/${n}.png`,png(16,16,(x,y)=>{let d=Math.floor(rand()*20)-10,c=color.map(v=>Math.max(0,Math.min(255,v+d)));if(kind==='brick'&&(y%5===0||(x+(Math.floor(y/5)%2)*8)%8===0))c=c.map(v=>v*.5);if(kind==='wood'&&(x%4===0||y===0))c=c.map(v=>v*.7);if(kind==='ore'&&((x*7+y*11)%19<4))c=[235,139,67];if(item){let visible=n.includes('sword')?Math.abs(x+y-15)<2||(x>9&&y>9&&Math.abs(x-y)<2):n.includes('pickaxe')?(y<5&&x>2&&x<14)||(Math.abs(x-8)<2&&y<15):n.includes('ingot')?(y>5&&y<12&&x>1&&x<15):n.includes('helmet')?(y>3&&y<12&&x>2&&x<13&&(y<7||x<5||x>10)):n.includes('chestplate')?(y>2&&y<14&&x>2&&x<13):n.includes('leggings')?(y>2&&y<14&&x>3&&x<12&&(y<7||x<6||x>9)):n.includes('boots')?(y>7&&y<14&&(x<7||x>9)&&x>1&&x<15):Math.abs(x-7.5)+Math.abs(y-7.5)<7;if(!visible)return[0,0,0,0];}return[...c.map(Math.round),255];}));}
function shapeless(n,ingredients,count=1){write(`data/${ns}/recipe/${n}.json`,{type:'minecraft:crafting_shapeless',category:'misc',ingredients:ingredients.map(x=>x.includes(':')?x:id(x)),result:{id:id(n),count}});}
function shaped(n,pattern,key,count=1){write(`data/${ns}/recipe/${n}.json`,{type:'minecraft:crafting_shaped',category:'misc',pattern,key:Object.fromEntries(Object.entries(key).map(([k,v])=>[k,v.includes(':')?v:id(v)])),result:{id:id(n),count}});}
function loot(n,entries,rolls=1){write(`data/${ns}/loot_table/${n}.json`,{type:n.startsWith('blocks/')?'minecraft:block':'minecraft:entity',pools:[{rolls,entries:entries.map(([name,min,max,weight=1])=>({type:'minecraft:item',name:name.includes(':')?name:id(name),weight,functions:[{function:'minecraft:set_count',count:min===max?min:{type:'minecraft:uniform',min,max}}]}))}]});}
function block(n,template,color,kind='stone',properties={},model){blocks.push(n);write(`data/${ns}/horizon/block/${n}.json`,{template:`minecraft:${template}`,properties,...(model?{shapes:{default:model.elements.map(e=>[...e.from,...e.to].map(v=>v/16))},collision_shapes:{default:model.elements.map(e=>[...e.from,...e.to].map(v=>v/16))}}:{})});texture(n,color,kind);write(`assets/${ns}/blockstates/${n}.json`,{variants:{'':{model:`${ns}:block/${n}`}}});write(`assets/${ns}/models/block/${n}.json`,model||{parent:'minecraft:block/cube_all',textures:{all:`${ns}:block/${n}`}});write(`assets/${ns}/items/${n}.json`,{model:{type:'minecraft:model',model:`${ns}:block/${n}`}});lang[`block.${ns}.${n}`]=title(n);loot(`blocks/${n}`,[[n,1,1]]);}
function furniture(n,boxes,color){const faces=Object.fromEntries(['down','up','north','south','west','east'].map(d=>[d,{texture:'#all'}]));block(n,'stone',color,'wood',{hardness:1.5,requires_tool:false,occludes:false},{textures:{all:`${ns}:block/${n}`,particle:`${ns}:block/${n}`},elements:boxes.map(([from,to])=>({from,to,faces}))});}
for(const [n,t,c,k]of[
 ['ashen_bricks','stone_bricks',[91,88,86],'brick'],['mossy_ashen_bricks','stone_bricks',[78,96,74],'brick'],['cracked_ashen_bricks','stone_bricks',[67,67,66],'brick'],['carved_ashen_stone','chiseled_stone_bricks',[115,105,88],'brick'],['relic_tiles','polished_deepslate',[56,71,76],'brick'],['sunstone_tiles','quartz_block',[209,168,94],'brick'],['cinderwood_planks','oak_planks',[115,66,43],'wood'],['cinderwood_beam','oak_log',[77,47,34],'wood'],['woven_thatch','hay_block',[172,145,81],'wood'],['weathered_copper_panel','copper_block',[64,126,111],'brick'],['ember_ore','iron_ore',[83,76,73],'ore'],['deep_ember_ore','deepslate_iron_ore',[47,48,54],'ore'],['ember_block','iron_block',[196,100,48],'brick'],['relic_crystal_block','amethyst_block',[68,158,175],'stone']])block(n,t,c,k,{hardness:n.includes('ore')?4:2.5,requires_tool:true});
block('ember_lamp','glowstone',[240,156,69],'brick',{hardness:1,light:14});
block('relic_beacon','sea_lantern',[74,195,213],'brick',{hardness:2,light:12});
block('trail_marker','stone',[175,141,71],'brick',{hardness:1.5});
block('ruin_cache','stone',[115,90,57],'wood',{hardness:1,requires_tool:false});
block('crypt_cache','stone',[71,91,109],'brick',{hardness:2,requires_tool:true});
furniture('cinderwood_table',[[[0,12,0],[16,15,16]],[[1,0,1],[4,12,4]],[[12,0,1],[15,12,4]],[[1,0,12],[4,12,15]],[[12,0,12],[15,12,15]]],[122,75,45]);
furniture('cinderwood_chair',[[[2,6,2],[14,9,14]],[[2,0,2],[4,6,4]],[[12,0,2],[14,6,4]],[[2,0,12],[4,15,14]],[[12,0,12],[14,15,14]],[[2,12,12],[14,15,14]]],[108,62,37]);
furniture('relic_shelf',[[[0,0,0],[16,2,16]],[[0,7,0],[16,9,16]],[[0,14,0],[16,16,16]],[[0,0,0],[2,16,16]],[[14,0,0],[16,16,16]],[[2,0,14],[14,16,16]]],[85,65,47]);
furniture('expedition_crate',[[[1,0,1],[15,14,15]],[[0,0,0],[16,2,16]],[[0,12,0],[16,14,16]]],[125,94,54]);
furniture('stone_bench',[[[0,7,1],[16,10,15]],[[2,0,3],[5,7,13]],[[11,0,3],[14,7,13]]],[104,106,103]);
furniture('display_pedestal',[[[1,0,1],[15,3,15]],[[4,3,4],[12,13,12]],[[0,13,0],[16,16,16]]],[103,130,135]);
function item(n,template,c,rarity='common',components={}){items.push(n);write(`data/${ns}/horizon/item/${n}.json`,{template:`minecraft:${template}`,rarity,components});texture(n,c,'stone',true);write(`assets/${ns}/models/item/${n}.json`,{parent:template.includes('sword')||template.includes('pickaxe')?'minecraft:item/handheld':'minecraft:item/generated',textures:{layer0:`${ns}:item/${n}`}});write(`assets/${ns}/items/${n}.json`,{model:{type:'minecraft:model',model:`${ns}:item/${n}`}});lang[`item.${ns}.${n}`]=title(n);}
for(const [n,t,c,r]of[['raw_ember','raw_iron',[187,98,55]],['ember_ingot','iron_ingot',[238,141,70],'uncommon'],['tempered_ember','iron_ingot',[247,184,85],'rare'],['relic_fragment','flint',[72,168,184],'uncommon'],['relic_core','diamond',[83,225,225],'rare'],['ancient_thread','string',[172,139,95]],['expedition_ration','cooked_beef',[159,91,54]],['hearty_stew','rabbit_stew',[200,132,60]],['warding_charm','amethyst_shard',[99,213,170],'rare'],['storm_focus','amethyst_shard',[105,165,244],'rare'],['grave_sigil','echo_shard',[150,108,207],'rare'],['cinder_sigil','echo_shard',[235,116,51],'epic'],['warden_seal','nether_star',[127,222,217],'epic'],['sovereign_seal','nether_star',[247,177,75],'epic']])item(n,t,c,r);
for(const [tier,t,color]of[['ember','iron',[225,128,59]],['relic','diamond',[71,203,212]]]){
 item(`${tier}_sword`,`${t}_sword`,color,'rare');item(`${tier}_pickaxe`,`${t}_pickaxe`,color,'uncommon');
 for(const piece of['helmet','chestplate','leggings','boots'])item(`${tier}_${piece}`,`${t}_${piece}`,color,'rare');
 const mat=tier==='ember'?'ember_ingot':'relic_core';
 shaped(`${tier}_sword`,[' M ',' M ',' S '],{M:mat,S:'minecraft:stick'});shaped(`${tier}_pickaxe`,['MMM',' S ',' S '],{M:mat,S:'minecraft:stick'});
 shaped(`${tier}_helmet`,['MMM','M M'],{M:mat});shaped(`${tier}_chestplate`,['M M','MMM','MMM'],{M:mat});shaped(`${tier}_leggings`,['MMM','M M','M M'],{M:mat});shaped(`${tier}_boots`,['M M','M M'],{M:mat});
}
for(const [n,hp,speed,atk]of[['ashbound',30,.25,4],['crypt_warden',120,.23,8],['cinder_sovereign',200,.27,10]]){write(`data/${ns}/horizon/entity_type/${n}.json`,{template:'minecraft:zombie',attributes:{'minecraft:max_health':hp,'minecraft:movement_speed':speed,'minecraft:attack_damage':atk,'minecraft:follow_range':32}});lang[`entity.${ns}.${n}`]=title(n);}
loot('blocks/ember_ore',[['raw_ember',1,2]]);loot('blocks/deep_ember_ore',[['raw_ember',1,3]]);
loot('blocks/ruin_cache',[['relic_fragment',1,3,5],['ancient_thread',2,5,5],['expedition_ration',1,3,4],['minecraft:iron_ingot',1,3,3],['grave_sigil',1,1,1]],3);
loot('blocks/crypt_cache',[['relic_fragment',2,5,5],['tempered_ember',1,2,3],['relic_core',1,1,1],['grave_sigil',1,1,2],['expedition_ration',2,4,4]],4);
loot('entities/ashbound',[['relic_fragment',1,2]]);loot('entities/crypt_warden',[['warden_seal',1,1]]);loot('entities/cinder_sovereign',[['sovereign_seal',1,1]]);
for(const n of['ashen_bricks','mossy_ashen_bricks','cracked_ashen_bricks','carved_ashen_stone','relic_tiles','sunstone_tiles','cinderwood_planks','cinderwood_beam','woven_thatch','weathered_copper_panel','ember_lamp','relic_beacon','trail_marker']){
 const inputs={ashen_bricks:['minecraft:stone','minecraft:charcoal'],mossy_ashen_bricks:['ashen_bricks','minecraft:vine'],cracked_ashen_bricks:['ashen_bricks','minecraft:flint'],carved_ashen_stone:['ashen_bricks','minecraft:quartz'],relic_tiles:['minecraft:deepslate','relic_fragment'],sunstone_tiles:['minecraft:sandstone','minecraft:gold_nugget'],cinderwood_planks:['minecraft:oak_planks','minecraft:charcoal'],cinderwood_beam:['minecraft:oak_log','minecraft:charcoal'],woven_thatch:['minecraft:wheat','minecraft:string'],weathered_copper_panel:['minecraft:copper_ingot','minecraft:green_dye'],ember_lamp:['ember_ingot','minecraft:glowstone_dust'],relic_beacon:['relic_fragment','minecraft:sea_lantern'],trail_marker:['ashen_bricks','minecraft:yellow_dye']}[n];shapeless(n,inputs,n.includes('lamp')||n.includes('beacon')?1:4);}
shaped('cinderwood_table',['PPP',' S ','S S'],{P:'cinderwood_planks',S:'minecraft:stick'});
shaped('cinderwood_chair',['P  ','PPP','S S'],{P:'cinderwood_planks',S:'minecraft:stick'});
shaped('relic_shelf',['PPP','S S','PPP'],{P:'cinderwood_planks',S:'minecraft:stick'});
shaped('expedition_crate',['PPP','P P','PPP'],{P:'cinderwood_planks'});
shaped('stone_bench',['AAA','S S'],{A:'ashen_bricks',S:'minecraft:stone'});shaped('display_pedestal',['AAA',' R ','AAA'],{A:'ashen_bricks',R:'relic_fragment'});
shapeless('tempered_ember',['ember_ingot','ember_ingot','minecraft:blaze_powder']);
shaped('relic_core',['FFF','FTF','FFF'],{F:'relic_fragment',T:'tempered_ember'});
shapeless('expedition_ration',['minecraft:cooked_beef','minecraft:bread','minecraft:dried_kelp'],3);
shapeless('hearty_stew',['minecraft:bowl','expedition_ration','minecraft:carrot']);
shaped('warding_charm',[' T ','FRF',' T '],{T:'ancient_thread',F:'relic_fragment',R:'relic_core'});
shaped('storm_focus',[' F ','TRT',' F '],{T:'tempered_ember',F:'relic_fragment',R:'relic_core'});
shaped('grave_sigil',['FFF','FEF','FFF'],{F:'relic_fragment',E:'ember_ingot'});
shaped('cinder_sigil',['ETE','TWT','ETE'],{E:'tempered_ember',T:'minecraft:blaze_powder',W:'warden_seal'});
shaped('ember_block',['III','III','III'],{I:'ember_ingot'});shapeless('ember_ingot',['ember_block'],9);
shaped('relic_crystal_block',['RR','RR'],{R:'relic_fragment'});shapeless('relic_fragment',['relic_crystal_block'],4);
for(const t of['smelting','blasting'])write(`data/${ns}/recipe/ember_ingot_${t}.json`,{type:`minecraft:${t}`,category:'misc',ingredient:id('raw_ember'),result:{id:id('ember_ingot')},experience:.8,cookingtime:t==='smelting'?200:100});
write('data/minecraft/tags/block/mineable/pickaxe.json',{replace:false,values:blocks.filter(n=>!n.startsWith('cinderwood')&&!['woven_thatch','expedition_crate','relic_shelf'].includes(n)).map(id)});
write('data/minecraft/tags/block/mineable/axe.json',{replace:false,values:blocks.filter(n=>n.startsWith('cinderwood')||['woven_thatch','expedition_crate','relic_shelf'].includes(n)).map(id)});
write('data/minecraft/tags/block/needs_iron_tool.json',{replace:false,values:['ember_ore','deep_ember_ore'].map(id)});
write(`assets/${ns}/lang/en_us.json`,lang);
write(`data/${ns}/horizon/creative_tab/frontier.json`,{title:'Ashen Frontier',icon:id('relic_core'),items:[...blocks,...items].map(id)});
fs.mkdirSync(path.join(root,'tools'),{recursive:true});const copiedScript=path.join(root,'tools/build-content.cjs');if(path.resolve(__filename)!==copiedScript)fs.copyFileSync(__filename,copiedScript);
fs.writeFileSync(path.join(root,'content-inventory.json'),JSON.stringify({namespace:ns,blocks,items,enemies:['ashbound','crypt_warden','cinder_sovereign']},null,2));
let guide=['ASHEN FRONTIER — RECIPE REFERENCE','Shaped recipes use the crafting grid as drawn. Blank spaces are empty slots.','IDs beginning minecraft: refer to vanilla ingredients.',''];
for(const file of fs.readdirSync(path.join(dir,`data/${ns}/recipe`)).sort()){
 const r=JSON.parse(fs.readFileSync(path.join(dir,`data/${ns}/recipe`,file)));guide.push(`${title(file.replace('.json',''))} -> ${r.result.id} x${r.result.count||1}`);
 if(r.pattern){guide.push(...r.pattern.map(p=>'  |'+p.padEnd(3)+'|'),...Object.entries(r.key).map(([k,v])=>`  ${k} = ${v}`));}
 else if(r.ingredients)guide.push('  Combine: '+r.ingredients.join(' + '));else guide.push('  '+r.type+': '+r.ingredient);guide.push('');
}fs.writeFileSync(path.join(root,'RECIPES.txt'),guide.join('\n'));
console.log(`Generated ${blocks.length} blocks, ${items.length} items, 3 entity types in ${dir}`);

