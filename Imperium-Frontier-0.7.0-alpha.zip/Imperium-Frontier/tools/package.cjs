const fs=require('fs'),path=require('path'),zlib=require('zlib'),crypto=require('crypto');
const root=path.resolve(__dirname,'..');
function crc(b){let c=0xffffffff;for(const x of b){c^=x;for(let k=0;k<8;k++)c=(c>>>1)^((c&1)?0xedb88320:0);}return(c^0xffffffff)>>>0;}
function zip(entries,out){let chunks=[],central=[],offset=0;for(const[name,data]of entries.sort((a,b)=>a[0].localeCompare(b[0]))){let n=Buffer.from(name),d=Buffer.isBuffer(data)?data:Buffer.from(data),compressed=zlib.deflateRawSync(d),checksum=crc(d),h=Buffer.alloc(30);h.writeUInt32LE(0x04034b50);h.writeUInt16LE(20,4);h.writeUInt16LE(8,8);h.writeUInt16LE(33,12);h.writeUInt32LE(checksum,14);h.writeUInt32LE(compressed.length,18);h.writeUInt32LE(d.length,22);h.writeUInt16LE(n.length,26);chunks.push(h,n,compressed);let c=Buffer.alloc(46);c.writeUInt32LE(0x02014b50);c.writeUInt16LE(20,4);c.writeUInt16LE(20,6);c.writeUInt16LE(8,10);c.writeUInt16LE(33,14);c.writeUInt32LE(checksum,16);c.writeUInt32LE(compressed.length,20);c.writeUInt32LE(d.length,24);c.writeUInt16LE(n.length,28);c.writeUInt32LE(offset,42);central.push(c,n);offset+=h.length+n.length+compressed.length;}let cd=Buffer.concat(central),end=Buffer.alloc(22);end.writeUInt32LE(0x06054b50);end.writeUInt16LE(entries.length,8);end.writeUInt16LE(entries.length,10);end.writeUInt32LE(cd.length,12);end.writeUInt32LE(offset,16);fs.mkdirSync(path.dirname(out),{recursive:true});fs.writeFileSync(out,Buffer.concat([...chunks,cd,end]));}
function walk(dir,prefix=''){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>{let p=path.join(dir,e.name),rel=prefix+e.name;return e.isDirectory()?(e.name==='target'?[]:walk(p,rel+'/')):[[rel,fs.readFileSync(p)]];});}
const rev='69fab597a6f0e8a6ce524d38d1b73e599e343034';
const manifest={schema:1,id:'ashen_frontier_gameplay',version:'0.7.0',game:'26.3',horizon:rev,mixins:'e8cd0aa38cffef49cb2e088ef716baa107148c02'};
fs.mkdirSync(path.join(root,'mods'),{recursive:true});
zip([['horizon-native.json',JSON.stringify(manifest,null,2)],...walk(path.join(root,'native')).map(([n,b])=>['mixins/ashen_frontier_gameplay/'+n,b]),['mixins/ashen_frontier_gameplay/LICENSE',fs.readFileSync(path.join(root,'LICENSE.txt'))]],path.join(root,'mods/ashen_frontier_gameplay-0.7.0.hnmod'));
fs.copyFileSync(path.join(root,'content/target/horizon-mod/ashen_frontier.hmod'),path.join(root,'mods/ashen_frontier-0.7.0.hmod'));
zip(walk(path.join(root,'biome-datapack')),path.join(root,'datapacks/imperium-biomes-0.7.0.zip'));
const hashes=['mods','datapacks'].flatMap(folder=>fs.readdirSync(path.join(root,folder)).sort().map(n=>crypto.createHash('sha256').update(fs.readFileSync(path.join(root,folder,n))).digest('hex')+'  '+folder+'/'+n)).join('\n')+'\n';fs.writeFileSync(path.join(root,'SHA256SUMS.txt'),hashes);
if(process.argv.includes('--release'))zip(walk(root).map(([n,b])=>['Imperium-Frontier/'+n,b]),path.join(root,'..','Imperium-Frontier-0.7.0-alpha.zip'));
console.log(hashes);

