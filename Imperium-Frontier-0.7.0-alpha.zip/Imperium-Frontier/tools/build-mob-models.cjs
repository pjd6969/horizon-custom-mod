// Original articulated mob geometry, Roman outfits, textures and a review scene.
// Geometry is independent of Mojang's models. Vanilla templates supply server AI only.
const fs=require('fs'),path=require('path'),zlib=require('zlib'),cp=require('child_process');
const root=path.resolve(__dirname,'..'),content=path.join(root,'content'),ns='ashen_frontier';
cp.execFileSync(process.execPath,[path.join(__dirname,'build-settlements.cjs')],{stdio:'inherit'});
function write(p,v){p=path.join(root,p);fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,Buffer.isBuffer(v)?v:typeof v==='string'?v:JSON.stringify(v,null,2)+'\n');}
function crc(b){let c=0xffffffff;for(const x of b){c^=x;for(let k=0;k<8;k++)c=c>>>1^((c&1)?0xedb88320:0);}return(c^0xffffffff)>>>0;}
function png(fn){const raw=Buffer.alloc(16*65);for(let y=0;y<16;y++)for(let x=0;x<16;x++)raw.set([...fn(x,y),255],y*65+x*4+1);const chunk=(n,b)=>{const h=Buffer.alloc(4),c=Buffer.alloc(4);h.writeUInt32BE(b.length);c.writeUInt32BE(crc(Buffer.concat([Buffer.from(n),b])));return Buffer.concat([h,Buffer.from(n),b,c]);};const h=Buffer.alloc(13);h.writeUInt32BE(16);h.writeUInt32BE(16,4);h[8]=8;h[9]=6;return Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]),chunk('IHDR',h),chunk('IDAT',zlib.deflateSync(raw)),chunk('IEND',Buffer.alloc(0))]);}
const colors={skin:[185,133,97],dark_skin:[125,81,57],pale_skin:[209,169,131],undead:[112,127,103],bone:[196,190,158],linen:[224,213,181],red:[151,38,37],purple:[95,48,101],ochre:[186,130,50],teal:[50,99,101],leather:[105,66,40],dark:[47,44,41],hair:[63,42,30],grey_hair:[157,150,132],steel:[168,177,177],bronze:[170,126,59],gold:[218,175,64],silver:[201,208,201],leaf:[78,119,54],eye:[34,29,24],ember:[233,106,34]};
for(const[n,c]of Object.entries(colors))write(`content/assets/${ns}/textures/mob/${n}.png`,png((x,y)=>{let d=((x*7+y*11+x*y)%7)-3;if(['steel','bronze','gold','silver'].includes(n))d+=y%4===0?-20:3;if(['red','purple','linen','teal','ochre'].includes(n))d+=x%4===0?-7:1;return c.map(v=>Math.max(0,Math.min(255,v+d)));}));
const roles=[
 {id:'citizen',title:'Roman Citizen',skin:'skin',cloth:'linen',hair:'hair',style:'toga',width:3.6},
 {id:'prefect',title:'Roman Prefect',skin:'pale_skin',cloth:'linen',hair:'grey_hair',style:'prefect',width:4.0},
 {id:'quartermaster',title:'Legion Quartermaster',skin:'dark_skin',cloth:'teal',hair:'hair',style:'supply',width:4.4},
 {id:'merchant',title:'Roman Merchant',skin:'skin',cloth:'ochre',hair:'hair',style:'merchant',width:4.1},
 {id:'legionary_guard',title:'Legionary Guard',skin:'skin',cloth:'red',hair:'hair',style:'legion',width:4.2},
 {id:'bandit',title:'Road Bandit',skin:'dark_skin',cloth:'leather',hair:'hair',style:'bandit',width:3.7},
 {id:'raider',title:'Raider Captain',skin:'skin',cloth:'dark',hair:'hair',style:'raider',width:4.8},
 {id:'cultist',title:'Ash Cultist',skin:'pale_skin',cloth:'purple',hair:'dark',style:'cultist',width:3.6},
 {id:'ashbound',title:'Restless Legionary',skin:'undead',cloth:'dark',hair:'dark',style:'undead',width:3.6},
 {id:'crypt_warden',title:'Fallen Centurion',skin:'undead',cloth:'red',hair:'grey_hair',style:'centurion',width:4.7},
 {id:'cinder_sovereign',title:'Usurper Emperor',skin:'undead',cloth:'purple',hair:'dark',style:'emperor',width:5.0}
];
if(process.env.IMPERIUM_ODYSSEY==='1')roles.push(
 {id:'forge_tyrant',title:"Vulcan's Forge Tyrant",skin:'undead',cloth:'red',hair:'dark',style:'raider',width:5.0,swap:{bronze:'gold'}},
 {id:'styx_judge',title:'Praetor of Dis',skin:'pale_skin',cloth:'dark',hair:'grey_hair',style:'cultist',width:4.6,swap:{purple:'dark',gold:'silver'}},
 {id:'astral_legate',title:'Astral Legate',skin:'pale_skin',cloth:'teal',hair:'grey_hair',style:'emperor',width:4.8,swap:{gold:'silver',purple:'teal'}},
 {id:'sol_avatar',title:'Avatar of Sol Invictus',skin:'skin',cloth:'ochre',hair:'gold',style:'emperor',width:5.2,swap:{purple:'red',leaf:'gold'}});
const bones=['body','head','left_arm','right_arm','left_leg','right_leg'];
const pivots={body:[0,11.5,0],head:[0,22.2,0],left_arm:[5.1,21,0],right_arm:[-5.1,21,0],left_leg:[2.1,11.5,0],right_leg:[-2.1,11.5,0]};
const models=[];
for(const r of roles){
 const parts=Object.fromEntries(bones.map(b=>[b,[]]));let b='body';
 const box=(from,to,material)=>{if(!colors[material])throw Error(material);parts[b].push({from,to,material});};
 const w=r.width,armored=['legion','raider','undead','centurion','emperor'].includes(r.style),elite=['centurion','emperor'].includes(r.style),metal=r.style==='emperor'?'gold':r.style==='raider'?'bronze':'steel';
 box([-w,0,-2.2],[w,10,2.2],r.cloth);box([-w-.15,1.6,-2.4],[w+.15,2.7,2.4],'leather');box([-.7,1.6,2.4],[.7,2.8,2.7],'bronze');
 // Separate tunic flaps move with the legs; cuirass strips sit above them.
 if(armored){for(let y=3;y<10;y+=1.7)box([-w-.2,y,-2.5],[w+.2,y+1.35,2.5],metal);for(const x of[-w+.6,w-.6])box([x-.3,3,2.5],[x+.3,9,2.8],'bronze');}
 if(['toga','prefect'].includes(r.style)){box([-w-.3,-2,-2.5],[w+.3,1,2.5],'linen');for(let i=0;i<5;i++)box([-w+i*1.4,8-i*1.2,2.25],[-w+i*1.4+2.3,10-i*1.2,2.65],r.style==='prefect'?'purple':'linen');box([w-1,-2,2.5],[w,8,2.8],r.style==='prefect'?'purple':'ochre');}
 if(['supply','merchant','bandit'].includes(r.style)){box([w-.3,.5,-1.3],[w+2,4.5,1.5],'leather');for(let i=0;i<5;i++)box([-w+i*1.4,8-i*1.3,2.25],[-w+i*1.4+1.2,9.2-i*1.3,2.6],'leather');}
 if(['raider','centurion','emperor','prefect','cultist'].includes(r.style)){box([-w-.2,-1,-3],[w+.2,9.5,-2.4],r.style==='raider'?'red':r.style==='centurion'?'red':'purple');box([-w-.2,-1,-3.2],[w+.2,.1,-3],'gold');}
 if(r.style==='cultist'){box([-4,-4,-2.4],[4,1.3,2.4],'purple');box([-.35,-4,2.4],[.35,9.8,2.7],'gold');}
 if(r.style==='undead'){for(let y=4;y<9;y+=2)box([-w,y,2.55],[w-1,y+.6,2.85],'bone');}
 b='head';box([-3.1,0,-2.8],[3.1,6.2,2.8],r.skin);box([-3.2,4.8,-2.9],[3.2,6.5,2.9],r.hair);box([-3.25,2,-2.9],[-2.7,5.5,1],r.hair);box([2.7,2,-2.9],[3.25,5.5,1],r.hair);
 box([-2.1,2.9,2.8],[-1,3.6,3.05],r.style==='undead'||elite?'ember':'eye');box([1,2.9,2.8],[2.1,3.6,3.05],r.style==='undead'||elite?'ember':'eye');box([-.5,1.7,2.8],[.5,2.8,3.35],r.skin);box([-.9,.8,2.81],[.9,1.1,3],'hair');
 if(['supply','merchant','bandit'].includes(r.style))box([-2.5,-.2,2.7],[2.5,1.7,3.15],r.hair);
 if(['prefect','emperor'].includes(r.style)){for(const side of[-1,1])for(let z=-2;z<=2;z+=1.3)box([side<0?-3.5:3.1,4.3,z],[side<0?-3.1:3.5,5.2,z+1],'leaf');box([-.5,4.3,2.9],[.5,5.2,3.15],'gold');}
 if(armored){box([-3.6,5,-3.3],[3.6,7,3.3],metal);box([-3.8,4.5,2.7],[3.8,5.1,3.8],metal);for(const side of[-1,1])box([side<0?-3.6:2.8,.3,1.8],[side<0?-2.8:3.6,4.5,3.2],metal);box([-3.8,-.3,-3.3],[3.8,1.1,-2.7],metal);
  if(r.style==='centurion'||r.style==='raider')box([-5.3,7,-.7],[5.3,9,.7],'red');else if(r.style!=='undead'){box([-.7,7,-3.5],[.7,9,3.5],r.style==='emperor'?'purple':'red');}else box([-.6,7,-3],[.6,8,0],'dark');}
 if(r.style==='bandit'){box([-3.3,4.8,-3],[3.3,5.9,3.1],'red');box([-4.2,4.7,-1],[-3.3,6.2,1],'red');}
 if(r.style==='merchant'){box([-3.4,5.6,-3.1],[3.4,7,3.1],'teal');box([-2.6,7,-2.5],[2.6,7.5,2.5],'teal');}
 if(r.style==='cultist'){box([-3.6,-.3,-3.2],[-2.8,6.7,3.3],'purple');box([2.8,-.3,-3.2],[3.6,6.7,3.3],'purple');box([-3.6,6,-3.2],[3.6,7.4,3.3],'purple');box([-2.7,.3,2.8],[2.7,4.7,3.15],'gold');box([-2,3,3.15],[-.7,3.7,3.3],'dark');box([.7,3,3.15],[2,3.7,3.3],'dark');}
 for(const side of['left','right']){
  b=side+'_arm';box([-1.35,-9,-1.35],[1.35,0,1.35],r.skin);box([-1.5,-4,-1.5],[1.5,.2,1.5],r.cloth);
  if(armored){box([-1.9,-2,-2],[1.9,1,2],metal);box([-1.6,-7,-1.6],[1.6,-4,1.6],'leather');box([-1.65,-7,-1.65],[1.65,-6.5,1.65],'bronze');}
  if(r.style==='cultist')box([-1.8,-7.5,-1.8],[1.8,0,1.8],'purple');
  if(side==='right'&&armored||side==='right'&&r.style==='bandit'){box([-.45,-14,1.1],[.45,-7.5,1.8],'silver');box([-1.7,-7.8,.9],[1.7,-7.2,2],'bronze');box([-.5,-7.3,1],[.5,-5.2,1.9],'leather');}
  if(side==='left'&&armored){const small=r.style==='undead',lo=small?-8:-11,hi=small?-1:2;box([-3,lo,1.7],[3,hi,2.5],r.style==='raider'?'dark':r.cloth);box([-.3,lo,2.5],[.3,hi,2.7],'gold');box([-3,-4.4,2.5],[3,-3.8,2.7],'gold');box([-1,-5,2.6],[1,-3,3],'bronze');for(const x of[-3,2.7])box([x,lo,1.7],[x+.3,hi,2.7],'bronze');}
  if(side==='right'&&r.style==='cultist'){box([-.35,-16,.8],[.35,7,1.5],'leather');box([-.9,5,.2],[.9,7,2.1],'bronze');box([-.55,7,.4],[.55,9,1.9],'ember');}
  if(side==='left'&&r.style==='supply')box([-1.8,-8,1],[1.8,-3,3],'linen');
  if(side==='left'&&r.style==='merchant')box([-2,-8,1],[2,-5,4],'leather');
  b=side+'_leg';box([-1.45,-10,-1.45],[1.45,0,1.45],r.skin);box([-1.8,-3,-1.9],[1.8,.2,1.9],r.cloth);box([-1.7,-11.5,-1.8],[1.7,-10.4,2.4],'leather');for(const y of[-9.5,-7.8])box([-1.55,y,-1.55],[1.55,y+.45,1.6],'leather');
  if(armored){box([-1.6,-9.5,1.5],[1.6,-4.5,1.95],metal);for(const x of[-1.6,.5])box([x,-3.7,1.95],[x+.9,-.5,2.25],'leather');}
  if(r.style==='cultist')box([-1.9,-10.3,-2],[1.9,.2,2],'purple');
 }
 if(r.swap)for(const e of Object.values(parts).flat())e.material=r.swap[e.material]||e.material;
 for(const name of bones){const elements=parts[name].map(e=>({from:e.from,to:e.to,faces:Object.fromEntries(['north','south','east','west','up','down'].map(f=>[f,{texture:'#'+e.material,uv:[0,0,16,16],tintindex:0}]))}));const textures=Object.fromEntries([...new Set(parts[name].map(e=>e.material))].map(m=>[m,`${ns}:mob/${m}`]));write(`content/assets/${ns}/models/mob/${r.id}/${name}.json`,{ambientocclusion:false,textures,elements});}
 models.push({...r,pivots,parts});
}
if(process.env.IMPERIUM_ODYSSEY==='1')for(const [id,title,fur,width]of [['lupa_hound',"Lupa's Hound",'grey_hair',3],['mars_boar','Mars War Boar','leather',4.5],['diana_lynx',"Diana's Lynx",'ochre',3],['jupiter_eagle',"Jupiter's Eagle",'hair',2.5]]){
 const parts=Object.fromEntries(bones.map(b=>[b,[]]));const add=(b,from,to,material)=>parts[b].push({from,to,material});const eagle=id==='jupiter_eagle';const pivots=eagle?{body:[0,8,0],head:[0,12,3],left_arm:[2,11,0],right_arm:[-2,11,0],left_leg:[1.2,6,0],right_leg:[-1.2,6,0]}:{body:[0,6,0],head:[0,10,6],left_arm:[3,6,4],right_arm:[-3,6,4],left_leg:[3,6,-4],right_leg:[-3,6,-4]};
 add('body',[-width,0,-5],[width,5,5],fur);add('body',[-width-.2,2,-2],[width+.2,3,2],'red');add('body',[-.7,2,5],[.7,3,5.3],'gold');
 add('head',[-2.5,0,-2],[2.5,4,2.5],eagle?'linen':fur);add('head',[-1.8,1,2.5],[-.8,1.8,2.8],'eye');add('head',[.8,1,2.5],[1.8,1.8,2.8],'eye');add('head',[-1.4,-.5,2.5],[1.4,1,5],eagle?'gold':fur);
 if(!eagle){add('head',[-2.5,4,-1],[-1.2,6,1],'dark');add('head',[1.2,4,-1],[2.5,6,1],'dark');add('body',[-.6,3,-8],[.6,4,-5],fur);for(const b of ['left_arm','right_arm','left_leg','right_leg']){add(b,[-1,-6,-1],[1,0,1],fur);add(b,[-1.2,-6,-1.2],[1.2,-4.8,1.7],'dark');}if(id==='mars_boar'){add('head',[-2.4,-1,3],[-1.5,1.5,4],'bone');add('head',[1.5,-1,3],[2.4,1.5,4],'bone');add('body',[-width-.2,4,-2],[width+.2,5.5,2],'bronze');}}else{for(const[b,sign]of [['left_arm',1],['right_arm',-1]]){add(b,sign>0?[0,-.5,-4]:[-8,-.5,-4],sign>0?[8,.5,3]:[0,.5,3],fur);add(b,sign>0?[2,-.5,-6]:[-8,-.5,-6],sign>0?[8,.5,-4]:[-2,.5,-4],'linen');}for(const b of ['left_leg','right_leg'])add(b,[-.5,-3,-.5],[.5,0,2],'gold');add('body',[-2,0,-8],[2,1,-5],'linen');}
 for(const b of bones)write(`content/assets/${ns}/models/mob/${id}/${b}.json`,{ambientocclusion:false,textures:Object.fromEntries([...new Set(parts[b].map(e=>e.material))].map(m=>[m,ns+':mob/'+m])),elements:parts[b].map(e=>({from:e.from,to:e.to,faces:Object.fromEntries(['north','south','east','west','up','down'].map(f=>[f,{texture:'#'+e.material,uv:[0,0,16,16],tintindex:0}]))}))});
 models.push({id,title,style:eagle?'eagle':'quadruped',skin:fur,pivots,parts});
}
write('mob-model-inventory.json',{version:'0.5.0',models,colors});
// Generated Rust manifest makes model registration and per-mob lookup agree.
write('native/engine/src/mob_model_ids.rs','// Generated by tools/build-mob-models.cjs.\n'+
 'pub const MODEL_IDS: [[&str; 6]; '+models.length+'] = [\n'+models.map(r=>'    ['+bones.map(b=>JSON.stringify(`${ns}:mob/${r.id}/${b}`)).join(',')+'],').join('\n')+'\n];\n'+
 'pub const KINDS: [&str; '+models.length+'] = ['+models.map(r=>JSON.stringify(ns+':'+r.id)).join(',')+'];\n'+'pub const PIVOTS: [[[f32;3];6]; '+models.length+'] = ['+models.map(m=>'['+bones.map(b=>'['+m.pivots[b].map(v=>v.toFixed(3)).join(',')+']').join(',')+']').join(',')+'];\n');
const manifest=path.join(content,'horizon-mod.toml');fs.writeFileSync(manifest,fs.readFileSync(manifest,'utf8').replace(/version = "[^"]+"/,'version = "0.5.0"'));
console.log(`Generated ${models.length} original articulated mobs, ${models.length*6} model parts and ${Object.keys(colors).length} textures.`);

