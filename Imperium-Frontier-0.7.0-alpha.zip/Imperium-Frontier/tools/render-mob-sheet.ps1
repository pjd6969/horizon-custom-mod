$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Drawing
$packRoot=Split-Path $PSScriptRoot -Parent
$scene=Get-Content -LiteralPath (Join-Path $packRoot 'preview/mob-sheet-draw.json') -Raw | ConvertFrom-Json
$bitmap=[System.Drawing.Bitmap]::new([int]$scene.width,[int]$scene.height)
$graphics=[System.Drawing.Graphics]::FromImage($bitmap)
$graphics.SmoothingMode=[System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
$background=[System.Drawing.ColorTranslator]::FromHtml('#101a21')
$graphics.Clear($background)
$gold=[System.Drawing.SolidBrush]::new([System.Drawing.ColorTranslator]::FromHtml('#e1b761'))
$ink=[System.Drawing.SolidBrush]::new([System.Drawing.ColorTranslator]::FromHtml('#cbd1cc'))
$panel=[System.Drawing.SolidBrush]::new([System.Drawing.ColorTranslator]::FromHtml('#192731'))
$header=[System.Drawing.Font]::new('Segoe UI',26,[System.Drawing.FontStyle]::Bold)
$title=[System.Drawing.Font]::new('Segoe UI',14,[System.Drawing.FontStyle]::Bold)
$small=[System.Drawing.Font]::new('Segoe UI',11)
try {
 $graphics.DrawString($scene.title,$header,$gold,25,15)
 $graphics.DrawString($scene.subtitle,$small,$ink,29,67)
 foreach($tile in $scene.tiles){
  $graphics.FillRectangle($panel,[single]($tile.x+10),[single]$tile.y,360,345)
  foreach($polygon in $tile.polygons){
   $brush=[System.Drawing.SolidBrush]::new([System.Drawing.Color]::FromArgb(255,[int]$polygon.color[0],[int]$polygon.color[1],[int]$polygon.color[2]))
   try { $points=[System.Drawing.PointF[]]@($polygon.points | ForEach-Object { [System.Drawing.PointF]::new([single]$_[0],[single]$_[1]) }); $graphics.FillPolygon($brush,$points) } finally { $brush.Dispose() }
  }
  $graphics.DrawString($tile.title,$title,$gold,[single]($tile.x+24),[single]($tile.y+295))
  $graphics.DrawString('Original articulated geometry',$small,$ink,[single]($tile.x+24),[single]($tile.y+322))
 }
 $bitmap.Save((Join-Path $packRoot 'preview/Roman-Mob-Models.png'),[System.Drawing.Imaging.ImageFormat]::Png)
} finally { $graphics.Dispose(); $bitmap.Dispose(); $gold.Dispose(); $ink.Dispose(); $panel.Dispose(); $header.Dispose(); $title.Dispose(); $small.Dispose() }
Write-Output 'Rendered preview/Roman-Mob-Models.png'
