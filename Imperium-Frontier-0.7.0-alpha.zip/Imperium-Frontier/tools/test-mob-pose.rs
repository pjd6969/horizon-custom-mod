#[path = "../native/engine/src/mob_pose.rs"]
mod mob_pose;
