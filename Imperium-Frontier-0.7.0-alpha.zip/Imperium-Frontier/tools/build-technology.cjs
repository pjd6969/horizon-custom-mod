// Complete RPG + engineering content builder. All art and models are original.
const fs=require('fs'),path=require('path'),zlib=require('zlib'),cp=require('child_process');
const root=path.resolve(__dirname,'..'),content=path.join(root,'content'),ns='ashen_frontier';
process.env.IMPERIUM_ENGINEERING='1';
cp.execFileSync(process.execPath,[path.join(__dirname,'build-mob-models.cjs')],{stdio:'inherit'});
function write(p,v){p=path.join(content,p);fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,Buffer.isBuffer(v)?v:JSON.stringify(v,null,2)+'\n');}
const inv=JSON.parse(fs.readFileSync(path.join(root,'content-inventory.json'))),lang=JSON.parse(fs.readFileSync(path.join(content,`assets/${ns}/lang/en_us.json`)));
function crc(b){let c=0xffffffff;for(const x of b){c^=x;for(let k=0;k<8;k++)c=c>>>1^((c&1)?0xedb88320:0);}return(c^0xffffffff)>>>0;}
function png(color,item,kind){let raw=Buffer.alloc(16*65);for(let y=0;y<16;y++)for(let x=0;x<16;x++){let d=((x*11+y*7+x*y)%9)-4,c=color.map(v=>v+d);if(kind==='stone'&&(y%5===0||(x+Math.floor(y/5)*5)%8===0))c=c.map(v=>v*.65);if(kind==='bronze'&&(x%5===0||y%5===0))c=[220,173,73];let visible=!item||Math.abs(x-7.5)+Math.abs(y-7.5)<7;if(kind==='sword')visible=(Math.abs(x-7.5)<1.7&&y<12)||(y===10&&x>3&&x<12)||(y>10&&x>6&&x<10);raw.set([...c.map(v=>Math.round(Math.max(0,Math.min(255,v)))),visible?255:0],y*65+x*4+1);}const ch=(n,b)=>{let h=Buffer.alloc(4),c=Buffer.alloc(4);h.writeUInt32BE(b.length);c.writeUInt32BE(crc(Buffer.concat([Buffer.from(n),b])));return Buffer.concat([h,Buffer.from(n),b,c]);};let h=Buffer.alloc(13);h.writeUInt32BE(16);h.writeUInt32BE(16,4);h[8]=8;h[9]=6;return Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]),ch('IHDR',h),ch('IDAT',zlib.deflateSync(raw)),ch('IEND',Buffer.alloc(0))]);}
const id=n=>n.includes(':')?n:ns+':'+n;
const box=(from,to)=>({from,to,faces:Object.fromEntries(['down','up','north','south','east','west'].map(f=>[f,{texture:'#all'}]))});
const mill=[box([1,0,1],[15,3,15]),box([2,3,2],[5,12,14]),box([11,3,2],[14,12,14]),box([4,7,4],[12,11,12]),box([6,11,6],[10,15,10])];
mill.push(...[box([3,3,0],[13,5,2]),box([1,5,0],[3,13,2]),box([13,5,0],[15,13,2]),box([3,13,0],[13,15,2]),box([7,4,0],[9,14,2]),box([2,8,0],[14,10,2])]);
const press=[box([0,0,0],[16,3,16]),box([1,3,1],[4,16,4]),box([12,3,12],[15,16,15]),box([1,14,1],[15,16,15]),box([6,4,6],[10,14,10]),box([3,5,3],[13,7,13])];
const hearth=[box([0,0,0],[16,3,16]),box([0,3,0],[3,14,16]),box([13,3,0],[16,14,16]),box([3,3,13],[13,14,16]),box([0,12,0],[16,16,16]),box([5,3,6],[11,5,12])];
const tank=[box([1,0,1],[15,3,15]),box([1,3,1],[3,14,15]),box([13,3,1],[15,14,15]),box([3,3,1],[13,14,3]),box([3,3,13],[13,14,15])];
const altar=[box([0,0,0],[16,3,16]),box([4,3,4],[12,12,12]),box([1,12,1],[15,15,15]),box([6,15,6],[10,16,10])];
const blocks=[
 ['watermill','Roman Watermill',[130,98,62],mill,'wood'],['olive_press','Olive Press',[120,86,51],press,'wood'],
 ['lime_kiln','Lime Kiln',[170,154,126],hearth,'stone'],['bloomery','Imperial Bloomery',[88,83,75],hearth,'stone'],
 ['steam_workshop','Aether Steam Workshop',[159,112,57],[box([0,0,0],[16,3,16]),box([3,3,3],[13,14,13]),box([6,14,6],[10,16,10]),box([1,3,5],[3,16,8]),box([1,14,5],[8,16,8]),box([13,6,6],[16,10,10])],'bronze'],
 ['divine_forge','Forge of Sol Invictus',[201,162,68],altar,'bronze'],['cistern','Roman Cistern',[204,199,177],tank,'stone'],
 ['irrigation_valve','Irrigation Valve',[120,142,110],[box([0,0,0],[16,3,16]),box([5,3,5],[11,10,11]),box([2,10,6],[14,12,10])],'bronze'],
 ['hypocaust_brazier','Hypocaust Brazier',[151,98,54],altar,'bronze'],
 ['aqueduct_arch','Aqueduct Arch',[217,208,186],[box([0,0,0],[3,12,16]),box([13,0,0],[16,12,16]),box([0,12,0],[16,16,16]),box([3,9,0],[5,12,16]),box([11,9,0],[13,12,16])],'stone'],
 ['via_stone','Via Romana Paving',[121,123,113],[box([0,0,0],[16,16,16])],'stone'],
 ['roman_concrete','Roman Concrete',[188,180,158],[box([0,0,0],[16,16,16])],'stone']
];
for(const[n,title,c,elements,kind]of blocks){inv.blocks.push(n);lang[`block.${ns}.${n}`]=title;write(`data/${ns}/horizon/block/${n}.json`,{template:'minecraft:stone',properties:{hardness:2.5,requires_tool:true,occludes:false},shapes:{default:elements.map(e=>[...e.from,...e.to].map(v=>v/16))},collision_shapes:{default:elements.map(e=>[...e.from,...e.to].map(v=>v/16))}});write(`assets/${ns}/textures/block/${n}.png`,png(c,false,kind));write(`assets/${ns}/models/block/${n}.json`,{textures:{all:`${ns}:block/${n}`,particle:`${ns}:block/${n}`},elements});write(`assets/${ns}/blockstates/${n}.json`,{variants:{'':{model:`${ns}:block/${n}`}}});write(`assets/${ns}/items/${n}.json`,{model:{type:'minecraft:model',model:`${ns}:block/${n}`}});write(`data/${ns}/loot_table/blocks/${n}.json`,{type:'minecraft:block',pools:[{rolls:1,entries:[{type:'minecraft:item',name:id(n)}]}]});}
const items=[['flour','Milled Flour','wheat',[230,218,181]],['olive_cluster','Olive Cluster','wheat',[101,124,59]],['olive_oil','Amphora of Olive Oil','wheat',[166,146,55]],['quicklime','Quicklime','white_dye',[219,216,193]],['steam_core','Aether Pressure Core','iron_ingot',[166,137,72]],['sunsteel_ingot','Sunsteel Ingot','netherite_ingot',[236,182,64]],['aquila_sword','Aquila of Sol','netherite_sword',[237,199,87]]];
for(const[n,title,template,c]of items){inv.items.push(n);lang[`item.${ns}.${n}`]=title;write(`data/${ns}/horizon/item/${n}.json`,{template:'minecraft:'+template,rarity:n==='aquila_sword'?'epic':n==='sunsteel_ingot'?'rare':'common'});write(`assets/${ns}/textures/item/${n}.png`,png(c,true,n==='aquila_sword'?'sword':'item'));write(`assets/${ns}/models/item/${n}.json`,{parent:n==='aquila_sword'?'minecraft:item/handheld':'minecraft:item/generated',textures:{layer0:`${ns}:item/${n}`}});write(`assets/${ns}/items/${n}.json`,{model:{type:'minecraft:model',model:`${ns}:item/${n}`}});}
function recipe(name,ingredients,result=name,count=1){write(`data/${ns}/recipe/${name}.json`,{type:'minecraft:crafting_shapeless',category:'misc',ingredients:ingredients.map(id),result:{id:id(result),count}});}
for(const[n,ing]of[
 ['watermill',['minecraft:stone','minecraft:stone','minecraft:stone','minecraft:oak_planks','minecraft:oak_planks','minecraft:iron_ingot']],
 ['olive_press',['minecraft:oak_planks','minecraft:oak_planks','minecraft:oak_planks','minecraft:piston','minecraft:barrel']],
 ['lime_kiln',['minecraft:bricks','minecraft:bricks','minecraft:bricks','minecraft:furnace','minecraft:clay_ball']],
 ['bloomery',['roman_concrete','roman_concrete','roman_concrete','minecraft:furnace','minecraft:iron_ingot']],
 ['steam_workshop',['tempered_ember','tempered_ember','minecraft:copper_block','minecraft:piston','minecraft:cauldron','relic_fragment']],
 ['divine_forge',['steam_core','steam_core','relic_core','relic_core','minecraft:gold_block','sovereign_seal']],
 ['cistern',['minecraft:bricks','minecraft:bricks','minecraft:bricks','minecraft:bucket']],
 ['irrigation_valve',['minecraft:copper_ingot','minecraft:copper_ingot','minecraft:iron_ingot','minecraft:lever']],
 ['hypocaust_brazier',['minecraft:bricks','minecraft:bricks','minecraft:campfire','minecraft:copper_ingot']],
 ['aqueduct_arch',['roman_concrete','roman_concrete','roman_concrete','minecraft:stone_bricks']],
 ['via_stone',['minecraft:stone_bricks','minecraft:gravel','quicklime']],
 ['roman_concrete',['quicklime','minecraft:gravel','minecraft:clay_ball','minecraft:sand']],
 ['aquila_sword',['sunsteel_ingot','sunsteel_ingot','sunsteel_ingot','minecraft:blaze_rod','warden_seal']]
])recipe(n,ing,n,['aqueduct_arch','via_stone','roman_concrete'].includes(n)?4:1);
recipe('olive_cluster',['amberwood_leaves','amberwood_leaves','minecraft:wheat'],'olive_cluster',2);
recipe('oiled_rations',['olive_oil','minecraft:bread','minecraft:bread','minecraft:cooked_porkchop'],'expedition_ration',4);
write(`data/${ns}/recipe/mill_bread.json`,{type:'minecraft:smelting',category:'food',ingredient:id('flour'),result:{id:'minecraft:bread'},experience:.2,cookingtime:100});
const recipes=[
 {station:'watermill',title:'Watermill',rank:2,quest:'tech_survey',boss:'',power:'Flow',ticks:100,inputs:[['minecraft:wheat',3]],output:['flour',6]},
 {station:'olive_press',title:'Olive Press',rank:2,quest:'tech_survey',boss:'',power:'None',ticks:120,inputs:[['olive_cluster',4]],output:['olive_oil',2]},
 {station:'lime_kiln',title:'Lime Kiln',rank:2,quest:'tech_survey',boss:'',power:'None',ticks:160,inputs:[['minecraft:calcite',4],['minecraft:charcoal',1]],output:['quicklime',4]},
 {station:'bloomery',title:'Imperial Bloomery',rank:3,quest:'tech_kiln',boss:'',power:'None',ticks:240,inputs:[['minecraft:iron_ingot',2],['quicklime',1],['minecraft:charcoal',1]],output:['tempered_ember',2]},
 {station:'steam_workshop',title:'Aether Steam Workshop',rank:4,quest:'tech_forge',boss:'warden',power:'Steam',ticks:300,inputs:[['tempered_ember',4],['minecraft:copper_ingot',2],['relic_fragment',1]],output:['steam_core',1]},
 {station:'divine_forge',title:'Forge of Sol Invictus',rank:5,quest:'tech_steam',boss:'emperor',power:'Divine',ticks:400,inputs:[['tempered_ember',2],['relic_core',2],['relic_fragment',4],['steam_core',1]],output:['sunsteel_ingot',1]}
];
const ruststr=JSON.stringify;
fs.writeFileSync(path.join(root,'native/engine/src/tech_catalog.rs'),'// Generated by tools/build-technology.cjs.\npub const RECIPES: [Recipe; 6] = [\n'+recipes.map(r=>`Recipe {station:${ruststr(id(r.station))}, title:${ruststr(r.title)}, rank:${r.rank}, quest:${ruststr(r.quest)}, boss:${ruststr(r.boss)}, power:Power::${r.power}, ticks:${r.ticks}, inputs:&[${r.inputs.map(([n,c])=>`(${ruststr(id(n))},${c})`).join(',')}], output:(${ruststr(id(r.output[0]))},${r.output[1]})},`).join('\n')+'\n];\n');
const settlementsPath=path.join(root,'settlement-inventory.json');const settlementData=JSON.parse(fs.readFileSync(settlementsPath));settlementData.quests=20;fs.writeFileSync(settlementsPath,JSON.stringify(settlementData,null,2));
fs.writeFileSync(path.join(root,'technology-inventory.json'),JSON.stringify({version:'0.6.0',stations:recipes,blocks:blocks.map(b=>b[0]),items:items.map(i=>i[0]),quests:8},null,2));
write(`assets/${ns}/lang/en_us.json`,lang);write(`data/${ns}/horizon/creative_tab/frontier.json`,{title:'Imperium Frontier',icon:id('aquila_sword'),items:[...inv.blocks,...inv.items].map(id)});
for(const tag of ['pickaxe']){let p=`data/minecraft/tags/block/mineable/${tag}.json`,j=JSON.parse(fs.readFileSync(path.join(content,p)));j.values.push(...blocks.map(b=>id(b[0])));write(p,j);}
fs.writeFileSync(path.join(root,'content-inventory.json'),JSON.stringify(inv,null,2));const mf=path.join(content,'horizon-mod.toml');fs.writeFileSync(mf,fs.readFileSync(mf,'utf8').replace(/version = "[^"]+"/,'version = "0.6.0"'));
console.log(`Engineering expansion: ${blocks.length} blocks, ${items.length} items, ${recipes.length} timed production stations; ${inv.blocks.length} blocks / ${inv.items.length} items total.`);
cp.execFileSync(process.execPath,[path.join(__dirname,'update-recipe-guide.cjs')],{stdio:'inherit'});
