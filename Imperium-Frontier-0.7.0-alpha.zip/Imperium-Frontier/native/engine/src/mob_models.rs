//! Original articulated mob renderer. No vanilla body/model parts are submitted.
use super::*;
mod ids {
    include!("mob_model_ids.rs");
}
pub(super) fn register(e: &mut StandaloneModelsEvent<'_>) {
    e.models
        .extend(ids::MODEL_IDS.iter().flatten().map(|id| (*id).to_owned()));
}
pub(super) fn draw(host: &dyn Host, e: &mut MobSubmitEvent<'_>) -> Flow {
    let Some(index) = ids::KINDS.iter().position(|kind| *kind == e.mob.kind) else {
        return Flow::Continue;
    };
    let m = e.mob;
    let pose = super::mob_pose::pose(
        m.walk_position,
        m.walk_speed,
        m.age,
        m.head_yaw,
        m.pitch,
        m.death_time,
        m.baby,
    );
    let d = &mut *e.draw;
    d.push();
    d.scale([pose.scale; 3]);
    d.rotate_about([0., 0., 1.], pose.death_roll, [0., 0., 0.]);
    let tint = if m.hurt_time > 0 { 0xff8888 } else { 0xffffff };
    for (i, pivot) in ids::PIVOTS[index].iter().enumerate() {
        d.push();
        d.translate(pivot.map(|v| v / 16.));
        if i == 1 {
            d.rotate_about([0., 1., 0.], -pose.head_yaw, [0.; 3]);
        }
        if e.mob.kind.ends_with("jupiter_eagle") && (i == 2 || i == 3) {
            d.rotate_about(
                [0., 0., 1.],
                (e.mob.age * 0.22).sin() * 22. * if i == 2 { 1. } else { -1. },
                [0.; 3],
            );
        } else {
            d.rotate_about([1., 0., 0.], pose.pitch[i], [0.; 3]);
        }
        let drawn = host.draw_model(d, ids::MODEL_IDS[index][i], tint);
        d.pop();
        if !drawn && i == 0 {
            d.pop();
            return Flow::Continue;
        }
    }
    d.pop();
    // Consume vanilla geometry even if a missing resource leaves a partial model:
    // avoids drawing two overlapping bodies. The loader logs failed models.
    Flow::Cancel
}
