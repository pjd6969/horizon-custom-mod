//! Learnable boss attacks: a fixed warning, one strike, then recovery.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Pattern {
    Cleave,
    Slam,
    Brand,
}
#[derive(Clone, Copy, Debug)]
pub struct Boss {
    pub id: &'static str,
    pub title: &'static str,
    pub health: f32,
    pub windup: i64,
    pub recovery: i64,
    pub damage: f32,
}
pub const BOSSES: [Boss; 6] = [
    Boss {
        id: "ashen_frontier:crypt_warden",
        title: "Fallen Centurion",
        health: 120.,
        windup: 46,
        recovery: 52,
        damage: 6.,
    },
    Boss {
        id: "ashen_frontier:cinder_sovereign",
        title: "Usurper Emperor",
        health: 200.,
        windup: 44,
        recovery: 48,
        damage: 7.,
    },
    Boss {
        id: "ashen_frontier:forge_tyrant",
        title: "Vulcan's Forge Tyrant",
        health: 260.,
        windup: 48,
        recovery: 46,
        damage: 8.,
    },
    Boss {
        id: "ashen_frontier:styx_judge",
        title: "Praetor of Dis",
        health: 320.,
        windup: 50,
        recovery: 44,
        damage: 9.,
    },
    Boss {
        id: "ashen_frontier:astral_legate",
        title: "Astral Legate",
        health: 380.,
        windup: 48,
        recovery: 44,
        damage: 10.,
    },
    Boss {
        id: "ashen_frontier:sol_avatar",
        title: "Avatar of Sol Invictus",
        health: 450.,
        windup: 52,
        recovery: 46,
        damage: 11.,
    },
];
pub fn boss(id: &str) -> Option<&'static Boss> {
    BOSSES.iter().find(|b| b.id == id)
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Phase {
    Approach,
    Windup,
    Recovery,
}
#[derive(Clone, Debug)]
pub struct Fight {
    pub phase: Phase,
    pub until: i64,
    pub sequence: u32,
    pub pattern: Pattern,
    pub origin: [f64; 3],
    pub mark: [f64; 3],
    pub aim: [f64; 2],
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Event {
    None,
    Warn,
    Strike,
}
impl Fight {
    pub fn new(now: i64) -> Self {
        Self {
            phase: Phase::Recovery,
            until: now + 40,
            sequence: 0,
            pattern: Pattern::Cleave,
            origin: [0.; 3],
            mark: [0.; 3],
            aim: [0., 1.],
        }
    }
    pub fn step(
        &mut self,
        b: &Boss,
        now: i64,
        origin: [f64; 3],
        target: Option<[f64; 3]>,
        health: f32,
    ) -> Event {
        match self.phase {
            Phase::Recovery => {
                if now >= self.until {
                    self.phase = Phase::Approach;
                }
                Event::None
            }
            Phase::Approach => {
                let Some(target) = target else {
                    return Event::None;
                };
                let d = [target[0] - origin[0], target[2] - origin[2]];
                let len = d[0].hypot(d[1]);
                if !len.is_finite() || len > 10. {
                    return Event::None;
                }
                self.pattern = match self.sequence % 3 {
                    0 => Pattern::Cleave,
                    1 => Pattern::Brand,
                    _ => Pattern::Slam,
                };
                self.sequence = self.sequence.wrapping_add(1);
                self.origin = origin;
                self.mark = target;
                self.aim = if len > 0.001 {
                    [d[0] / len, d[1] / len]
                } else {
                    [0., 1.]
                };
                self.phase = Phase::Windup;
                self.until = now + (b.windup - if health < b.health * 0.5 { 8 } else { 0 }).max(32);
                Event::Warn
            }
            Phase::Windup => {
                if now < self.until {
                    return Event::None;
                }
                self.phase = Phase::Recovery;
                self.until = now + b.recovery;
                Event::Strike
            }
        }
    }
    pub fn hits(&self, p: [f64; 3]) -> bool {
        let at = if self.pattern == Pattern::Brand {
            self.mark
        } else {
            self.origin
        };
        if p.iter().any(|v| !v.is_finite()) || (p[1] - at[1]).abs() > 2.5 {
            return false;
        }
        let d = [p[0] - at[0], p[2] - at[2]];
        let len = d[0].hypot(d[1]);
        match self.pattern {
            Pattern::Brand => len <= 2.5,
            Pattern::Slam => len <= 3.5,
            Pattern::Cleave => {
                len <= 4.5 && (len < 0.01 || (d[0] * self.aim[0] + d[1] * self.aim[1]) / len >= 0.5)
            }
        }
    }
    pub fn label(&self) -> &'static str {
        match self.pattern {
            Pattern::Cleave => "CLEAVE — circle behind or retreat",
            Pattern::Slam => "GROUND SLAM — leave the marked circle",
            Pattern::Brand => "DIVINE BRAND — leave the marked ground",
        }
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn no_instant_strike_on_spawn() {
        let mut f = Fight::new(0);
        assert_eq!(
            f.step(&BOSSES[0], 0, [0.; 3], Some([0., 0., 1.]), 120.),
            Event::None
        );
        assert_eq!(f.phase, Phase::Recovery);
    }
    #[test]
    fn warning_precedes_damage_and_locks_mark() {
        let mut f = Fight::new(0);
        f.step(&BOSSES[0], 40, [0.; 3], Some([0., 0., 2.]), 120.);
        assert_eq!(
            f.step(&BOSSES[0], 41, [0.; 3], Some([0., 0., 2.]), 120.),
            Event::Warn
        );
        let mark = f.mark;
        assert_eq!(
            f.step(&BOSSES[0], 60, [5.; 3], Some([8.; 3]), 120.),
            Event::None
        );
        assert_eq!(f.mark, mark);
        assert_eq!(
            f.step(&BOSSES[0], 87, [0.; 3], Some([0.; 3]), 120.),
            Event::Strike
        );
    }
    #[test]
    fn recovery_never_double_strikes() {
        let mut f = Fight::new(0);
        f.phase = Phase::Windup;
        f.until = 10;
        assert_eq!(f.step(&BOSSES[0], 10, [0.; 3], None, 120.), Event::Strike);
        assert_eq!(f.step(&BOSSES[0], 11, [0.; 3], None, 120.), Event::None);
    }
    #[test]
    fn cone_has_safe_rear_and_range() {
        let f = Fight::new(0);
        assert!(f.hits([0., 0., 3.]));
        assert!(!f.hits([0., 0., -2.]));
        assert!(!f.hits([0., 0., 5.]));
    }
    #[test]
    fn brand_can_be_outwalked() {
        let mut f = Fight::new(0);
        f.pattern = Pattern::Brand;
        f.mark = [8., 0., 8.];
        assert!(f.hits([8., 0., 8.]));
        assert!(!f.hits([11., 0., 8.]));
    }
    #[test]
    fn enrage_keeps_reaction_window() {
        for b in BOSSES {
            let mut f = Fight::new(0);
            f.phase = Phase::Approach;
            f.step(&b, 100, [0.; 3], Some([0., 0., 2.]), 1.);
            assert!(f.until - 100 >= 32);
            assert!(b.recovery >= 40);
            assert!(b.damage < 20.);
        }
    }
    #[test]
    fn no_target_means_no_warning() {
        let mut f = Fight::new(0);
        f.phase = Phase::Approach;
        assert_eq!(f.step(&BOSSES[0], 100, [0.; 3], None, 100.), Event::None);
    }
    #[test]
    fn vertical_and_nonfinite_positions_miss() {
        let f = Fight::new(0);
        assert!(!f.hits([0., 8., 1.]));
        assert!(!f.hits([f64::NAN, 0., 1.]));
    }
}
