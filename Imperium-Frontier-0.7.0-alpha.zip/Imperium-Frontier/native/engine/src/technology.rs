//! Pure Roman engineering recipes, progression and timed-job rules.
use std::collections::BTreeSet;
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Power {
    None,
    Flow,
    Steam,
    Divine,
}
#[derive(Clone, Copy, Debug)]
pub struct Recipe {
    pub station: &'static str,
    pub title: &'static str,
    pub rank: u32,
    pub quest: &'static str,
    pub boss: &'static str,
    pub power: Power,
    pub ticks: i64,
    pub inputs: &'static [(&'static str, u32)],
    pub output: (&'static str, u32),
}
include!("tech_catalog.rs");
pub fn recipe(station: &str) -> Option<&'static Recipe> {
    RECIPES.iter().find(|r| r.station == station)
}
pub fn gate(r: &Recipe, rank: u32, completed: &BTreeSet<String>) -> Result<(), &'static str> {
    if rank < r.rank {
        return Err("Your imperial rank is too low for this station.");
    }
    if !completed.contains(r.quest) {
        return Err("Complete this station's engineering commission first. /frontier tech");
    }
    if !r.boss.is_empty() && !completed.contains(r.boss) {
        return Err(
            "Complete the required boss commission before using this late-game technology.",
        );
    }
    Ok(())
}
pub fn ready(finish: i64, now: i64) -> bool {
    finish <= now
}
pub fn duration(r: &Recipe, now: i64) -> i64 {
    now.saturating_add(r.ticks)
}
pub fn profession(completed: &BTreeSet<String>) -> &'static str {
    if completed.contains("tech_divine") {
        "Artifex of Sol"
    } else if completed.contains("tech_steam") {
        "Aether Mechanicus"
    } else if completed.contains("tech_forge") {
        "Imperial Artifex"
    } else if completed.contains("tech_survey") {
        "Roman Apprentice"
    } else {
        "Untrained"
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn early_quest_unlocks_historical_only() {
        let q = BTreeSet::from(["tech_survey".into()]);
        assert!(gate(&RECIPES[0], 2, &q).is_ok());
        assert!(gate(&RECIPES[4], 5, &q).is_err());
    }
    #[test]
    fn ranks_gate_even_with_quests() {
        let q = BTreeSet::from(["tech_survey".into()]);
        assert!(gate(&RECIPES[0], 1, &q).is_err());
    }
    #[test]
    fn steam_requires_boss_story() {
        let mut q = BTreeSet::from(["tech_forge".into()]);
        assert!(gate(&RECIPES[4], 4, &q).is_err());
        q.insert("warden".into());
        assert!(gate(&RECIPES[4], 4, &q).is_ok());
    }
    #[test]
    fn divine_is_endgame() {
        let q = BTreeSet::from(["tech_steam".into(), "emperor".into()]);
        assert!(gate(&RECIPES[5], 4, &q).is_err());
        assert!(gate(&RECIPES[5], 5, &q).is_ok());
    }
    #[test]
    fn boundaries_and_saturation() {
        assert!(!ready(101, 100));
        assert!(ready(101, 101));
        assert_eq!(duration(&RECIPES[0], i64::MAX), i64::MAX);
    }
    #[test]
    fn recipes_are_unique_and_bounded() {
        let mut names = BTreeSet::new();
        for r in RECIPES {
            assert!(names.insert(r.station));
            assert!(r.ticks >= 20 && r.ticks <= 1200);
            assert!(r.output.1 > 0 && r.output.1 <= 64);
            assert!(
                r.inputs
                    .iter()
                    .all(|(n, c)| *c > 0 && *c <= 64 && *n != r.output.0)
            );
        }
    }
    #[test]
    fn professions_follow_commissions() {
        let mut q = BTreeSet::new();
        assert_eq!(profession(&q), "Untrained");
        q.insert("tech_survey".into());
        assert_eq!(profession(&q), "Roman Apprentice");
        q.insert("tech_divine".into());
        assert_eq!(profession(&q), "Artifex of Sol");
    }
    #[test]
    fn unknown_station_is_not_a_recipe() {
        assert!(recipe("minecraft:furnace").is_none());
    }
}
