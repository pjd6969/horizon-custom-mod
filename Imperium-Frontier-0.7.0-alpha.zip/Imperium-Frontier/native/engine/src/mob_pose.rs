#[derive(Debug)]
pub(super) struct Pose {
    pub pitch: [f32; 6],
    pub head_yaw: f32,
    pub death_roll: f32,
    pub scale: f32,
}
pub(super) fn pose(
    position: f32,
    speed: f32,
    age: f32,
    yaw: f32,
    pitch: f32,
    death: i32,
    baby: bool,
) -> Pose {
    let speed = if speed.is_finite() {
        speed.clamp(0., 1.)
    } else {
        0.
    };
    let position = if position.is_finite() { position } else { 0. };
    let age = if age.is_finite() { age } else { 0. };
    let swing = (position * 0.6662).cos() * speed * 34.;
    let idle = (age * 0.07).sin() * 1.8;
    let head_yaw = if yaw.is_finite() {
        yaw.clamp(-80., 80.)
    } else {
        0.
    };
    let look = if pitch.is_finite() {
        pitch.clamp(-65., 65.)
    } else {
        0.
    };
    Pose {
        pitch: [
            0.,
            look,
            -swing * 0.65 + idle,
            swing * 0.65 - idle,
            swing,
            -swing,
        ],
        head_yaw,
        death_roll: (death as f32 / 20.).clamp(0., 1.) * 90.,
        scale: if baby { 0.5 } else { 1. },
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    mod ids {
        include!("mob_model_ids.rs");
    }
    #[test]
    fn registry_has_unique_models_for_every_role() {
        let ids: std::collections::BTreeSet<_> = ids::MODEL_IDS.iter().flatten().collect();
        assert_eq!(ids.len(), ids::KINDS.len() * 6);
        assert!(ids::KINDS.len() >= 11);
        assert_eq!(ids::PIVOTS.len(), ids::KINDS.len());
    }
    #[test]
    fn legs_counter_swing_and_stop_at_rest() {
        let p = pose(0., 1., 0., 0., 0., 0, false);
        assert_eq!(p.pitch[4], -p.pitch[5]);
        let p = pose(2., 0., 0., 0., 0., 0, false);
        assert_eq!(p.pitch[4], 0.);
    }
    #[test]
    fn look_and_death_are_bounded() {
        let p = pose(0., 0., 0., 180., -120., 40, true);
        assert_eq!(p.head_yaw, 80.);
        assert_eq!(p.pitch[1], -65.);
        assert_eq!(p.death_roll, 90.);
        assert_eq!(p.scale, 0.5);
    }
    #[test]
    fn invalid_animation_input_stays_finite() {
        let p = pose(
            f32::NAN,
            f32::INFINITY,
            f32::NAN,
            f32::NAN,
            f32::INFINITY,
            0,
            false,
        );
        assert!(p.pitch.iter().all(|n| n.is_finite()));
        assert_eq!(p.head_yaw, 0.);
    }
}
