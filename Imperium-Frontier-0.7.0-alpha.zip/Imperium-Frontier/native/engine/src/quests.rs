//! Original persistent quest rules. Host integration lives in the native module.
use std::collections::BTreeSet;
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Goal {
    Deliver(&'static str, u32),
    Kill(&'static str, u32),
    Craft(&'static str, u32),
    Visit(&'static str),
}
#[derive(Clone, Copy, Debug)]
pub struct Quest {
    pub id: &'static str,
    pub title: &'static str,
    pub giver: &'static str,
    pub requires: &'static str,
    pub goal: Goal,
    pub glory: u32,
    pub coins: u32,
}
pub const QUESTS: [Quest; 20] = [
    Quest {
        id: "enlist",
        title: "Bread for the Legion",
        giver: "quartermaster",
        requires: "",
        goal: Goal::Deliver("minecraft:bread", 8),
        glory: 15,
        coins: 8,
    },
    Quest {
        id: "first_blood",
        title: "The Restless Dead",
        giver: "prefect",
        requires: "enlist",
        goal: Goal::Kill("ashen_frontier:ashbound", 3),
        glory: 25,
        coins: 12,
    },
    Quest {
        id: "gladius",
        title: "A Legionary's Blade",
        giver: "quartermaster",
        requires: "enlist",
        goal: Goal::Craft("ashen_frontier:ember_sword", 1),
        glory: 20,
        coins: 10,
    },
    Quest {
        id: "stonework",
        title: "Rebuild the Frontier",
        giver: "prefect",
        requires: "enlist",
        goal: Goal::Deliver("ashen_frontier:ashen_bricks", 32),
        glory: 25,
        coins: 14,
    },
    Quest {
        id: "town",
        title: "The Provincial Roads",
        giver: "prefect",
        requires: "enlist",
        goal: Goal::Visit("town"),
        glory: 20,
        coins: 10,
    },
    Quest {
        id: "bandits",
        title: "Bandits on the Road",
        giver: "prefect",
        requires: "first_blood",
        goal: Goal::Kill("ashen_frontier:bandit", 5),
        glory: 40,
        coins: 20,
    },
    Quest {
        id: "supply",
        title: "The Legion Must Eat",
        giver: "quartermaster",
        requires: "gladius",
        goal: Goal::Deliver("ashen_frontier:expedition_ration", 8),
        glory: 30,
        coins: 16,
    },
    Quest {
        id: "fort",
        title: "Report to the Castrum",
        giver: "prefect",
        requires: "town",
        goal: Goal::Visit("fort"),
        glory: 35,
        coins: 18,
    },
    Quest {
        id: "city",
        title: "Audience in the City",
        giver: "prefect",
        requires: "stonework",
        goal: Goal::Visit("city"),
        glory: 45,
        coins: 24,
    },
    Quest {
        id: "warden",
        title: "The Fallen Centurion",
        giver: "prefect",
        requires: "bandits",
        goal: Goal::Kill("ashen_frontier:crypt_warden", 1),
        glory: 70,
        coins: 35,
    },
    Quest {
        id: "praetorian",
        title: "Steel for a Praetorian",
        giver: "quartermaster",
        requires: "warden",
        goal: Goal::Craft("ashen_frontier:relic_sword", 1),
        glory: 60,
        coins: 30,
    },
    Quest {
        id: "emperor",
        title: "The Usurper's Fall",
        giver: "prefect",
        requires: "praetorian",
        goal: Goal::Kill("ashen_frontier:cinder_sovereign", 1),
        glory: 150,
        coins: 64,
    },
    Quest {
        id: "tech_survey",
        title: "An Engineer for the Legion",
        giver: "quartermaster",
        requires: "enlist",
        goal: Goal::Deliver("minecraft:copper_ingot", 8),
        glory: 20,
        coins: 10,
    },
    Quest {
        id: "tech_mill",
        title: "Bread for the March",
        giver: "quartermaster",
        requires: "tech_survey",
        goal: Goal::Deliver("ashen_frontier:flour", 6),
        glory: 25,
        coins: 12,
    },
    Quest {
        id: "tech_press",
        title: "Oil for the Frontier",
        giver: "quartermaster",
        requires: "tech_mill",
        goal: Goal::Deliver("ashen_frontier:olive_oil", 4),
        glory: 30,
        coins: 14,
    },
    Quest {
        id: "tech_kiln",
        title: "The Art of Roman Concrete",
        giver: "quartermaster",
        requires: "tech_press",
        goal: Goal::Deliver("ashen_frontier:quicklime", 8),
        glory: 35,
        coins: 18,
    },
    Quest {
        id: "tech_forge",
        title: "Steel of the Artifex",
        giver: "quartermaster",
        requires: "tech_kiln",
        goal: Goal::Deliver("ashen_frontier:tempered_ember", 4),
        glory: 45,
        coins: 24,
    },
    Quest {
        id: "tech_steam",
        title: "The Aether Awakens",
        giver: "quartermaster",
        requires: "tech_forge",
        goal: Goal::Deliver("ashen_frontier:steam_core", 2),
        glory: 70,
        coins: 35,
    },
    Quest {
        id: "tech_divine",
        title: "Fire of Sol Invictus",
        giver: "quartermaster",
        requires: "tech_steam",
        goal: Goal::Deliver("ashen_frontier:sunsteel_ingot", 1),
        glory: 100,
        coins: 50,
    },
    Quest {
        id: "tech_aquila",
        title: "The Legendary Aquila",
        giver: "quartermaster",
        requires: "tech_divine",
        goal: Goal::Craft("ashen_frontier:aquila_sword", 1),
        glory: 120,
        coins: 64,
    },
];
pub fn get(id: &str) -> Option<&'static Quest> {
    QUESTS.iter().find(|q| q.id == id)
}
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct Journal {
    pub active: Option<String>,
    pub progress: u32,
    pub completed: BTreeSet<String>,
}
impl Journal {
    pub fn accept(&mut self, id: &str) -> Result<(), &'static str> {
        let q = get(id).ok_or("Unknown quest.")?;
        if self.active.is_some() {
            return Err("Finish or abandon your active quest first.");
        }
        if self.completed.contains(id) {
            return Err("This quest is already completed.");
        }
        if !q.requires.is_empty() && !self.completed.contains(q.requires) {
            return Err("Complete the prerequisite quest first.");
        }
        self.active = Some(id.into());
        self.progress = 0;
        Ok(())
    }
    pub fn event(&mut self, event: Goal) {
        let Some(q) = self.active.as_deref().and_then(get) else {
            return;
        };
        let count = match (q.goal, event) {
            (Goal::Kill(a, _), Goal::Kill(b, n)) if a == b => n,
            (Goal::Craft(a, _), Goal::Craft(b, n)) if a == b => n,
            (Goal::Visit(a), Goal::Visit(b)) if a == b => 1,
            _ => 0,
        };
        let cap = match q.goal {
            Goal::Deliver(_, n) | Goal::Kill(_, n) | Goal::Craft(_, n) => n,
            Goal::Visit(_) => 1,
        };
        self.progress = self.progress.saturating_add(count).min(cap);
    }
    pub fn ready(&self, inventory_count: u32) -> bool {
        let Some(q) = self.active.as_deref().and_then(get) else {
            return false;
        };
        match q.goal {
            Goal::Deliver(_, n) => inventory_count >= n,
            Goal::Kill(_, n) | Goal::Craft(_, n) => self.progress >= n,
            Goal::Visit(_) => self.progress >= 1,
        }
    }
    pub fn finish(&mut self) -> Option<&'static Quest> {
        let id = self.active.take()?;
        let q = get(&id)?;
        if !self.completed.insert(id) {
            return None;
        }
        self.progress = 0;
        Some(q)
    }
    pub fn abandon(&mut self) {
        self.active = None;
        self.progress = 0;
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn prerequisites_and_one_active() {
        let mut j = Journal::default();
        assert!(j.accept("emperor").is_err());
        j.accept("enlist").unwrap();
        assert!(j.accept("town").is_err());
    }
    #[test]
    fn delivery_requires_inventory() {
        let mut j = Journal::default();
        j.accept("enlist").unwrap();
        assert!(!j.ready(7));
        assert!(j.ready(8));
    }
    #[test]
    fn reward_claim_cannot_repeat() {
        let mut j = Journal::default();
        j.accept("enlist").unwrap();
        assert_eq!(j.finish().unwrap().coins, 8);
        assert!(j.finish().is_none());
        assert!(j.accept("enlist").is_err());
    }
    #[test]
    fn kill_matching_and_clamping() {
        let mut j = Journal::default();
        j.completed.insert("enlist".into());
        j.accept("first_blood").unwrap();
        j.event(Goal::Kill("minecraft:cow", 20));
        assert_eq!(j.progress, 0);
        j.event(Goal::Kill("ashen_frontier:ashbound", 99));
        assert_eq!(j.progress, 3);
        assert!(j.ready(0));
    }
    #[test]
    fn crafting_after_acceptance() {
        let mut j = Journal::default();
        j.event(Goal::Craft("ashen_frontier:ember_sword", 1));
        assert_eq!(j.progress, 0);
        j.completed.insert("enlist".into());
        j.accept("gladius").unwrap();
        j.event(Goal::Craft("ashen_frontier:ember_sword", 1));
        assert!(j.ready(0));
    }
    #[test]
    fn visits_match_settlement() {
        let mut j = Journal::default();
        j.completed.insert("enlist".into());
        j.accept("town").unwrap();
        j.event(Goal::Visit("fort"));
        assert!(!j.ready(0));
        j.event(Goal::Visit("town"));
        assert!(j.ready(0));
    }
    #[test]
    fn abandon_resets() {
        let mut j = Journal::default();
        j.accept("enlist").unwrap();
        j.abandon();
        assert!(j.active.is_none());
        assert_eq!(j.progress, 0);
        j.accept("enlist").unwrap();
    }
    #[test]
    fn definitions_form_valid_noncyclic_chains() {
        let mut ids = BTreeSet::new();
        for q in QUESTS {
            assert!(ids.insert(q.id));
            assert!(q.requires.is_empty() || ids.contains(q.requires));
            assert!(q.glory > 0 && q.coins > 0);
        }
        assert_eq!(ids.len(), QUESTS.len());
    }
}
