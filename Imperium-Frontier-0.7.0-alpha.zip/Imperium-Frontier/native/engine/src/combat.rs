//! Horizon adaptation of Funny-Bones' MIT combat sandbox's dodge/stamina design.
//! Costs 12/8 and 45 stamina/sec follow src/sim/data.rs. Other tuning is original,
//! in Minecraft's 20 Hz units; no extracted Elden Ring data or animations are used.
pub const MAX_STAMINA: f32 = 100.;
pub const ROLL_COST: f32 = 12.;
pub const BACKSTEP_COST: f32 = 8.;
pub const REGEN_PER_TICK: f32 = 45. / 20.;
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Load {
    Light,
    Medium,
    Heavy,
}
impl Load {
    pub fn name(self) -> &'static str {
        match self {
            Self::Light => "Light",
            Self::Medium => "Medium",
            Self::Heavy => "Heavy",
        }
    }
}
pub fn load(weight: u32) -> Load {
    if weight < 25 {
        Load::Light
    } else if weight < 65 {
        Load::Medium
    } else {
        Load::Heavy
    }
}
pub fn weight(item: &str) -> u32 {
    let armor = ["_helmet", "_chestplate", "_leggings", "_boots"]
        .iter()
        .any(|s| item.ends_with(s));
    if armor {
        if item.contains("netherite") {
            16
        } else if item.contains("diamond") || item.contains("relic_") {
            14
        } else if item.contains("iron") || item.contains("ember_") {
            12
        } else if item.contains("chainmail") {
            8
        } else if item.contains("golden") {
            10
        } else {
            4
        }
    } else if item.ends_with("shield") || item.ends_with("_scutum") {
        8
    } else if item.ends_with("_sword")
        || item.ends_with("_axe")
        || item.ends_with("trident")
        || item.ends_with("mace")
    {
        5
    } else {
        0
    }
}
#[derive(Clone, Copy, Debug)]
pub struct Fighter {
    pub stamina: f32,
    pub last_tick: i64,
    pub ready_at: i64,
    pub regen_at: i64,
    pub heavy_until: i64,
    last_hit: Option<(i64, f32)>,
}
impl Fighter {
    pub fn new(t: i64) -> Self {
        Self {
            stamina: MAX_STAMINA,
            last_tick: t,
            ready_at: t,
            regen_at: t,
            heavy_until: 0,
            last_hit: None,
        }
    }
    pub fn advance(&mut self, t: i64) {
        let elapsed = t
            .saturating_sub(self.last_tick.max(self.regen_at))
            .clamp(0, 200);
        self.stamina = (self.stamina + elapsed as f32 * REGEN_PER_TICK).min(MAX_STAMINA);
        self.last_tick = t;
    }
    fn spend(&mut self, t: i64, cost: f32) -> Result<(), &'static str> {
        self.advance(t);
        if self.stamina < cost {
            return Err("Not enough stamina.");
        }
        self.stamina -= cost;
        self.regen_at = t + 12;
        Ok(())
    }
    pub fn dodge(
        &mut self,
        t: i64,
        tier: Load,
        backstep: bool,
    ) -> Result<(f32, u32, u32), &'static str> {
        self.advance(t);
        if t < self.ready_at {
            return Err("Dodge recovering.");
        }
        let (speed, cooldown, iframes, cost) = if backstep {
            (0.55, 12, 0, BACKSTEP_COST)
        } else {
            match tier {
                Load::Light => (0.95, 14, 6, ROLL_COST),
                Load::Medium => (0.75, 18, 5, ROLL_COST + 4.),
                Load::Heavy => (0.55, 24, 4, ROLL_COST + 10.),
            }
        };
        self.spend(t, cost)?;
        self.ready_at = t + cooldown as i64;
        self.heavy_until = 0;
        Ok((speed, cooldown, iframes))
    }
    pub fn heavy(&mut self, t: i64) -> Result<(), &'static str> {
        self.advance(t);
        if t < self.ready_at || t < self.heavy_until {
            return Err("Combat action recovering.");
        }
        self.spend(t, 18.)?;
        self.heavy_until = t + 16;
        Ok(())
    }
    pub fn attack(&mut self, t: i64) -> Result<f32, &'static str> {
        // Vanilla sweep victims share one server tick and one stamina charge.
        if let Some((tick, multiplier)) = self.last_hit {
            if tick == t {
                return Ok(multiplier);
            }
        }
        self.advance(t);
        if t < self.ready_at {
            return Err("Combat action recovering.");
        }
        if self.heavy_until > t {
            self.heavy_until = 0;
            self.ready_at = t + 18;
            self.last_hit = Some((t, 1.6));
            Ok(1.6)
        } else {
            self.spend(t, 6.)?;
            self.ready_at = t + 7;
            self.last_hit = Some((t, 1.));
            Ok(1.)
        }
    }
}
/// Movement input: positive forward, positive strafe-left. Idle means a backstep.
pub fn kick(yaw: f32, forward: i8, strafe: i8, speed: f32) -> [f32; 3] {
    let (f, s) = if forward == 0 && strafe == 0 {
        (-1., 0.)
    } else {
        let (f, s) = (forward as f32, strafe as f32);
        let n = (f * f + s * s).sqrt();
        (f / n, s / n)
    };
    let a = yaw.to_radians();
    [
        (-a.sin() * f + a.cos() * s) * speed,
        0.,
        (a.cos() * f + a.sin() * s) * speed,
    ]
}
pub fn dodgeable(kind: &str) -> bool {
    matches!(
        kind.strip_prefix("minecraft:").unwrap_or(kind),
        "mob_attack"
            | "mob_attack_no_aggro"
            | "player_attack"
            | "arrow"
            | "trident"
            | "thrown"
            | "explosion"
            | "player_explosion"
    )
}
pub fn weapon(item: &str) -> bool {
    item.ends_with("_sword")
        || item.ends_with("_axe")
        || item.ends_with("trident")
        || item.ends_with("mace")
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn scutum_has_shield_weight() {
        assert_eq!(weight("ashen_frontier:legionary_scutum"), 8);
    }
    #[test]
    fn sweep_victims_share_one_cost() {
        let mut f = Fighter::new(0);
        assert_eq!(f.attack(0).unwrap(), 1.);
        assert_eq!(f.attack(0).unwrap(), 1.);
        assert_eq!(f.stamina, 94.);
        assert!(f.attack(1).is_err());
    }
    #[test]
    fn dodge_spends_once_and_respects_recovery() {
        let mut f = Fighter::new(0);
        assert!(f.dodge(0, Load::Light, false).is_ok());
        assert_eq!(f.stamina, 88.);
        assert!(f.dodge(1, Load::Light, false).is_err());
        assert_eq!(f.stamina, 88.);
        assert!(f.dodge(14, Load::Light, false).is_ok());
    }
    #[test]
    fn no_negative_stamina() {
        let mut f = Fighter::new(0);
        f.stamina = 7.;
        assert!(f.dodge(0, Load::Light, true).is_err());
        assert_eq!(f.stamina, 7.);
    }
    #[test]
    fn regen_waits_then_caps() {
        let mut f = Fighter::new(0);
        f.dodge(0, Load::Light, false).unwrap();
        f.advance(12);
        assert_eq!(f.stamina, 88.);
        f.advance(14);
        assert_eq!(f.stamina, 92.5);
        f.advance(1000);
        assert_eq!(f.stamina, 100.);
    }
    #[test]
    fn normalized_diagonals_and_backstep() {
        for yaw in [0., 90., 180., 270.] {
            for (f, s) in [(1, 0), (0, 1), (1, 1), (-1, -1), (0, 0)] {
                let k = kick(yaw, f, s, 0.75);
                assert!(((k[0] * k[0] + k[2] * k[2]).sqrt() - 0.75).abs() < 0.0001);
            }
        }
        assert!(kick(0., 0, 0, 1.)[2] < 0.);
    }
    #[test]
    fn load_changes_roll_and_backstep_has_no_iframes() {
        assert_eq!(load(24), Load::Light);
        assert_eq!(load(25), Load::Medium);
        assert_eq!(load(65), Load::Heavy);
        let mut f = Fighter::new(0);
        let heavy = f.dodge(0, Load::Heavy, false).unwrap();
        assert_eq!(heavy, (0.55, 24, 4));
        assert_eq!(f.stamina, 78.);
        let mut f = Fighter::new(0);
        assert_eq!(f.dodge(0, Load::Light, true).unwrap().2, 0);
    }
    #[test]
    fn invulnerability_excludes_environmental_damage() {
        assert!(dodgeable("minecraft:arrow"));
        assert!(dodgeable("mob_attack"));
        for k in [
            "fall",
            "lava",
            "on_fire",
            "starve",
            "in_wall",
            "magic",
            "out_of_world",
        ] {
            assert!(!dodgeable(k));
        }
    }
    #[test]
    fn heavy_consumed_once_and_can_expire() {
        let mut f = Fighter::new(0);
        f.heavy(0).unwrap();
        assert!(f.heavy(1).is_err());
        assert_eq!(f.attack(1).unwrap(), 1.6);
        assert!(f.attack(2).is_err());
        assert_eq!(f.attack(20).unwrap(), 1.);
        let mut f = Fighter::new(0);
        f.heavy(0).unwrap();
        assert_eq!(f.attack(17).unwrap(), 1.);
    }
}
