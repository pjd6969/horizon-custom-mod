use super::*;
#[derive(Clone)]
pub(super) struct Home {
    pub dimension: String,
    pub position: [f64; 3],
}
#[derive(Clone)]
pub(super) struct Travel {
    pub player: u128,
    pub realm: usize,
    pub started: i64,
    pub companion: Option<(u128, String)>,
}
impl Frontier {
    pub(super) fn adventure_guide(&self, host: &mut dyn Host, player: u128) {
        let stage = self
            .world(host, |w| *w.campaign.entry(player).or_default())
            .unwrap_or(0);
        host.tell(player,Text::literal(format!("IMPERIAL ODYSSEY — chapter {stage}/4. Complete the Usurper Emperor commission, then use an Imperial Waygate. Realms are adventure zones within existing worlds.")));
        for (i, r) in realm_rules::REALMS.iter().enumerate() {
            host.tell(
                player,
                Text::literal(format!(
                    "{}: /frontier realm {} — {}",
                    r.title,
                    r.key,
                    if i <= stage as usize {
                        "chapter available after emperor"
                    } else {
                        "defeat the preceding realm boss"
                    }
                )),
            );
        }
        host.tell(player,Text::literal("Use /frontier challenge <realm> inside its arena with the matching sigil. Return Waygates take you home. /frontier pets lists companions."));
    }
    fn near_waygate(&self, host: &dyn Host, p: [f64; 3]) -> bool {
        let at = p.map(|v| v.floor() as i32);
        (-4..=4).any(|x| {
            (-3..=3).any(|y| {
                (-4..=4).any(|z| {
                    host.block([at[0] + x, at[1] + y, at[2] + z])
                        == "ashen_frontier:imperial_waygate"
                })
            })
        })
    }
    pub(super) fn adventure_command(
        &self,
        host: &mut dyn Host,
        p: &NativeServerPlayer,
        args: &[&str],
    ) -> bool {
        match args.get(1).copied() {
            Some("odyssey") => {
                self.adventure_guide(host, p.uuid);
                true
            }
            Some("realm") => {
                let Some(index) = args
                    .get(2)
                    .and_then(|key| realm_rules::REALMS.iter().position(|r| r.key == *key))
                else {
                    self.adventure_guide(host, p.uuid);
                    return true;
                };
                if !matches!(p.game_mode, 0 | 2) || p.health <= 0. {
                    tell(
                        host,
                        "Realm travel requires a living Survival or Adventure character.",
                    );
                    return true;
                }
                if !self.near_waygate(host, p.position) {
                    tell(host, "Stand within four blocks of an Imperial Waygate.");
                    return true;
                }
                let allowed = self
                    .world(host, |w| {
                        realm_rules::can_enter(
                            index,
                            *w.campaign.entry(p.uuid).or_default(),
                            w.quests
                                .get(&p.uuid)
                                .is_some_and(|j| j.completed.contains("emperor")),
                        )
                    })
                    .unwrap_or(false);
                if !allowed {
                    tell(
                        host,
                        "This chapter is sealed. Complete emperor, then defeat the realms in order.",
                    );
                    return true;
                }
                let already = self
                    .world(host, |w| w.travel.iter().any(|r| r.player == p.uuid))
                    .unwrap_or(true);
                if already {
                    tell(host, "Your waygate is already preparing a destination.");
                    return true;
                }
                let started = now(host);
                let companion = self.following_pet(host, p.uuid);
                self.world(host, |w| {
                    if !realm_rules::REALMS
                        .iter()
                        .any(|r| realm_rules::inside(r, &p.dimension, p.position))
                    {
                        w.homes.insert(
                            p.uuid,
                            Home {
                                dimension: p.dimension.clone(),
                                position: p.position,
                            },
                        );
                    }
                    w.travel.push(Travel {
                        player: p.uuid,
                        realm: index,
                        started,
                        companion,
                    });
                });
                self.persist(host);
                let r = realm_rules::REALMS[index];
                let [x, _, z] = r.center;
                host.run_command(&format!(
                    "execute in {} run forceload add {} {} {} {}",
                    r.dimension,
                    x - 32,
                    z - 32,
                    x + 31,
                    z + 31
                ));
                tell(
                    host,
                    "The waygate is preparing the realm. You will travel when all arrival chunks are loaded.",
                );
                true
            }
            Some("challenge") => {
                let Some(index) = args
                    .get(2)
                    .and_then(|key| realm_rules::REALMS.iter().position(|r| r.key == *key))
                else {
                    tell(
                        host,
                        "Use /frontier challenge vulcan | dis | astra | elysium",
                    );
                    return true;
                };
                self.realm_challenge(host, p, index);
                true
            }
            _ => false,
        }
    }
    pub(super) fn waygate_click(&self, host: &mut dyn Host, pos: [i32; 3]) -> bool {
        match host.block(pos).as_str() {
            "ashen_frontier:imperial_waygate" => {
                if let Some(p) = host.acting_player() {
                    self.adventure_guide(host, p.uuid);
                }
                true
            }
            "ashen_frontier:return_waygate" => {
                if let Some(p) = host.acting_player() {
                    let home = self
                        .world(host, |w| w.homes.get(&p.uuid).cloned())
                        .flatten();
                    if let Some(h) = home {
                        let companion = self.following_pet(host, p.uuid);
                        let moved = host.run_command(&format!(
                            "execute in {} run tp {} {} {} {}",
                            h.dimension,
                            uuid(p.uuid),
                            h.position[0],
                            h.position[1],
                            h.position[2]
                        ));
                        if moved {
                            if let Some((pet, dimension)) = companion {
                                host.run_command(&format!(
                                    "execute in {dimension} run tp {} {}",
                                    uuid(pet),
                                    uuid(p.uuid)
                                ));
                            }
                        }
                    } else {
                        tell(host, "No saved waygate origin exists for this character.");
                    }
                }
                true
            }
            _ => false,
        }
    }
    pub(super) fn adventure_tick(&self, host: &mut dyn Host, dimension: &str) {
        let t = now(host);
        if t % 10 != 0 {
            return;
        }
        if dimension == "minecraft:overworld" {
            let cleanup = self
                .world(host, |w| w.travel_cleanup.drain(..).collect::<Vec<_>>())
                .unwrap_or_default();
            if !cleanup.is_empty() {
                for index in cleanup {
                    let r = realm_rules::REALMS[index];
                    let [x, _, z] = r.center;
                    host.run_command(&format!(
                        "execute in {} run forceload remove {} {} {} {}",
                        r.dimension,
                        x - 32,
                        z - 32,
                        x + 31,
                        z + 31
                    ));
                }
                self.persist(host);
            }
        }
        let requests = self
            .world(host, |w| {
                w.travel
                    .iter()
                    .filter(|p| realm_rules::REALMS[p.realm].dimension == dimension)
                    .cloned()
                    .collect::<Vec<_>>()
            })
            .unwrap_or_default();
        for request in requests {
            let r = realm_rules::REALMS[request.realm];
            let Some(level) = host.level(dimension) else {
                continue;
            };
            let [x, y, z] = r.center;
            let loaded = (-2..=1).all(|cx| {
                (-2..=1).all(|cz| host.level_is_loaded(level, [x + cx * 16, y, z + cz * 16]))
            });
            if !loaded {
                if t - request.started > 1200 {
                    host.tell(request.player,Text::literal("Realm loading timed out; no travel occurred. Retry the waygate after checking chunk generation."));
                    self.world(host, |w| w.travel.retain(|p| p.player != request.player));
                    host.run_command(&format!(
                        "execute in {} run forceload remove {} {} {} {}",
                        dimension,
                        x - 32,
                        z - 32,
                        x + 31,
                        z + 31
                    ));
                }
                continue;
            }
            let built = self
                .world(host, |w| w.realms_built.contains(r.key))
                .unwrap_or(false);
            let foundation =
                host.level_block(level, [x, y - 4, z]).as_deref() == Some("minecraft:bedrock");
            if !built || !foundation {
                let edit = realm_layout(&r);
                if host.edit_blocks(dimension, &edit).is_err() {
                    continue;
                }
                self.world(host, |w| {
                    w.realms_built.insert(r.key.into());
                });
                self.persist(host);
            }
            if host.run_command(&format!(
                "execute in {} run tp {} {} {} {}",
                dimension,
                uuid(request.player),
                x as f64 + 0.5,
                y + 1,
                z - 16
            )) {
                if let Some((pet, old_dimension)) = &request.companion {
                    host.run_command(&format!(
                        "execute in {old_dimension} run tp {} {}",
                        uuid(*pet),
                        uuid(request.player)
                    ));
                }
                host.tell(request.player,Text::literal(format!("Entered {}. Gather its ore, prepare equipment, then /frontier challenge {}. The Return Waygate is behind you.",r.title,r.key)));
            }
            self.world(host, |w| w.travel.retain(|p| p.player != request.player));
            host.run_command(&format!(
                "execute in {} run forceload remove {} {} {} {}",
                dimension,
                x - 32,
                z - 32,
                x + 31,
                z + 31
            ));
        }
    }
    pub(super) fn realm_challenge(
        &self,
        host: &mut dyn Host,
        p: &NativeServerPlayer,
        index: usize,
    ) {
        let r = realm_rules::REALMS[index];
        if !realm_rules::inside(&r, &p.dimension, p.position) || !matches!(p.game_mode, 0 | 2) {
            tell(host, "Use this ritual inside its realm arena.");
            return;
        }
        let allowed = self
            .world(host, |w| {
                realm_rules::can_enter(
                    index,
                    *w.campaign.entry(p.uuid).or_default(),
                    w.quests
                        .get(&p.uuid)
                        .is_some_and(|j| j.completed.contains("emperor")),
                )
            })
            .unwrap_or(false);
        if !allowed {
            tell(host, "Defeat the preceding campaign chapter first.");
            return;
        }
        let active = self
            .world(host, |w| w.bosses.keys().copied().collect::<Vec<_>>())
            .unwrap_or_default()
            .into_iter()
            .any(|id| {
                host.entity(id).is_some_and(|e| {
                    host.entity_kind(e).as_deref() == Some(r.boss)
                        && host
                            .entity_level(e)
                            .is_some_and(|l| l.dimension() == r.dimension)
                })
            });
        if active {
            tell(host, "This realm's boss is already present.");
            return;
        }
        if host.count_items(r.sigil) < 1 {
            tell(host, format!("Bring the {} challenge sigil.", r.key));
            return;
        }
        let def = boss_rules::boss(r.boss).unwrap();
        let mut n = Compound::new();
        n.insert("CustomName".into(), Tag::String(def.title.into()));
        n.insert("CustomNameVisible".into(), Tag::Byte(1));
        n.insert("PersistenceRequired".into(), Tag::Byte(1));
        if let Some(id) = host.summon(
            r.dimension,
            r.boss,
            [
                r.center[0] as f64 + 0.5,
                (r.center[1] + 1) as f64,
                (r.center[2] + 9) as f64,
            ],
            n,
        ) {
            host.take_items(r.sigil, 1);
            self.world(host, |w| {
                w.bosses.insert(id, boss_rules::Fight::new(now(host)));
            });
            tell(
                host,
                "The challenge begins. Watch the marked attack, then punish the recovery.",
            );
        }
    }
    pub(super) fn campaign_kill(&self, host: &mut dyn Host, player: u128, kind: &str) {
        let advanced = self.world(host, |w| {
            let stage = w.campaign.entry(player).or_default();
            let next = realm_rules::advance(*stage, kind);
            let changed = next != *stage;
            *stage = next;
            changed
        });
        if advanced == Some(true) {
            host.tell(player,Text::literal("Realm conquered. The next Imperial Odyssey chapter is unlocked; /frontier odyssey."));
            self.persist(host);
        }
    }
}
pub(super) fn dimension_ruin(host: &mut dyn Host, dimension: &str, chunk: [i32; 2]) {
    if !matches!(dimension, "minecraft:the_nether" | "minecraft:the_end")
        || rules::hash(chunk[0], chunk[1]) % 47 != 0
    {
        return;
    }
    let Some(level) = host.level(dimension) else {
        return;
    };
    let x = chunk[0] * 16 + 5;
    let z = chunk[1] * 16 + 5;
    let solid = |p: [i32; 3]| {
        host.level_block(level, p).is_some_and(|b| {
            !matches!(
                b.as_str(),
                "minecraft:air" | "minecraft:lava" | "minecraft:water" | "minecraft:bedrock"
            )
        })
    };
    let top = if dimension == "minecraft:the_nether" {
        (48..=104).rev().find(|y| {
            solid([x, *y - 1, z])
                && (0..7).all(|dy| {
                    host.level_block(level, [x, *y + dy, z]).as_deref() == Some("minecraft:air")
                })
        })
    } else {
        host.surface_heights(dimension, &[(x, z)], NativeHeightmap::WorldSurface)
            .ok()
            .and_then(|v| v.first().copied().flatten())
            .filter(|y| *y > 45 && *y < 140)
    };
    let Some(y) = top else {
        return;
    };
    let mut edit = NativeBlockEdit {
        palette: vec![
            if dimension == "minecraft:the_nether" {
                "ashen_frontier:volcanic_tuff".into()
            } else {
                "ashen_frontier:luna_marble".into()
            },
            "ashen_frontier:roman_column".into(),
            "ashen_frontier:crypt_cache".into(),
            "ashen_frontier:ember_lamp".into(),
        ],
        ..Default::default()
    };
    for dx in 0..7 {
        for dz in 0..7 {
            edit.runs.push(NativeBlockRun {
                x: x + dx,
                z: z + dz,
                y: y - 1,
                height: 1,
                surface: None,
                block: 0,
                only: None,
            });
        }
    }
    for (dx, dz) in [(0, 0), (0, 6), (6, 0), (6, 6)] {
        edit.runs.push(NativeBlockRun {
            x: x + dx,
            z: z + dz,
            y,
            height: 5,
            surface: None,
            block: 1,
            only: None,
        });
    }
    for (dx, dz, block) in [(3, 3, 2), (3, 5, 3)] {
        edit.runs.push(NativeBlockRun {
            x: x + dx,
            z: z + dz,
            y,
            height: 1,
            surface: None,
            block,
            only: None,
        });
    }
    let _ = host.edit_blocks(dimension, &edit);
}
fn realm_layout(r: &realm_rules::Realm) -> NativeBlockEdit {
    let mut e = NativeBlockEdit {
        palette: vec![
            "minecraft:air".into(),
            "minecraft:bedrock".into(),
            match r.key {
                "vulcan" => "ashen_frontier:volcanic_tuff",
                "dis" => "ashen_frontier:carved_ashen_stone",
                "astra" => "ashen_frontier:luna_marble",
                _ => "ashen_frontier:sunstone_tiles",
            }
            .into(),
            "ashen_frontier:roman_column".into(),
            r.ore.into(),
            "ashen_frontier:return_waygate".into(),
            "ashen_frontier:ember_lamp".into(),
            "ashen_frontier:roman_concrete".into(),
            "minecraft:grass_block".into(),
            "ashen_frontier:amberwood_log".into(),
            "ashen_frontier:amberwood_leaves[persistent=true]".into(),
            "ashen_frontier:relic_crystal_block".into(),
            "ashen_frontier:relic_beacon".into(),
            "ashen_frontier:crypt_cache".into(),
        ],
        ..Default::default()
    };
    let [cx, y, cz] = r.center;
    let mut put = |x, z, at, height, block| {
        e.runs.push(NativeBlockRun {
            x: cx + x,
            z: cz + z,
            y: at,
            height,
            surface: None,
            block,
            only: None,
        })
    };
    for x in -24i32..=24 {
        for z in -24i32..=24 {
            put(x, z, y + 1, 14, 0);
            put(x, z, y - 4, 1, 1);
            put(x, z, y - 3, 3, 7);
            put(x, z, y, 1, 2);
            if x.abs() == 24 || z.abs() == 24 {
                put(x, z, y + 1, 4, 7);
            }
            if (x.abs() >= 19 || z.abs() >= 19) && rules::hash(x, z) % 4 == 0 {
                put(x, z, y + 1, 2, 4);
            }
            if x % 8 == 0 && z % 8 == 0 {
                put(x, z, y + 1, 1, 6);
            }
        }
    }
    for x in [-8, -4, 4, 8] {
        for z in [4, 16] {
            put(x, z, y + 1, 7, 3);
            put(x, z, y + 8, 1, 2);
        }
    }
    for x in [-16, 16] {
        for z in [-12, 0, 12] {
            match r.key {
                "elysium" => {
                    for dx in -2..=2 {
                        for dz in -2..=2 {
                            put(x + dx, z + dz, y, 1, 8);
                            if dx != 0 || dz != 0 {
                                put(x + dx, z + dz, y + 4, 2, 10);
                            }
                        }
                    }
                    put(x, z, y + 1, 4, 9);
                }
                "astra" => {
                    put(x, z, y + 1, 4, 11);
                    put(x, z, y + 5, 1, 12);
                }
                "dis" => {
                    put(x, z, y + 1, 1, 13);
                    put(x, z + 1, y + 1, 3, 3);
                }
                _ => {
                    put(x, z, y + 1, 2, 7);
                    put(x, z, y + 3, 1, 6);
                }
            }
        }
    }
    put(0, -20, y + 1, 1, 5);
    e
}
