//! Imperium Frontier's native gameplay. Original MIT-licensed implementation.
use horizon_client::mod_api::*;
use std::{
    collections::{BTreeMap, HashMap, VecDeque},
    path::PathBuf,
    sync::Mutex,
    time::{Duration, Instant},
};
mod adventures;
mod boss_rules;
mod bosses;
mod campaign;
mod combat;
mod companion_rules;
mod companions;
mod engineering;
mod mob_models;
mod mob_pose;
mod quests;
mod realm_rules;
mod rules;
mod technology;
mod trees;
use rules::{Progress, level, reward};
const ID: &str = "ashen_frontier_gameplay";
const PREFIX: &str = "ashen_frontier:";
pub fn hooks() -> Box<dyn Hooks> {
    Box::new(Frontier::default())
}
#[derive(Default)]
struct World {
    players: BTreeMap<u128, Progress>,
    harsh: bool,
    pending: VecDeque<[i32; 2]>,
    commands: VecDeque<String>,
    ticks: u64,
    fighters: BTreeMap<u128, combat::Fighter>,
    tree_disabled: std::collections::BTreeSet<u128>,
    quests: BTreeMap<u128, quests::Journal>,
    npcs: BTreeMap<u32, campaign::Npc>,
    bosses: BTreeMap<u32, boss_rules::Fight>,
    campaign: BTreeMap<u128, u8>,
    homes: BTreeMap<u128, adventures::Home>,
    travel: Vec<adventures::Travel>,
    travel_cleanup: Vec<usize>,
    realms_built: std::collections::BTreeSet<String>,
    pet_bonds: BTreeMap<u128, String>,
    pet_entities: BTreeMap<u128, (u32, String, bool)>,
}
#[derive(Default)]
struct Frontier {
    worlds: Mutex<BTreeMap<PathBuf, World>>,
    client: Mutex<ClientCombat>,
    protection: Mutex<HashMap<(std::thread::ThreadId, i32), Instant>>,
}
struct ClientCombat {
    forward: i8,
    strafe: i8,
    armed: Option<Instant>,
    stamina: f32,
    load: String,
    visual: Option<(Instant, f32)>,
}
impl Default for ClientCombat {
    fn default() -> Self {
        Self {
            forward: 0,
            strafe: 0,
            armed: None,
            stamina: 100.,
            load: "Light".into(),
            visual: None,
        }
    }
}
const COMBAT_CHANNEL: &str = "ashen_frontier_gameplay:combat";
fn file(root: &std::path::Path) -> PathBuf {
    root.join("ashen-frontier").join("progress.json")
}
fn load(root: &std::path::Path) -> World {
    let mut w = World {
        harsh: true,
        ..World::default()
    };
    let primary = file(root);
    let recovered = [
        primary.clone(),
        primary.with_extension("pending.json"),
        primary.with_extension("backup.json"),
    ]
    .into_iter()
    .filter_map(|p| std::fs::read_to_string(p).ok())
    .find_map(|text| serde_json::from_str::<serde_json::Value>(&text).ok());
    if let Some(v) = recovered {
        if let Some(rows) = v["quests"].as_object() {
            for (k, v) in rows {
                if let Ok(player) = k.parse() {
                    w.quests.insert(
                        player,
                        quests::Journal {
                            active: v["active"]
                                .as_str()
                                .filter(|id| quests::get(id).is_some())
                                .map(str::to_owned),
                            progress: v["progress"].as_u64().unwrap_or(0).min(u32::MAX as u64)
                                as u32,
                            completed: v["completed"]
                                .as_array()
                                .into_iter()
                                .flatten()
                                .filter_map(|s| s.as_str())
                                .filter(|id| quests::get(id).is_some())
                                .map(str::to_owned)
                                .collect(),
                        },
                    );
                }
            }
        }
        if let Some(rows) = v["odyssey"].as_object() {
            for (k, v) in rows {
                if let Ok(id) = k.parse() {
                    w.campaign.insert(id, v.as_u64().unwrap_or(0).min(4) as u8);
                }
            }
        }
        if let Some(rows) = v["pet_bonds"].as_object() {
            for (k, v) in rows {
                if let (Ok(id), Some(token)) = (k.parse(), v.as_str()) {
                    w.pet_bonds.insert(id, token.to_owned());
                }
            }
        }
        if let Some(rows) = v["homes"].as_object() {
            for (k, v) in rows {
                if let (Ok(id), Some(dim), Some(pos)) =
                    (k.parse(), v["dimension"].as_str(), v["position"].as_array())
                {
                    if matches!(
                        dim,
                        "minecraft:overworld" | "minecraft:the_nether" | "minecraft:the_end"
                    ) && pos.len() == 3
                    {
                        let at = [
                            pos[0].as_f64().unwrap_or(0.),
                            pos[1].as_f64().unwrap_or(80.),
                            pos[2].as_f64().unwrap_or(0.),
                        ];
                        w.homes.insert(
                            id,
                            adventures::Home {
                                dimension: dim.into(),
                                position: at,
                            },
                        );
                    }
                }
            }
        }
        w.travel_cleanup = v["pending_realms"]
            .as_array()
            .into_iter()
            .flatten()
            .filter_map(|v| v.as_u64())
            .filter(|n| *n < 4)
            .map(|v| v as usize)
            .collect();
        w.realms_built = v["realms_built"]
            .as_array()
            .into_iter()
            .flatten()
            .filter_map(|v| v.as_str())
            .filter(|id| realm_rules::REALMS.iter().any(|r| r.key == *id))
            .map(str::to_owned)
            .collect();
        w.harsh = v["harsh"].as_bool().unwrap_or(true);
        if let Some(ps) = v["players"].as_object() {
            for (k, v) in ps {
                if let Ok(id) = k.parse() {
                    w.players.insert(
                        id,
                        Progress {
                            xp: v["xp"].as_u64().unwrap_or(0).min(u32::MAX as u64) as u32,
                            kills: v["kills"].as_u64().unwrap_or(0).min(u32::MAX as u64) as u32,
                            ready_at: v["ready_at"].as_i64().unwrap_or(0),
                        },
                    );
                }
            }
        }
    }
    w
}
fn save(root: &std::path::Path, w: &World) -> Result<(), String> {
    let quest_rows:serde_json::Map<String,serde_json::Value>=w.quests.iter().map(|(player,j)|(player.to_string(),serde_json::json!({"active":j.active,"progress":j.progress,"completed":j.completed}))).collect();
    let players: serde_json::Map<String, serde_json::Value> = w
        .players
        .iter()
        .map(|(id, p)| {
            (
                id.to_string(),
                serde_json::json!({"xp":p.xp,"kills":p.kills,"ready_at":p.ready_at}),
            )
        })
        .collect();
    let target = file(root);
    std::fs::create_dir_all(target.parent().unwrap()).map_err(|e| e.to_string())?;
    let homes: serde_json::Map<String, serde_json::Value> = w
        .homes
        .iter()
        .map(|(id, h)| {
            (
                id.to_string(),
                serde_json::json!({"dimension":h.dimension,"position":h.position}),
            )
        })
        .collect();
    let text = serde_json::to_vec_pretty(
        &serde_json::json!({"version":2,"harsh":w.harsh,"players":players,"quests":quest_rows,"odyssey":w.campaign,"homes":homes,"realms_built":w.realms_built,"pet_bonds":w.pet_bonds,"pending_realms":w.travel.iter().map(|r|r.realm).chain(w.travel_cleanup.iter().copied()).collect::<Vec<_>>()}),
    )
    .map_err(|e| e.to_string())?;
    // A recovery copy survives a failed or interrupted replacement on Windows.
    let temp = target.with_extension("pending.json");
    std::fs::write(&temp, &text).map_err(|e| e.to_string())?;
    if std::fs::read_to_string(&target)
        .ok()
        .and_then(|s| serde_json::from_str::<serde_json::Value>(&s).ok())
        .is_some()
    {
        std::fs::copy(&target, target.with_extension("backup.json")).map_err(|e| e.to_string())?;
    }
    std::fs::copy(&temp, &target).map_err(|e| e.to_string())?;
    let _ = std::fs::remove_file(temp);
    Ok(())
}
fn uuid(id: u128) -> String {
    let s = format!("{id:032x}");
    format!(
        "{}-{}-{}-{}-{}",
        &s[..8],
        &s[8..12],
        &s[12..16],
        &s[16..20],
        &s[20..]
    )
}
fn tell(host: &mut dyn Host, msg: impl Into<String>) {
    host.feedback(Text::literal(msg.into()));
}
fn now(host: &dyn Host) -> i64 {
    host.level("minecraft:overworld")
        .and_then(|level| host.level_game_time(level))
        .or_else(|| host.clock().map(|c| c.game_time))
        .unwrap_or(0)
}
impl Frontier {
    fn combat_status(&self, host: &mut dyn Host, player: u128) {
        let t = now(host);
        if let Some(stamina) = self.world(host, |w| {
            let f = w
                .fighters
                .entry(player)
                .or_insert_with(|| combat::Fighter::new(t));
            f.advance(t);
            f.stamina
        }) {
            let bytes = serde_json::json!({"stamina":stamina}).to_string();
            let _ = host.net_send_to_player(player, COMBAT_CHANNEL, bytes.as_bytes());
        }
    }
    fn dodge_request(&self, host: &mut dyn Host, player: u128, kind: u8, forward: i8, strafe: i8) {
        let Some(p) = host
            .server_players()
            .into_iter()
            .find(|p| p.uuid == player && p.health > 0. && (p.game_mode == 0 || p.game_mode == 2))
        else {
            return;
        };
        let Some(entity) = host.entity(p.entity_id as u32) else {
            return;
        };
        if host.entity_on_ground(entity) != Some(true) {
            host.tell(
                player,
                Text::literal("Combat actions require solid ground."),
            );
            return;
        }
        let Some(living) = host.living(entity) else {
            return;
        };
        let weight = [
            EquipmentSlot::Head,
            EquipmentSlot::Chest,
            EquipmentSlot::Legs,
            EquipmentSlot::Feet,
            EquipmentSlot::MainHand,
            EquipmentSlot::OffHand,
        ]
        .into_iter()
        .filter_map(|s| host.living_equipment(living, s))
        .map(|s| combat::weight(&s.item))
        .sum();
        let tier = combat::load(weight);
        let t = now(host);
        if kind == 1 {
            let weapon = host.living_equipment(living, EquipmentSlot::MainHand);
            if weapon.is_none_or(|s| !combat::weapon(&s.item)) {
                host.tell(
                    player,
                    Text::literal("Hold a sword, axe, trident or mace to prepare a heavy attack."),
                );
                return;
            }
            let answer = self.world(host, |w| {
                w.fighters
                    .entry(player)
                    .or_insert_with(|| combat::Fighter::new(t))
                    .heavy(t)
            });
            if let Some(Err(reason)) = answer {
                host.tell(player, Text::literal(reason));
            } else if answer.is_some() {
                host.tell(
                    player,
                    Text::literal("Heavy attack ready: land a melee hit within 0.8 seconds."),
                );
            }
            self.combat_status(host, player);
            return;
        }
        let backstep = forward == 0 && strafe == 0;
        let result = self.world(host, |w| {
            w.fighters
                .entry(player)
                .or_insert_with(|| combat::Fighter::new(t))
                .dodge(t, tier, backstep)
        });
        match result {
            Some(Ok((speed, _, iframes))) => {
                let kick = combat::kick(p.yaw, forward, strafe, speed);
                if iframes > 0 {
                    self.protection
                        .lock()
                        .unwrap_or_else(|e| e.into_inner())
                        .insert(
                            (std::thread::current().id(), p.entity_id),
                            Instant::now() + Duration::from_millis(iframes as u64 * 50),
                        );
                }
                let stamina = self
                    .world(host, |w| w.fighters[&player].stamina)
                    .unwrap_or(0.);
                let bytes=serde_json::json!({"stamina":stamina,"kick":kick,"load":tier.name(),"lean":if strafe<0{-1.}else{1.}}).to_string();
                let _ = host.net_send_to_player(player, COMBAT_CHANNEL, bytes.as_bytes());
            }
            Some(Err(reason)) => {
                host.tell(player, Text::literal(reason));
                self.combat_status(host, player);
            }
            None => {}
        }
    }
    fn world<T>(&self, host: &dyn Host, f: impl FnOnce(&mut World) -> T) -> Option<T> {
        let root = host.world_dir()?;
        let mut all = self.worlds.lock().unwrap_or_else(|e| e.into_inner());
        let w = all.entry(root.clone()).or_insert_with(|| load(&root));
        Some(f(w))
    }
    fn persist(&self, host: &mut dyn Host) {
        if let Some(root) = host.world_dir() {
            let error = {
                let all = self.worlds.lock().unwrap_or_else(|e| e.into_inner());
                all.get(&root).and_then(|w| save(&root, w).err())
            };
            if let Some(e) = error {
                host.broadcast(Text::literal(format!(
                    "Imperium Frontier could not save progression: {e}"
                )));
            }
        }
    }
    fn ability(&self, host: &mut dyn Host) {
        let Some(p) = host.acting_player() else {
            return;
        };
        if p.game_mode != 0 && p.game_mode != 2 {
            tell(host, "Abilities require survival or adventure mode.");
            return;
        }
        let t = now(host);
        let progress = self
            .world(host, |w| *w.players.entry(p.uuid).or_default())
            .unwrap_or_default();
        if level(progress.xp) < 2 {
            tell(host, "Reach rank 2 (40 glory) to awaken relic abilities.");
            return;
        }
        if progress.ready_at > t {
            tell(
                host,
                format!("Relic recharging: {}s", (progress.ready_at - t + 19) / 20),
            );
            return;
        }
        let held = host.held().map(|v| v.0).unwrap_or_default();
        let effect = if held == "ashen_frontier:storm_focus" {
            "storm"
        } else if held == "ashen_frontier:warding_charm" {
            "ward"
        } else {
            tell(
                host,
                "Hold a Signum of Jupiter or Laurel Talisman to use an ability.",
            );
            return;
        };
        if host.count_items("ashen_frontier:relic_fragment") == 0 {
            tell(host, "An ability costs one Ancient Tessera.");
            return;
        }
        if host.take_items("ashen_frontier:relic_fragment", 1) != 1 {
            return;
        }
        self.world(host, |w| {
            w.players.entry(p.uuid).or_default().ready_at = t + 400;
            let who = uuid(p.uuid);
            for (e, d, a) in if effect == "storm" {
                [("speed", 8, 1), ("strength", 8, 0)]
            } else {
                [("resistance", 8, 0), ("regeneration", 5, 0)]
            } {
                w.commands
                    .push_back(format!("effect give {who} minecraft:{e} {d} {a} true"));
            }
        });
        tell(
            host,
            format!(
                "{} awakened. 20s cooldown.",
                if effect == "storm" {
                    "Signum of Jupiter"
                } else {
                    "Laurel Talisman"
                }
            ),
        );
        self.persist(host);
    }
    fn summon_boss(&self, host: &mut dyn Host, which: &str) {
        let Some(p) = host.acting_player() else {
            return;
        };
        if p.game_mode != 0 && p.game_mode != 2 {
            tell(host, "Boss rituals require survival or adventure mode.");
            return;
        }
        let (item, kind, name, rank) = if which == "cinder" {
            ("cinder_sigil", "cinder_sovereign", "Usurper Emperor", 3)
        } else {
            ("grave_sigil", "crypt_warden", "Fallen Centurion", 2)
        };
        let xp = self
            .world(host, |w| w.players.entry(p.uuid).or_default().xp)
            .unwrap_or(0);
        if level(xp) < rank {
            tell(host, format!("This ritual requires rank {rank}."));
            return;
        }
        let item = format!("{PREFIX}{item}");
        if host.count_items(&item) < 1 {
            tell(host, format!("You need a {}.", item.replace('_', " ")));
            return;
        }
        let angle = (p.yaw as f64).to_radians();
        let at = [
            p.position[0] - angle.sin() * 5.,
            p.position[1],
            p.position[2] + angle.cos() * 5.,
        ];
        // Require open space above solid ground: a refused summon never consumes the sigil.
        let b = at.map(|x| x.floor() as i32);
        if host.block(b) != "minecraft:air"
            || host.block([b[0], b[1] + 1, b[2]]) != "minecraft:air"
            || matches!(
                host.block([b[0], b[1] - 1, b[2]]).as_str(),
                "minecraft:air" | "minecraft:water" | "minecraft:lava"
            )
        {
            tell(
                host,
                "The ritual needs open, level ground five blocks ahead.",
            );
            return;
        }
        let mut tag = Compound::new();
        tag.insert("CustomName".into(), Tag::String(name.into()));
        tag.insert("CustomNameVisible".into(), Tag::Byte(1));
        tag.insert("PersistenceRequired".into(), Tag::Byte(1));
        if host
            .summon(&p.dimension, &format!("{PREFIX}{kind}"), at, tag)
            .is_some()
        {
            host.take_items(&item, 1);
            tell(host, format!("{name} has answered your challenge."));
        } else {
            tell(host, "The ritual failed; your sigil was kept.");
        }
    }
}
impl Hooks for Frontier {
    fn block_entity(
        &self,
        _host: &mut dyn Host,
        e: &mut BlockEntityEvent<'_>,
    ) -> Option<(String, Compound)> {
        engineering::make(e.block)
    }
    fn right_click_block(&self, host: &mut dyn Host, e: &mut RightClickBlockEvent) -> Flow {
        if self.waygate_click(host, e.pos) || self.engineering_click(host, e.pos) {
            Flow::Cancel
        } else {
            Flow::Continue
        }
    }
    fn player_tick(&self, host: &mut dyn Host, _e: &mut PlayerTickEvent) {
        self.engineered_road(host);
    }
    fn left_click_block(&self, host: &mut dyn Host, e: &mut LeftClickBlockEvent) -> Flow {
        if host.acting_player().is_some_and(|p| p.game_mode == 0)
            && engineering::is_station(&host.block(e.pos))
            && host
                .mod_block_entity(e.pos)
                .is_some_and(|e| e.nbt.contains_key(&"Job".into()))
        {
            tell(
                host,
                "Collect this station's reserved batch before breaking it.",
            );
            Flow::Cancel
        } else {
            Flow::Continue
        }
    }
    fn standalone_models(&self, e: &mut StandaloneModelsEvent<'_>) {
        mob_models::register(e);
    }
    fn mob_submit(&self, host: &dyn Host, e: &mut MobSubmitEvent<'_>) -> Flow {
        mob_models::draw(host, e)
    }
    fn register_goals(&self, e: &mut RegisterGoalsEvent<'_>) {
        if companions::pet(&e.mob.kind.id) || boss_rules::boss(&e.mob.kind.id).is_some() {
            let pet = companions::pet(&e.mob.kind.id);
            let kind = std::sync::Arc::make_mut(&mut e.mob.kind);
            if pet {
                let (species, width, height) = if kind.id.ends_with("mars_boar") {
                    (horizon_client::mobs::Species::Pig, 0.9, 1.0)
                } else if kind.id.ends_with("jupiter_eagle") {
                    (horizon_client::mobs::Species::Parrot, 0.8, 0.6)
                } else {
                    (horizon_client::mobs::Species::Wolf, 0.65, 0.85)
                };
                kind.species = species;
                kind.width = width;
                kind.height = height;
                kind.eye_height = height * 0.8;
            } else {
                kind.species = horizon_client::mobs::Species::Husk;
            }

            kind.flags.burns_in_day = false;
            kind.flags.fire_immune = !pet;
            kind.flags.undead = !pet;
            kind.flags.animal = pet;
            kind.flags.fall_immune = kind.id.ends_with("jupiter_eagle");
            kind.flags.omnidirectional = kind.id.ends_with("jupiter_eagle");
            kind.brain = if pet {
                horizon_client::mobs::Brain::Passive
            } else {
                horizon_client::mobs::Brain::Zombie
            };
            e.mob.ai.goals.clear();
            e.mob.ai.targets.clear();
            e.mob.attrs.attack_damage = 0.;
            return;
        }
        if e.mob.kind.id != "ashen_frontier:legionary_guard" {
            return;
        }
        use horizon_client::mobs::{
            Species,
            goals::{MeleeAttack, NearestTarget},
        };
        e.mob.ai.goals.clear();
        e.mob.ai.targets.clear();
        e.mob.attrs.attack_damage = 7.;
        e.mob.attrs.follow_range = 24.;
        e.mob.ai.goals.add(1, MeleeAttack::new(1.1, true));
        e.mob.ai.targets.add(
            0,
            NearestTarget::species(
                &[
                    Species::Zombie,
                    Species::Skeleton,
                    Species::Spider,
                    Species::Creeper,
                ],
                true,
            ),
        );
    }
    fn interact_entity(&self, host: &mut dyn Host, e: &mut InteractEntityEvent<'_>) -> Flow {
        if self.pet_interact(host, e.entity as u32, e.kind)
            || self.npc_interaction(host, e.entity as u32, e.kind)
        {
            Flow::Cancel
        } else {
            Flow::Continue
        }
    }
    fn item_crafted(&self, host: &mut dyn Host, e: &mut ItemCraftedEvent<'_>) {
        self.quest_event(host, e.player, "craft", &e.stack.item, e.stack.count);
    }
    fn entity_leave_level(&self, host: &mut dyn Host, e: &mut EntityLeaveLevelEvent<'_>) {
        self.world(host, |w| {
            w.npcs.remove(&e.entity);
            w.bosses.remove(&e.entity);
        });
    }
    fn entity_join_level(&self, host: &mut dyn Host, e: &mut EntityJoinLevelEvent<'_>) -> Flow {
        if e.loaded_from_disk {
            return Flow::Continue;
        }
        if boss_rules::boss(e.kind).is_some() {
            return Flow::Continue;
        }
        let tier = match e.kind {
            "ashen_frontier:ashbound"
            | "ashen_frontier:crypt_warden"
            | "ashen_frontier:bandit"
            | "ashen_frontier:raider"
            | "ashen_frontier:cultist"
            | "ashen_frontier:legionary_guard" => "ember",
            "ashen_frontier:cinder_sovereign" => "relic",
            _ => return Flow::Continue,
        };
        if let Some(living) = host.entity(e.entity).and_then(|entity| host.living(entity)) {
            for (slot, piece) in [
                (EquipmentSlot::Head, "helmet"),
                (EquipmentSlot::Chest, "chestplate"),
                (EquipmentSlot::Legs, "leggings"),
                (EquipmentSlot::Feet, "boots"),
            ] {
                host.living_set_equipment(
                    living,
                    slot,
                    Some(ItemStack::new(&format!("ashen_frontier:{tier}_{piece}"), 1)),
                );
            }
            host.living_set_equipment(
                living,
                EquipmentSlot::MainHand,
                Some(ItemStack::new(&format!("ashen_frontier:{tier}_sword"), 1)),
            );
            host.living_set_equipment(
                living,
                EquipmentSlot::OffHand,
                Some(ItemStack::new("ashen_frontier:legionary_scutum", 1)),
            );
        }
        Flow::Continue
    }
    fn loot_drops(&self, host: &mut dyn Host, e: &mut LootDropsEvent<'_>) {
        let context = e.context;
        if context.used || context.explosion.is_some() {
            return;
        }
        let (Some(player), Some((root, _))) = (context.player, context.block) else {
            return;
        };
        let Some(actor) = host
            .acting_player()
            .filter(|p| p.uuid == player && p.game_mode == 0)
        else {
            return;
        };
        if host.sneaking()
            || self
                .world(host, |w| w.tree_disabled.contains(&player))
                .unwrap_or(true)
        {
            return;
        }
        let Some(log_name) = context
            .table
            .strip_prefix("minecraft:blocks/")
            .map(|s| format!("minecraft:{s}"))
        else {
            return;
        };
        let Some(species) = trees::species(&log_name) else {
            return;
        };
        if !trees::ground(&host.block([root[0], root[1] - 1, root[2]])) {
            return;
        }
        let Some(mut axe) = host.equipment(EquipmentSlot::MainHand) else {
            return;
        };
        let Some(max_damage) = trees::axe_durability(&axe.item) else {
            return;
        };
        let budget = max_damage.saturating_sub(axe.damage).saturating_sub(1) as usize;
        if budget == 0 {
            return;
        }
        let namespace = log_name.split_once(':').unwrap().0;
        let leaves = format!("{namespace}:{species}_leaves");
        let plan = trees::scan(root, |p| {
            if p == root {
                return trees::Block::Log;
            }
            let b = host.block(p);
            if b == log_name {
                trees::Block::Log
            } else if b == leaves
                && host.block_property(p, "persistent").as_deref() == Some("false")
            {
                trees::Block::Leaf
            } else {
                trees::Block::Other
            }
        });
        let Some(plan) = plan else {
            return;
        };
        let Some(living) = host
            .entity(actor.entity_id as u32)
            .and_then(|e| host.living(e))
        else {
            return;
        };
        let mut count = 0;
        for p in plan.into_iter().filter(|p| *p != root).take(budget) {
            if host.block(p) != log_name {
                continue;
            }
            if host.destroy_block(p, Some(&axe), false).is_some() {
                count += 1;
            }
        }
        if count > 0 {
            axe.damage = axe.damage.saturating_add(count);
            host.living_set_equipment(living, EquipmentSlot::MainHand, Some(axe));
            host.tell(
                player,
                Text::literal(format!(
                    "Tree felling: {count} additional logs. Sneak to chop one block."
                )),
            );
        }
    }
    fn movement_input(&self, _host: &dyn Host, e: &mut MovementInputEvent) {
        let mut c = self.client.lock().unwrap_or_else(|e| e.into_inner());
        c.forward = if e.forward > 0.1 {
            1
        } else if e.forward < -0.1 {
            -1
        } else {
            0
        };
        c.strafe = if e.strafe > 0.1 {
            1
        } else if e.strafe < -0.1 {
            -1
        } else {
            0
        };
    }
    fn net_from_client(&self, host: &mut dyn Host, e: &mut NetFromClientEvent<'_>) {
        if e.channel != COMBAT_CHANNEL
            || e.data.len() != 3
            || e.data[0] > 1
            || e.data[1] > 2
            || e.data[2] > 2
        {
            return;
        }
        self.dodge_request(
            host,
            e.player,
            e.data[0],
            e.data[1] as i8 - 1,
            e.data[2] as i8 - 1,
        );
    }
    fn net_from_server(&self, host: &mut dyn Host, e: &mut NetFromServerEvent<'_>) {
        if e.channel != COMBAT_CHANNEL || e.data.len() > 512 {
            return;
        }
        let Ok(v) = serde_json::from_slice::<serde_json::Value>(e.data) else {
            return;
        };
        let kick = v["kick"].as_array().filter(|a| a.len() == 3).and_then(|a| {
            let mut out = [0f32; 3];
            for i in 0..3 {
                out[i] = a[i].as_f64()? as f32;
                if !out[i].is_finite() || out[i].abs() > 1. {
                    return None;
                }
            }
            Some(out)
        });
        {
            let mut c = self.client.lock().unwrap_or_else(|e| e.into_inner());
            if let Some(stamina) = v["stamina"].as_f64().filter(|s| s.is_finite()) {
                c.stamina = (stamina as f32).clamp(0., 100.);
            }
            if let Some(load) = v["load"]
                .as_str()
                .filter(|s| matches!(*s, "Light" | "Medium" | "Heavy"))
            {
                c.load = load.into();
            }
            if kick.is_some() {
                c.visual = Some((
                    Instant::now(),
                    v["lean"].as_f64().unwrap_or(1.).clamp(-1., 1.) as f32,
                ));
            }
        }
        if let Some(kick) = kick {
            if host.playing() {
                host.push_player(kick);
            }
        }
    }
    fn camera_shake(&self, host: &dyn Host, e: &mut CameraShakeEvent<'_>) {
        if !host.playing() || host.setting(ID, "roll_camera").as_deref() == Some("off") {
            return;
        }
        let visual = self.client.lock().unwrap_or_else(|e| e.into_inner()).visual;
        if let Some((started, side)) = visual {
            let t = started.elapsed().as_secs_f32() / 0.4;
            if t < 1. {
                let wave = (t * std::f32::consts::PI).sin();
                e.shake.roll += 8. * side * wave;
                e.shake.offset[1] -= 0.22 * wave;
            }
        }
    }
    fn client_level_unload(&self, _host: &mut dyn Host, _e: &mut ClientLevelUnloadEvent<'_>) {
        *self.client.lock().unwrap_or_else(|e| e.into_inner()) = ClientCombat::default();
    }
    fn player_died(&self, host: &mut dyn Host, e: &mut PlayerDiedEvent<'_>) {
        let t = now(host);
        self.world(host, |w| {
            w.fighters.insert(e.player, combat::Fighter::new(t));
        });
    }
    fn server_stopping(&self, host: &mut dyn Host, _e: &mut ServerStoppingEvent) {
        self.persist(host);
        if let Some(root) = host.world_dir() {
            self.worlds
                .lock()
                .unwrap_or_else(|e| e.into_inner())
                .remove(&root);
        }
        self.protection
            .lock()
            .unwrap_or_else(|e| e.into_inner())
            .clear();
    }
    fn living_incoming_damage_v2(
        &self,
        host: &mut dyn Host,
        e: &mut LivingIncomingDamageV2Event<'_>,
    ) -> Flow {
        if e.weapon.is_some_and(|s| combat::weapon(&s.item)) {
            if let Some(player) = host
                .acting_player()
                .filter(|p| p.entity_id == e.causing)
                .or_else(|| {
                    host.server_players()
                        .into_iter()
                        .find(|p| p.entity_id == e.causing)
                })
            {
                let t = now(host);
                match self.world(host, |w| {
                    w.fighters
                        .entry(player.uuid)
                        .or_insert_with(|| combat::Fighter::new(t))
                        .attack(t)
                }) {
                    Some(Ok(multiplier)) => e.amount *= multiplier,
                    Some(Err(_)) => return Flow::Cancel,
                    None => {}
                }
            }
        }
        if boss_rules::boss(e.kind).is_some() {
            let recovery = self
                .world(host, |w| {
                    w.bosses
                        .get(&(e.entity as u32))
                        .is_some_and(|f| f.phase == boss_rules::Phase::Recovery)
                })
                .unwrap_or(false);
            e.amount *= if recovery { 1.25 } else { 0.65 };
        }
        if let Some(weapon) = e.weapon {
            e.amount += match weapon.item.as_ref() {
                "ashen_frontier:ember_sword" => 1.0,
                "ashen_frontier:relic_sword" => 3.0,
                "ashen_frontier:aquila_sword" => 8.0,
                "ashen_frontier:cindersteel_sword" => 3.,
                "ashen_frontier:stygian_sword" => 4.,
                "ashen_frontier:aetherium_sword" => 5.,
                "ashen_frontier:elysian_sword" => 6.,
                _ => 0.0,
            };
        }
        Flow::Continue
    }
    fn living_incoming_damage(&self, e: &mut LivingIncomingDamageEvent<'_>) -> Flow {
        if e.kind == "minecraft:player" && combat::dodgeable(e.damage_type) {
            let mut windows = self.protection.lock().unwrap_or_else(|e| e.into_inner());
            let t = Instant::now();
            windows.retain(|_, until| *until > t);
            if windows.contains_key(&(std::thread::current().id(), e.entity)) {
                return Flow::Cancel;
            }
        }
        if boss_rules::boss(e.kind).is_some()
            && matches!(
                e.damage_type,
                "minecraft:on_fire"
                    | "minecraft:in_fire"
                    | "minecraft:lava"
                    | "on_fire"
                    | "in_fire"
                    | "lava"
            )
        {
            Flow::Cancel
        } else {
            Flow::Continue
        }
    }
    fn mods(&self, _host: &mut dyn Host, e: &mut ModsEvent<'_>) {
        e.mods.push(NativeMod {
            id: ID.into(),
            title: "Imperium Frontier 0.7.0".into(),
            description: "Roman provinces, legionary combat, villas and catacombs".into(),
            keys: vec![
                [
                    "roll".into(),
                    "Directional dodge roll (tap)".into(),
                    "key.keyboard.b".into(),
                ],
                [
                    "backstep".into(),
                    "Backstep".into(),
                    "key.keyboard.x".into(),
                ],
                [
                    "heavy".into(),
                    "Prepare heavy attack".into(),
                    "key.keyboard.v".into(),
                ],
                [
                    "ability".into(),
                    "Divine blessing".into(),
                    "key.keyboard.r".into(),
                ],
                [
                    "guide".into(),
                    "Field guide".into(),
                    "key.keyboard.g".into(),
                ],
            ],
        });
    }
    fn settings(&self, host: &mut dyn Host, e: &mut SettingsEvent<'_>) {
        if e.mod_id == ID {
            e.buttons.push(format!(
                "Expedition HUD: {}",
                if host.setting(ID, "hud").as_deref() == Some("off") {
                    "OFF"
                } else {
                    "ON"
                }
            ));
            e.buttons.push(format!(
                "Dodge camera lean: {}",
                if host.setting(ID, "roll_camera").as_deref() == Some("off") {
                    "OFF"
                } else {
                    "ON"
                }
            ));
        }
    }
    fn settings_click(&self, host: &mut dyn Host, e: &mut SettingsClickEvent<'_>) {
        if e.mod_id == ID && e.button == 0 {
            let v = if host.setting(ID, "hud").as_deref() == Some("off") {
                "on"
            } else {
                "off"
            };
            host.set_setting(ID, "hud", v);
        }
        if e.mod_id == ID && e.button == 1 {
            let v = if host.setting(ID, "roll_camera").as_deref() == Some("off") {
                "on"
            } else {
                "off"
            };
            host.set_setting(ID, "roll_camera", v);
        }
    }
    fn key(&self, host: &mut dyn Host, e: &mut KeyEvent<'_>) {
        let roll = host.mod_key(ID, "roll", "key.keyboard.b");
        if e.key == roll {
            let request = {
                let mut c = self.client.lock().unwrap_or_else(|e| e.into_inner());
                if !host.playing() {
                    c.armed = None;
                    None
                } else if e.pressed {
                    c.armed.get_or_insert_with(Instant::now);
                    None
                } else {
                    c.armed
                        .take()
                        .filter(|t| t.elapsed() < Duration::from_millis(350))
                        .map(|_| [0, (c.forward + 1) as u8, (c.strafe + 1) as u8])
                }
            };
            if let Some(data) = request {
                let _ = host.net_send_to_server(COMBAT_CHANNEL, &data);
            }
            return;
        }
        if !e.pressed || !host.playing() {
            return;
        }
        if e.key == host.mod_key(ID, "backstep", "key.keyboard.x") {
            let _ = host.net_send_to_server(COMBAT_CHANNEL, &[0, 1, 1]);
        }
        if e.key == host.mod_key(ID, "heavy", "key.keyboard.v") {
            let _ = host.net_send_to_server(COMBAT_CHANNEL, &[1, 1, 1]);
        }
        if e.key == host.mod_key(ID, "ability", "key.keyboard.r") {
            let _ = host.send_chat("/frontier ability");
        }
        if e.key == host.mod_key(ID, "guide", "key.keyboard.g") {
            let _ = host.send_chat("/frontier guide");
        }
    }
    fn hud(&self, host: &mut dyn Host, e: &mut HudEvent<'_>) {
        if host.setting(ID, "hud").as_deref() == Some("off") {
            return;
        }
        let Some(p) = host.player() else { return };
        let (stamina, load) = {
            let c = self.client.lock().unwrap_or_else(|e| e.into_inner());
            (c.stamina, c.load.clone())
        };
        let lines = [
            "IMPERIUM FRONTIER".to_string(),
            format!("XYZ {:.0} / {:.0} / {:.0}", p.x, p.y, p.z),
            "R: relic ability | G: field guide".into(),
            format!("Stamina {:.0}/100 | {} load", stamina, load),
            "B: dodge | X: backstep | V: heavy".into(),
        ];
        let w = lines
            .iter()
            .map(|l| host.text_width(l))
            .fold(0f32, f32::max)
            + 12.;
        let (x, y) = e.corners.place(Corner::TopRight, w, 70.);
        host.fill(e.batch, [x, y, w, 70.], 0xb52a1717);
        host.fill(e.batch, [x + 6., y + 62., w - 12., 3.], 0xff444444);
        host.fill(
            e.batch,
            [x + 6., y + 62., (w - 12.) * stamina / 100., 3.],
            0xff69b886,
        );
        for (i, line) in lines.iter().enumerate() {
            host.text(
                e.batch,
                line,
                [x + 6., y + 5. + i as f32 * 11.],
                if i == 0 { 0xf0bb73 } else { 0xd0d9dc },
                true,
            );
        }
    }
    fn register_commands(&self, _host: &mut dyn Host, e: &mut RegisterCommandsEvent<'_>) {
        for usage in [
            "frontier",
            "frontier guide",
            "frontier stats",
            "frontier ability",
            "frontier trees",
            "frontier quests",
            "frontier tech",
            "frontier odyssey",
            "frontier realm <key:word>",
            "frontier challenge <key:word>",
            "frontier pets",
            "frontier pet adopt <id:word>",
            "frontier pet release",
            "frontier quest accept <id:word>",
            "frontier quest claim",
            "frontier quest abandon",
            "frontier trade <offer:word>",
            "frontier boss crypt",
            "frontier boss cinder",
        ] {
            e.commands.push(NativeCommand::new(usage));
        }
        e.commands
            .push(NativeCommand::op("frontier difficulty <mode:word>", 2));
    }
    fn perform_command(&self, host: &mut dyn Host, e: &mut PerformCommandEvent<'_>) -> Flow {
        let a: Vec<_> = e.command.split_whitespace().collect();
        if a.first() != Some(&"frontier") {
            return Flow::Continue;
        }
        if a.get(1) == Some(&"tech") {
            self.tech_guide(host, e.player.uuid);
            return Flow::Cancel;
        }
        if self.adventure_command(host, e.player, &a)
            || self.pet_command(host, e.player, &a)
            || self.campaign_command(host, e.player, &a)
        {
            return Flow::Cancel;
        }
        match a.get(1).copied() {
            Some("trees") => {
                let enabled = self
                    .world(host, |w| {
                        if w.tree_disabled.remove(&e.player.uuid) {
                            true
                        } else {
                            w.tree_disabled.insert(e.player.uuid);
                            false
                        }
                    })
                    .unwrap_or(false);
                tell(
                    host,
                    format!(
                        "Tree felling: {} (this session). Sneak to bypass.",
                        if enabled { "ON" } else { "OFF" }
                    ),
                );
            }
            Some("stats") => {
                let p = self
                    .world(host, |w| *w.players.entry(e.player.uuid).or_default())
                    .unwrap_or_default();
                let remaining = (p.ready_at - now(host)).max(0) / 20;
                tell(
                    host,
                    format!(
                        "Rank {} | {} glory | {} hostile kills | relic cooldown {}s",
                        rules::rank_name(p.xp),
                        p.xp,
                        p.kills,
                        remaining
                    ),
                );
            }
            Some("ability") => self.ability(host),
            Some("boss") => match a.get(2).copied() {
                Some("crypt") => self.summon_boss(host, "crypt"),
                Some("cinder") => self.summon_boss(host, "cinder"),
                _ => tell(host, "Use /frontier boss crypt or /frontier boss cinder"),
            },
            Some("difficulty") => {
                if e.player.permission < 2 {
                    tell(host, "Operator permission required.");
                    return Flow::Cancel;
                }
                match a.get(2).copied() {
                    Some("harsh") | Some("normal") => {
                        let harsh = a[2] == "harsh";
                        self.world(host, |w| w.harsh = harsh);
                        self.persist(host);
                        tell(host, format!("Expedition hunger: {}", a[2]));
                    }
                    _ => tell(host, "Use /frontier difficulty harsh or normal"),
                }
            }
            _ => {
                for line in [
                    "Settlements: seek prefects and quartermasters for 20 commissions. Right-click NPCs or use /frontier quests. Merchants trade in denarii.",
                    "Tree felling: axe-chop the bottom log of a leafy tree. Sneak for single logs; /frontier trees toggles it for this session.",
                    "Combat: tap B + movement for a dodge; idle B or X backsteps. Armour weight changes roll cost and recovery.",
                    "Stamina recovers after a short delay. V prepares a heavy strike: hit within 0.8 seconds. Dodge protection never blocks falls, lava or starvation.",
                    "Imperium Frontier: mine Orichalcum Ore with an iron pick; smelt Raw Orichalcum, then temper ingots with blaze powder.",
                    "Explore newly generated land for ruins and underground crypts. Break their caches for relic fragments and thread.",
                    "Earn glory from hostile kills. Ranks: 0 / 40 / 140 / 350 / 700. At rank 2 hold a Laurel Talisman or Signum of Jupiter and press R.",
                    "Abilities cost 1 Ancient Tessera and recharge in 20 seconds. G opens this guide; /frontier stats shows progression.",
                    "Craft a Centurion Challenge Seal and challenge /frontier boss crypt at rank 2. Its seal crafts a Imperial Challenge Seal for the rank 3 Sovereign.",
                    "Furniture is decorative. Harsh hunger is on by default; an operator can use /frontier difficulty normal.",
                ] {
                    tell(host, line);
                }
            }
        }
        Flow::Cancel
    }
    fn player_logged_in(&self, host: &mut dyn Host, e: &mut PlayerLoggedInEvent<'_>) {
        host.tell(e.player,Text::literal("Welcome to Imperium Frontier. Press G or use /frontier guide. Explore fresh chunks for ruins."));
    }
    fn mob_killed(&self, host: &mut dyn Host, e: &mut MobKilledEvent<'_>) {
        self.campaign_kill(host, e.player, e.kind);
        self.quest_event(host, e.player, "kill", e.kind, 1);
        let r = reward(e.kind);
        if r == 0 {
            return;
        }
        let rank = self.world(host, |w| {
            let p = w.players.entry(e.player).or_default();
            let old = level(p.xp);
            p.xp = p.xp.saturating_add(r);
            p.kills = p.kills.saturating_add(1);
            (old, level(p.xp), p.xp)
        });
        if let Some((old, new, xp)) = rank {
            host.tell(e.player, Text::literal(format!("+{r} glory ({xp})")));
            if new > old {
                host.tell(
                    e.player,
                    Text::literal(format!("Imperial rank {new} reached!")),
                );
            }
        }
        self.persist(host);
    }
    fn use_item(&self, host: &mut dyn Host, e: &mut UseItemEvent<'_>) -> Flow {
        if let Some(index) = realm_rules::REALMS
            .iter()
            .position(|r| r.sigil == e.stack.item.as_ref())
        {
            if let Some(p) = host.acting_player() {
                self.realm_challenge(host, &p, index);
            }
            return Flow::Cancel;
        }
        match e.stack.item.as_ref() {
            "ashen_frontier:warding_charm" | "ashen_frontier:storm_focus" => {
                self.ability(host);
                Flow::Cancel
            }
            "ashen_frontier:grave_sigil" => {
                self.summon_boss(host, "crypt");
                Flow::Cancel
            }
            "ashen_frontier:cinder_sigil" => {
                self.summon_boss(host, "cinder");
                Flow::Cancel
            }
            _ => Flow::Continue,
        }
    }
    fn food_level_changed(&self, host: &mut dyn Host, e: &mut FoodLevelChangedEvent<'_>) -> Flow {
        if e.to < e.from && self.world(host, |w| w.harsh).unwrap_or(false) {
            e.to = (e.to - 1).max(0);
        }
        Flow::Continue
    }
    fn potential_spawns(&self, _host: &dyn Host, e: &mut PotentialSpawnsEvent<'_>) -> Flow {
        if e.category == "monster" && e.dimension == "minecraft:overworld" {
            for (entity, weight) in [("bandit", 8), ("raider", 3), ("cultist", 3)] {
                e.entries.push(SpawnEntry {
                    entity: format!("ashen_frontier:{entity}"),
                    weight,
                    min: 1,
                    max: 2,
                    constant: false,
                });
            }
            e.entries.push(SpawnEntry {
                entity: "ashen_frontier:ashbound".into(),
                weight: 12,
                min: 1,
                max: 2,
                constant: false,
            });
        }
        Flow::Continue
    }
    fn chunk_load(&self, host: &mut dyn Host, e: &mut ChunkLoadEvent<'_>) {
        if e.new {
            adventures::dimension_ruin(host, e.dimension, e.chunk);
        }
        if e.new && e.dimension == "minecraft:overworld" {
            self.world(host, |w| w.pending.push_back(e.chunk));
        }
    }
    fn level_tick_post(&self, host: &mut dyn Host, e: &mut LevelTickPostEvent<'_>) {
        self.adventure_tick(host, e.dimension);
        if e.dimension != "minecraft:overworld" {
            return;
        }
        let work = self.world(host, |w| {
            w.ticks = w.ticks.wrapping_add(1);
            (
                w.pending.pop_front(),
                w.commands.drain(..).collect::<Vec<_>>(),
                w.ticks % 20 == 0,
            )
        });
        let Some((chunk, cmds, status)) = work else {
            return;
        };
        for command in cmds {
            host.run_command(&command);
        }
        if let Some(c) = chunk {
            generate(host, c);
        }
        if status {
            for p in host.server_players() {
                if p.game_mode != 0 && p.game_mode != 2 {
                    continue;
                }
                let engaged = self
                    .world(host, |w| w.bosses.keys().copied().collect::<Vec<_>>())
                    .unwrap_or_default()
                    .into_iter()
                    .any(|id| {
                        host.entity(id).is_some_and(|entity| {
                            host.entity_level(entity)
                                .is_some_and(|l| l.dimension() == p.dimension)
                                && host.entity_position(entity).is_some_and(|at| {
                                    at.into_iter()
                                        .zip(p.position)
                                        .map(|(a, b)| (a - b).powi(2))
                                        .sum::<f64>()
                                        < 32. * 32.
                                })
                        })
                    });
                if engaged {
                    self.combat_status(host, p.uuid);
                    continue;
                }
                let value = self
                    .world(host, |w| *w.players.entry(p.uuid).or_default())
                    .unwrap_or_default();
                host.action_bar(
                    p.uuid,
                    Text::literal(format!(
                        "Imperial rank {} | {} glory | relic {}",
                        rules::rank_name(value.xp),
                        value.xp,
                        if value.ready_at > now(host) {
                            format!("{}s", (value.ready_at - now(host) + 19) / 20)
                        } else {
                            "ready".into()
                        }
                    )),
                );
                self.combat_status(host, p.uuid);
            }
        }
    }
    fn living_death(&self, host: &mut dyn Host, e: &mut LivingDeathEvent<'_>) -> Flow {
        self.pet_died(host, e.entity, e.kind);
        Flow::Continue
    }
    fn entity_tick_listened(&self, _host: &mut dyn Host, e: &mut EntityTickListenedEvent) {
        e.listened = true;
    }
    fn entity_tick_post(&self, host: &mut dyn Host, e: &mut EntityTickPostEvent<'_>) {
        if self.pet_tick(host, e) {
            return;
        }
        if campaign::is_npc(e.kind) {
            if now(host) % 20 == 0 {
                self.track_npc(host, e.entity, e.kind);
            }
            return;
        }
        self.boss_tick(host, e);
    }
}
fn generate(host: &mut dyn Host, chunk: [i32; 2]) {
    let dimension = "minecraft:overworld";
    let [cx, cz] = chunk;
    let x = cx * 16;
    let z = cz * 16;
    let h = rules::hash(cx, cz);
    imperial_surface(host, chunk);
    let mut edit = NativeBlockEdit {
        palette: vec![
            "ashen_frontier:ember_ore".into(),
            "ashen_frontier:deep_ember_ore".into(),
        ],
        filters: vec!["minecraft:stone".into(), "minecraft:deepslate".into()],
        runs: vec![],
    };
    for i in 0..10u64 {
        let q = rules::hash(cx.wrapping_add(i as i32), cz.wrapping_sub(i as i32));
        let y = (q % 100) as i32 - 48;
        edit.runs.push(NativeBlockRun {
            x: x + 2 + (q % 12) as i32,
            z: z + 2 + ((q >> 12) % 12) as i32,
            y,
            height: 3,
            surface: None,
            block: if y < 0 { 1 } else { 0 },
            only: Some(if y < 0 { 1 } else { 0 }),
        });
    }
    let _ = host.edit_blocks(dimension, &edit);
    if h % 35 != 0 {
        return;
    }
    let columns = [
        (x + 2, z + 2),
        (x + 12, z + 2),
        (x + 2, z + 12),
        (x + 12, z + 12),
        (x + 7, z + 7),
    ];
    let Ok(heights) =
        host.surface_heights(dimension, &columns, NativeHeightmap::MotionBlockingNoLeaves)
    else {
        return;
    };
    let Some(base) = heights.first().copied().flatten() else {
        return;
    };
    if heights
        .iter()
        .any(|y| y.is_none_or(|y| (y - base).abs() > 3))
        || base < 50
        || base > 160
    {
        return;
    }
    if columns.iter().any(|(x, z)| {
        matches!(
            host.block([*x, base - 1, *z]).as_str(),
            "minecraft:water" | "minecraft:lava" | "minecraft:air"
        )
    }) {
        return;
    }
    // Do not carve a small ruin into a newly generated settlement's own floors.
    if columns.iter().any(|(x, z)| {
        host.block([*x, base - 1, *z])
            .starts_with("ashen_frontier:")
    }) {
        return;
    }
    let variant = (h >> 12) % 3;
    let y = if variant == 2 { base - 14 } else { base - 1 };
    let mut structure = NativeBlockEdit::default();
    for p in rules::site(variant) {
        let state = p.block.to_string();
        let index = structure
            .palette
            .iter()
            .position(|s| s == &state)
            .unwrap_or_else(|| {
                structure.palette.push(state);
                structure.palette.len() - 1
            });
        structure.runs.push(NativeBlockRun {
            x: x + 2 + p.at[0],
            z: z + 2 + p.at[2],
            y: y + p.at[1],
            height: 1,
            surface: None,
            block: index as u32,
            only: None,
        });
    }
    if variant == 2 {
        let a = structure.palette.len() as u32;
        structure.palette.extend([
            "minecraft:air".into(),
            "ashen_frontier:ashen_bricks".into(),
            "minecraft:ladder[facing=south]".into(),
        ]);
        for k in 1..=14 {
            for (dx, dz, b) in [(5, 5, a), (5, 4, a + 1), (5, 5, a + 2)] {
                structure.runs.push(NativeBlockRun {
                    x: x + 2 + dx,
                    z: z + 2 + dz,
                    y: y + k,
                    height: 1,
                    surface: None,
                    block: b,
                    only: None,
                });
            }
        }
    }
    if host.edit_blocks(dimension, &structure).is_ok() {
        let _ = host.summon(
            dimension,
            "ashen_frontier:ashbound",
            [(x + 7) as f64, (y + 1) as f64, (z + 7) as f64],
            Compound::new(),
        );
    }
}
/// Province surfaces are changed only while handling a newly generated chunk.
/// Tint values identify the two original province definitions in the companion datapack.
fn imperial_surface(host: &mut dyn Host, chunk: [i32; 2]) {
    let x = chunk[0] * 16;
    let z = chunk[1] * 16;
    let columns: Vec<_> = (0..16)
        .flat_map(|dx| (0..16).map(move |dz| (x + dx, z + dz)))
        .collect();
    let Ok(read) = host.read_columns(
        "minecraft:overworld",
        &columns,
        NativeHeightmap::MotionBlockingNoLeaves,
        (1, 1),
    ) else {
        return;
    };
    let mut edit = NativeBlockEdit {
        palette: vec![
            "ashen_frontier:luna_marble".into(),
            "ashen_frontier:volcanic_tuff".into(),
            "minecraft:blackstone".into(),
        ],
        filters: vec!["minecraft:grass_block".into(), "minecraft:dirt".into()],
        runs: vec![],
    };
    for (i, (x, z)) in columns.into_iter().enumerate() {
        let Some(y) = read.bases.get(i).copied().flatten() else {
            continue;
        };
        let tint = read.tints.get(i * 3).copied().unwrap_or(0);
        let block = if tint == 0x92adb2 {
            0
        } else if tint == 0x8d8874 {
            if rules::hash(x, z) % 5 == 0 { 2 } else { 1 }
        } else {
            continue;
        };
        for filter in 0..2 {
            edit.runs.push(NativeBlockRun {
                x,
                z,
                y: y - 1,
                height: 1,
                surface: None,
                block,
                only: Some(filter),
            });
        }
    }
    if !edit.runs.is_empty() {
        let _ = host.edit_blocks("minecraft:overworld", &edit);
    }
}
