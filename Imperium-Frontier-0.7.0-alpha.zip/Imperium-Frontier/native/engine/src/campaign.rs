//! Roman NPCs, quest journal, turn-ins, shops, exploration and guard AI integration.
use super::*;
#[derive(Clone)]
pub(super) struct Npc {
    kind: String,
    dimension: String,
    pos: [f64; 3],
}
fn role(kind: &str) -> Option<&str> {
    kind.strip_prefix(PREFIX).filter(|r| {
        matches!(
            *r,
            "citizen" | "prefect" | "quartermaster" | "merchant" | "legionary_guard"
        )
    })
}
pub(super) fn is_npc(kind: &str) -> bool {
    role(kind).is_some()
}
fn label(id: &str) -> &str {
    match id {
        "ashen_frontier:flour" => "Milled Flour",
        "ashen_frontier:olive_oil" => "Amphorae of Olive Oil",
        "ashen_frontier:quicklime" => "Quicklime",
        "ashen_frontier:tempered_ember" => "Imperial Steel",
        "ashen_frontier:steam_core" => "Aether Pressure Cores",
        "ashen_frontier:sunsteel_ingot" => "Sunsteel Ingot",
        "ashen_frontier:aquila_sword" => "Aquila of Sol",
        "minecraft:bread" => "Bread",
        "ashen_frontier:expedition_ration" => "Legionary Rations",
        "ashen_frontier:ashen_bricks" => "Roman Marble Bricks",
        "ashen_frontier:ember_sword" => "Legionary Gladius",
        "ashen_frontier:relic_sword" => "Praetorian Gladius",
        "ashen_frontier:ashbound" => "Restless Legionaries",
        "ashen_frontier:bandit" => "Road Bandits",
        "ashen_frontier:crypt_warden" => "the Fallen Centurion",
        "ashen_frontier:cinder_sovereign" => "the Usurper Emperor",
        other => other,
    }
}
fn objective(q: &quests::Quest) -> String {
    match q.goal {
        quests::Goal::Deliver(id, n) => format!("Deliver {n} {}", label(id)),
        quests::Goal::Kill(id, n) => format!("Defeat {n} {}", label(id)),
        quests::Goal::Craft(id, n) => format!("Craft {n} {}", label(id)),
        quests::Goal::Visit(kind) => format!("Visit a Roman {kind}"),
    }
}
impl Frontier {
    pub(super) fn track_npc(&self, host: &mut dyn Host, id: u32, kind: &str) {
        if role(kind).is_none() {
            return;
        }
        let Some(entity) = host.entity(id) else {
            return;
        };
        let Some(pos) = host.entity_position(entity) else {
            return;
        };
        let dimension = host
            .entity_level(entity)
            .map(|l| l.dimension().to_owned())
            .unwrap_or_default();
        self.world(host, |w| {
            w.npcs.insert(
                id,
                Npc {
                    kind: kind.to_owned(),
                    dimension: dimension.clone(),
                    pos,
                },
            );
        });
        let tags = host.entity_tags(entity).unwrap_or_default();
        let site = if tags.iter().any(|t| t == "imperium.city") {
            Some("city")
        } else if tags.iter().any(|t| t == "imperium.town") {
            Some("town")
        } else if tags.iter().any(|t| t == "imperium.fort") {
            Some("fort")
        } else {
            None
        };
        if let Some(site) = site {
            for p in host.server_players() {
                if p.dimension == dimension
                    && p.position
                        .into_iter()
                        .zip(pos)
                        .map(|(a, b)| (a - b).powi(2))
                        .sum::<f64>()
                        <= 24. * 24.
                {
                    self.quest_event(host, p.uuid, "visit", site, 1);
                }
            }
        }
    }
    fn near_giver(&self, host: &dyn Host, player: &NativeServerPlayer, wanted: &str) -> bool {
        let candidates = self
            .world(host, |w| {
                w.npcs
                    .iter()
                    .map(|(id, n)| (*id, n.clone()))
                    .collect::<Vec<_>>()
            })
            .unwrap_or_default();
        candidates.into_iter().any(|(id, n)| {
            role(&n.kind) == Some(wanted)
                && n.dimension == player.dimension
                && host.entity(id).is_some()
                && n.pos
                    .into_iter()
                    .zip(player.position)
                    .map(|(a, b)| (a - b).powi(2))
                    .sum::<f64>()
                    <= 10. * 10.
        })
    }
    pub(super) fn quest_event(
        &self,
        host: &mut dyn Host,
        player: u128,
        event: &str,
        key: &str,
        count: u32,
    ) {
        let changed = self
            .world(host, |w| {
                let j = w.quests.entry(player).or_default();
                let before = j.progress;
                let goal = j
                    .active
                    .as_deref()
                    .and_then(quests::get)
                    .and_then(|q| match q.goal {
                        quests::Goal::Kill(id, _) if event == "kill" && id == key => {
                            Some(quests::Goal::Kill(id, count))
                        }
                        quests::Goal::Craft(id, _) if event == "craft" && id == key => {
                            Some(quests::Goal::Craft(id, count))
                        }
                        quests::Goal::Visit(id) if event == "visit" && id == key => {
                            Some(quests::Goal::Visit(id))
                        }
                        _ => None,
                    });
                if let Some(goal) = goal {
                    j.event(goal);
                }
                before != j.progress
            })
            .unwrap_or(false);
        if changed {
            self.persist(host);
        }
    }
    pub(super) fn show_quests(&self, host: &mut dyn Host, player: u128) {
        let journal = self
            .world(host, |w| w.quests.entry(player).or_default().clone())
            .unwrap_or_default();
        host.tell(
            player,
            Text::literal(format!(
                "TABULA — {} / {} commissions complete",
                journal.completed.len(),
                quests::QUESTS.len()
            )),
        );
        if let Some(q) = journal.active.as_deref().and_then(quests::get) {
            let progress = match q.goal {
                quests::Goal::Deliver(id, n) => host.count_items(id).min(n),
                _ => journal.progress,
            };
            host.tell(player,Text::literal(format!("ACTIVE: {} — {} (tracked: {}). Reward: {} glory, {} denarii. Return to the {} and /frontier quest claim.",q.title,objective(q),progress,q.glory,q.coins,q.giver)));
        } else {
            for q in quests::QUESTS {
                if !journal.completed.contains(q.id)
                    && (q.requires.is_empty() || journal.completed.contains(q.requires))
                {
                    host.tell(
                        player,
                        Text::literal(format!(
                            "{}: {} — {}. Speak to a {} and /frontier quest accept {}",
                            q.id,
                            q.title,
                            objective(&q),
                            q.giver,
                            q.id
                        )),
                    );
                }
            }
        }
        host.tell(
            player,
            Text::literal(
                "One active commission at a time. /frontier quest abandon cancels active progress.",
            ),
        );
    }
    pub(super) fn campaign_command(
        &self,
        host: &mut dyn Host,
        player: &NativeServerPlayer,
        args: &[&str],
    ) -> bool {
        match args.get(1).copied() {
            Some("quests") => {
                self.show_quests(host, player.uuid);
                true
            }
            Some("quest") => {
                match args.get(2).copied() {
                    Some("accept") => {
                        let Some(q) = args.get(3).and_then(|id| quests::get(id)) else {
                            tell(
                                host,
                                "Unknown commission. /frontier quests lists available IDs.",
                            );
                            return true;
                        };
                        if !self.near_giver(host, player, q.giver) {
                            tell(
                                host,
                                format!(
                                    "Stand within 10 blocks of a {} to accept this commission.",
                                    q.giver
                                ),
                            );
                            return true;
                        }
                        let answer = self.world(host, |w| {
                            w.quests.entry(player.uuid).or_default().accept(q.id)
                        });
                        match answer {
                            Some(Ok(())) => {
                                tell(host, format!("Accepted: {}. {}", q.title, objective(q)));
                                self.persist(host);
                            }
                            Some(Err(s)) => tell(host, s),
                            None => {}
                        }
                    }
                    Some("claim") => {
                        let j = self
                            .world(host, |w| w.quests.entry(player.uuid).or_default().clone())
                            .unwrap_or_default();
                        let Some(q) = j.active.as_deref().and_then(quests::get) else {
                            tell(host, "No active commission.");
                            return true;
                        };
                        if !self.near_giver(host, player, q.giver) {
                            tell(
                                host,
                                format!("Return to a {} to claim the reward.", q.giver),
                            );
                            return true;
                        }
                        let count = match q.goal {
                            quests::Goal::Deliver(id, _) => host.count_items(id),
                            _ => 0,
                        };
                        if !j.ready(count) {
                            tell(host, "This commission's objective is not complete.");
                            return true;
                        }
                        if host.room_for("ashen_frontier:denarius") < q.coins {
                            tell(host, "Make inventory space for the reward first.");
                            return true;
                        }
                        if let quests::Goal::Deliver(id, n) = q.goal {
                            if host.take_items(id, n) != n {
                                tell(host, "Delivery inventory changed; try again.");
                                return true;
                            }
                        }
                        self.world(host, |w| {
                            w.quests.entry(player.uuid).or_default().finish();
                            let progress = w.players.entry(player.uuid).or_default();
                            progress.xp = progress.xp.saturating_add(q.glory);
                        });
                        host.give_items("ashen_frontier:denarius", q.coins);
                        self.persist(host);
                        tell(
                            host,
                            format!(
                                "Commission complete: {}. +{} glory, +{} denarii.",
                                q.title, q.glory, q.coins
                            ),
                        );
                    }
                    Some("abandon") => {
                        self.world(host, |w| w.quests.entry(player.uuid).or_default().abandon());
                        self.persist(host);
                        tell(host, "Active commission abandoned.");
                    }
                    _ => self.show_quests(host, player.uuid),
                }
                true
            }
            Some("trade") => {
                if !self.near_giver(host, player, "merchant")
                    && !self.near_giver(host, player, "quartermaster")
                {
                    tell(host, "Stand near a merchant or quartermaster to trade.");
                    return true;
                }
                let offer = match args.get(2).copied() {
                    Some("rations") => Some(("ashen_frontier:expedition_ration", 2, 3)),
                    Some("marble") => Some(("ashen_frontier:ashen_bricks", 16, 4)),
                    Some("steel") => Some(("ashen_frontier:tempered_ember", 1, 12)),
                    Some("tesserae") => Some(("ashen_frontier:relic_fragment", 2, 4)),
                    _ => None,
                };
                let Some((id, count, cost)) = offer else {
                    tell(
                        host,
                        "Offers: rations (3 denarii), marble (4), steel (12), tesserae (4). /frontier trade <offer>",
                    );
                    return true;
                };
                if host.count_items("ashen_frontier:denarius") < cost {
                    tell(host, "You do not have enough denarii.");
                    return true;
                }
                if host.room_for(id) < count {
                    tell(host, "Make inventory space first.");
                    return true;
                }
                if host.take_items("ashen_frontier:denarius", cost) == cost {
                    host.give_items(id, count);
                    tell(host, "Trade completed.");
                }
                true
            }
            _ => false,
        }
    }
    pub(super) fn npc_interaction(&self, host: &mut dyn Host, id: u32, kind: &str) -> bool {
        let Some(role) = role(kind) else {
            return false;
        };
        self.track_npc(host, id, kind);
        let Some(player) = host.acting_player() else {
            return false;
        };
        match role {
            "prefect" | "quartermaster" => {
                host.tell(
                    player.uuid,
                    Text::literal(
                        "For the province and the legion. These are our outstanding commissions:",
                    ),
                );
                self.show_quests(host, player.uuid);
                if role == "quartermaster" {
                    host.tell(
                        player.uuid,
                        Text::literal(
                            "Supplies: /frontier trade rations | marble | steel | tesserae",
                        ),
                    );
                }
            }
            "merchant" => {
                host.tell(player.uuid,Text::literal("Salve! Rations 3, marble 4, steel 12, tesserae 4 denarii. /frontier trade <offer>"));
            }
            "legionary_guard" => {
                host.tell(
                    player.uuid,
                    Text::literal("The legion holds the road. Seek the prefect for commissions."),
                );
            }
            _ => {
                let words = [
                    "The baths are the heart of a civilized town.",
                    "The quartermaster pays for supplies. Speak to them if you seek work.",
                    "Bandits haunt the roads. The prefect offers commissions against them.",
                    "Trade your denarii at the market. The legion always needs rations.",
                ];
                host.tell(player.uuid, Text::literal(words[id as usize % words.len()]));
            }
        }
        true
    }
}
