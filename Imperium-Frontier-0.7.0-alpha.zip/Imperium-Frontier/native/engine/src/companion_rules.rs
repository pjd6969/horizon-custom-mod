pub const PETS: [(&str, &str, u8, u32); 4] = [
    ("lupa_hound", "Lupa's Hound", 0, 8),
    ("mars_boar", "Mars War Boar", 1, 12),
    ("diana_lynx", "Diana's Lynx", 2, 16),
    ("jupiter_eagle", "Jupiter's Eagle", 3, 24),
];
pub fn owner_tag(owner: u128) -> String {
    format!("imperium.owner.{owner}")
}
pub fn bond_tag(token: &str) -> String {
    format!("imperium.bond.{token}")
}
pub fn identity(tags: &[String]) -> Option<(u128, &str)> {
    let owner = tags
        .iter()
        .find_map(|s| s.strip_prefix("imperium.owner."))
        .and_then(|s| s.parse().ok())?;
    let token = tags
        .iter()
        .find_map(|s| s.strip_prefix("imperium.bond."))
        .filter(|s| !s.is_empty())?;
    Some((owner, token))
}
pub fn valid_bond(expected: Option<&str>, token: &str) -> bool {
    expected.is_some_and(|v| !token.is_empty() && v == token)
}
pub fn can_adopt(stage: u8, required: u8, enlisted: bool, has_bond: bool) -> bool {
    stage >= required && enlisted && !has_bond
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn tags_preserve_full_owner_and_token() {
        let t = vec![owner_tag(u128::MAX), bond_tag("released-then-new-bond")];
        assert_eq!(identity(&t), Some((u128::MAX, "released-then-new-bond")));
    }
    #[test]
    fn incomplete_identity_is_not_owned() {
        assert!(identity(&[owner_tag(7)]).is_none());
        assert!(identity(&["imperium.owner.invalid".into(), bond_tag("a")]).is_none());
        assert!(identity(&[owner_tag(7), bond_tag("")]).is_none());
    }
    #[test]
    fn releasing_or_replacing_revokes_old_entity() {
        assert!(!valid_bond(None, "old"));
        assert!(!valid_bond(Some("new"), "old"));
        assert!(valid_bond(Some("new"), "new"));
    }
    #[test]
    fn one_pet_and_campaign_gates() {
        assert!(can_adopt(0, 0, true, false));
        assert!(!can_adopt(4, 0, true, true));
        assert!(!can_adopt(0, 3, true, false));
        assert!(!can_adopt(4, 0, false, false));
    }
    #[test]
    fn pet_catalog_has_unique_progression() {
        let mut names = std::collections::BTreeSet::new();
        for (i, (id, _, stage, cost)) in PETS.iter().enumerate() {
            assert!(names.insert(id));
            assert_eq!(*stage, i as u8);
            assert!(*cost > 0);
        }
    }
}
