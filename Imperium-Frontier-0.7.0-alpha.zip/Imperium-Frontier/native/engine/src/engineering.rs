//! RPG engineering stations. Jobs persist in the station's block entity NBT.
use super::*;
const BE: &str = "ashen_frontier:engineering";
const UTILITIES: [&str; 3] = [
    "ashen_frontier:cistern",
    "ashen_frontier:irrigation_valve",
    "ashen_frontier:hypocaust_brazier",
];
fn item_name(id: &str) -> &str {
    match id {
        "minecraft:wheat" => "Wheat",
        "minecraft:calcite" => "Calcite",
        "minecraft:charcoal" => "Charcoal",
        "minecraft:iron_ingot" => "Iron Ingots",
        "minecraft:copper_ingot" => "Copper Ingots",
        "ashen_frontier:flour" => "Milled Flour",
        "ashen_frontier:olive_cluster" => "Olives",
        "ashen_frontier:olive_oil" => "Olive Oil Amphorae",
        "ashen_frontier:quicklime" => "Quicklime",
        "ashen_frontier:tempered_ember" => "Imperial Steel",
        "ashen_frontier:relic_fragment" => "Ancient Tesserae",
        "ashen_frontier:relic_core" => "Votive Gems",
        "ashen_frontier:steam_core" => "Aether Pressure Cores",
        "ashen_frontier:sunsteel_ingot" => "Sunsteel Ingots",
        other => other,
    }
}
fn supplies(r: &technology::Recipe) -> String {
    r.inputs
        .iter()
        .map(|(id, n)| format!("{n} {}", item_name(id)))
        .collect::<Vec<_>>()
        .join(", ")
}
pub(super) fn is_station(block: &str) -> bool {
    technology::recipe(block).is_some() || UTILITIES.contains(&block)
}
pub(super) fn make(block: &str) -> Option<(String, Compound)> {
    is_station(block).then(|| (BE.into(), Compound::new()))
}
fn text(nbt: &Compound, key: &str) -> Option<String> {
    match nbt.get(&key.into()) {
        Some(Tag::String(v)) => v.to_string().ok(),
        _ => None,
    }
}
fn number(nbt: &Compound, key: &str) -> i64 {
    match nbt.get(&key.into()) {
        Some(Tag::Long(v)) => *v,
        _ => 0,
    }
}
fn neighbors(p: [i32; 3]) -> [[i32; 3]; 6] {
    let [x, y, z] = p;
    [
        [x + 1, y, z],
        [x - 1, y, z],
        [x, y + 1, z],
        [x, y - 1, z],
        [x, y, z + 1],
        [x, y, z - 1],
    ]
}
fn water(host: &dyn Host, p: [i32; 3], flow: bool) -> bool {
    neighbors(p).into_iter().any(|p| {
        host.block(p) == "minecraft:water"
            && (!flow
                || host
                    .block_property(p, "level")
                    .and_then(|n| n.parse::<u8>().ok())
                    .is_some_and(|n| n > 0))
    })
}
fn powered(host: &dyn Host, p: [i32; 3], power: technology::Power) -> bool {
    match power {
        technology::Power::None => true,
        technology::Power::Flow => water(host, p, true),
        technology::Power::Steam => {
            water(host, p, false) && {
                let below = [p[0], p[1] - 1, p[2]];
                matches!(
                    host.block(below).as_str(),
                    "minecraft:campfire" | "minecraft:soul_campfire"
                ) && host.block_property(below, "lit").as_deref() == Some("true")
            }
        }
        technology::Power::Divine => neighbors(p)
            .into_iter()
            .any(|p| host.block(p) == "ashen_frontier:relic_beacon"),
    }
}
fn power_help(p: technology::Power) -> &'static str {
    match p {
        technology::Power::None => "Hand operated",
        technology::Power::Flow => "Needs flowing water touching one face",
        technology::Power::Steam => "Needs adjacent water and a lit campfire directly below",
        technology::Power::Divine => "Needs an adjacent Votive Lantern",
    }
}
impl Frontier {
    pub(super) fn tech_guide(&self, host: &mut dyn Host, player: u128) {
        let (xp, j) = self
            .world(host, |w| {
                (
                    w.players.entry(player).or_default().xp,
                    w.quests.entry(player).or_default().clone(),
                )
            })
            .unwrap_or_default();
        host.tell(player,Text::literal(format!("ARS ROMANA — {} | {}. Eight engineering commissions begin with tech_survey after enlist.",technology::profession(&j.completed),rules::rank_name(xp))));
        let odyssey = self
            .world(host, |w| *w.campaign.entry(player).or_default())
            .unwrap_or(0);
        host.tell(
            player,
            Text::literal(
                "Odyssey gates: defeat Vulcan for steam, and Sol Invictus for divine forging.",
            ),
        );
        for r in technology::RECIPES {
            let state = if technology::gate(&r, level(xp), &j.completed).is_ok()
                && match r.power {
                    technology::Power::Steam => odyssey >= 1,
                    technology::Power::Divine => odyssey >= 4,
                    _ => true,
                } {
                "UNLOCKED"
            } else {
                "LOCKED"
            };
            host.tell(
                player,
                Text::literal(format!(
                    "{state}: {} | rank {} + {}{} | {} | {}s. Inputs: {}; output {} x{}.",
                    r.title,
                    r.rank,
                    r.quest,
                    if r.boss.is_empty() {
                        String::new()
                    } else {
                        format!(" + boss commission {}", r.boss)
                    },
                    power_help(r.power),
                    r.ticks / 20,
                    supplies(&r),
                    item_name(r.output.0),
                    r.output.1
                )),
            );
        }
        host.tell(player,Text::literal("Right-click a station to load a timed batch; return to collect. Sneak-right-click shows its recipe. Cisterns, irrigation and hypocaust rest unlock after tech_survey. Engineered roads grant brief travel speed."));
    }
    pub(super) fn engineering_click(&self, host: &mut dyn Host, p: [i32; 3]) -> bool {
        let block = host.block(p);
        if !is_station(&block) {
            return false;
        }
        let Some(player) = host.acting_player() else {
            return true;
        };
        if player.game_mode != 0 {
            tell(
                host,
                "Engineering stations currently require Survival mode.",
            );
            return true;
        }
        if player
            .position
            .into_iter()
            .zip(p)
            .map(|(a, b)| (a - (b as f64 + 0.5)).powi(2))
            .sum::<f64>()
            > 36.
        {
            return true;
        }
        let Some(entity) = host.mod_block_entity(p) else {
            tell(
                host,
                "This station has no engineering data. Replace it with both updated mods enabled.",
            );
            return true;
        };
        let t = now(host);
        if let Some(job) = text(&entity.nbt, "Job") {
            if text(&entity.nbt, "Owner").as_deref() != Some(&player.uuid.to_string()) {
                tell(host, "Another adventurer owns this batch.");
                return true;
            }
            let Some(r) = technology::recipe(&job).filter(|r| r.station == block) else {
                tell(
                    host,
                    "Unrecognized saved batch; keep this station for inspection.",
                );
                return true;
            };
            let finish = number(&entity.nbt, "ReadyAt");
            if !technology::ready(finish, t) {
                tell(
                    host,
                    format!(
                        "{} working: {} seconds remaining.",
                        r.title,
                        (finish - t + 19) / 20
                    ),
                );
                return true;
            }
            if host.room_for(r.output.0) < r.output.1 {
                tell(host, "Make room for the completed batch first.");
                return true;
            }
            if host.change_mod_block_entity(p, &mut |e| {
                e.nbt.remove(&"Job".into());
                e.nbt.remove(&"Owner".into());
                e.nbt.remove(&"ReadyAt".into());
            }) {
                host.give_items(r.output.0, r.output.1);
                self.quest_event(host, player.uuid, "craft", r.output.0, r.output.1);
                tell(
                    host,
                    format!(
                        "Batch collected: {} x{}.",
                        item_name(r.output.0),
                        r.output.1
                    ),
                );
            }
            return true;
        }
        let (xp, j) = self
            .world(host, |w| {
                (
                    w.players.entry(player.uuid).or_default().xp,
                    w.quests.entry(player.uuid).or_default().clone(),
                )
            })
            .unwrap_or_default();
        if let Some(r) = technology::recipe(&block) {
            if host.sneaking() {
                tell(
                    host,
                    format!(
                        "{}: {} -> {} x{} in {}s. {}. Rank {}, {}, boss: {}.",
                        r.title,
                        supplies(r),
                        item_name(r.output.0),
                        r.output.1,
                        r.ticks / 20,
                        power_help(r.power),
                        r.rank,
                        r.quest,
                        if r.boss.is_empty() { "none" } else { r.boss }
                    ),
                );
                return true;
            }
            if let Err(s) = technology::gate(r, level(xp), &j.completed) {
                tell(host, s);
                return true;
            }
            let stage = self
                .world(host, |w| *w.campaign.entry(player.uuid).or_default())
                .unwrap_or(0);
            if (r.power == technology::Power::Steam && stage < 1)
                || (r.power == technology::Power::Divine && stage < 4)
            {
                tell(
                    host,
                    "This technology requires later Imperial Odyssey victories: Vulcan for steam, Sol Invictus for divine forging.",
                );
                return true;
            }
            if !powered(host, p, r.power) {
                tell(host, power_help(r.power));
                return true;
            }
            if !r.inputs.iter().all(|(id, n)| host.count_items(id) >= *n) {
                tell(host, format!("Missing supplies: {}", supplies(r)));
                return true;
            }
            let mut taken = Vec::new();
            for (id, n) in r.inputs {
                let count = host.take_items(id, *n);
                taken.push((*id, count));
                if count != *n {
                    for (id, count) in taken {
                        host.give_items(id, count);
                    }
                    tell(host, "Supplies changed; the batch was not started.");
                    return true;
                }
            }
            let finish = technology::duration(r, t);
            let owner = player.uuid.to_string();
            if !host.change_mod_block_entity(p, &mut |e| {
                e.nbt.insert("Job".into(), Tag::String(r.station.into()));
                e.nbt
                    .insert("Owner".into(), Tag::String(owner.as_str().into()));
                e.nbt.insert("ReadyAt".into(), Tag::Long(finish));
            }) {
                for (id, count) in taken {
                    host.give_items(id, count);
                }
                return true;
            }
            tell(
                host,
                format!(
                    "{} started. Return in {} seconds to collect.",
                    r.title,
                    r.ticks / 20
                ),
            );
            return true;
        }
        if level(xp) < 2 || !j.completed.contains("tech_survey") {
            tell(
                host,
                "Reach Miles and complete tech_survey to operate Roman utilities.",
            );
            return true;
        }
        let cooldown = number(&entity.nbt, "Cooldown");
        if cooldown > t {
            tell(
                host,
                format!("Utility ready in {} seconds.", (cooldown - t + 19) / 20),
            );
            return true;
        }
        match block.as_str() {
            "ashen_frontier:cistern" => {
                if !water(host, p, false) {
                    tell(host, "Place water touching a face of the cistern.");
                    return true;
                }
                if host.count_items("minecraft:bucket") < 1
                    || host.room_for("minecraft:water_bucket") < 1
                {
                    tell(
                        host,
                        "Bring an empty bucket and leave a slot for a water bucket.",
                    );
                    return true;
                }
                if host.take_items("minecraft:bucket", 1) == 1 {
                    host.give_items("minecraft:water_bucket", 1);
                    tell(host, "Water drawn from the cistern.");
                }
            }
            "ashen_frontier:irrigation_valve" => {
                if !water(host, p, false) {
                    tell(host, "The valve needs adjacent water.");
                    return true;
                }
                let mut count = 0;
                for x in -3..=3 {
                    for z in -3..=3 {
                        let at = [p[0] + x, p[1] - 1, p[2] + z];
                        if host.block(at) == "minecraft:farmland"
                            && host.set_block_property(at, "moisture", "7")
                        {
                            count += 1;
                        }
                    }
                }
                tell(
                    host,
                    format!(
                        "Irrigation refreshed {count} farmland blocks. Real nearby water keeps them hydrated."
                    ),
                );
            }
            "ashen_frontier:hypocaust_brazier" => {
                if host.count_items("minecraft:charcoal") < 1 {
                    tell(
                        host,
                        "Rest requires one charcoal; restores health and grants brief protection.",
                    );
                    return true;
                }
                if host.take_items("minecraft:charcoal", 1) == 1 {
                    self.world(host, |w| {
                        let who = uuid(player.uuid);
                        w.commands.push_back(format!(
                            "effect give {who} minecraft:regeneration 5 0 true"
                        ));
                        w.commands
                            .push_back(format!("effect give {who} minecraft:resistance 60 0 true"));
                    });
                    host.change_mod_block_entity(p, &mut |e| {
                        e.nbt
                            .insert("Cooldown".into(), Tag::Long(t.saturating_add(1200)));
                    });
                    tell(
                        host,
                        "Rested by the hypocaust: regeneration and one minute of resistance.",
                    );
                }
            }
            _ => {}
        }
        true
    }
    pub(super) fn engineered_road(&self, host: &mut dyn Host) {
        let Some(p) = host.acting_player().filter(|p| p.game_mode == 0) else {
            return;
        };
        if now(host) % 40 != 0 {
            return;
        }
        let at = [
            p.position[0].floor() as i32,
            (p.position[1] - 0.1).floor() as i32,
            p.position[2].floor() as i32,
        ];
        if host.block(at) != "ashen_frontier:via_stone" {
            return;
        }
        let unlocked = self
            .world(host, |w| {
                w.quests
                    .get(&p.uuid)
                    .is_some_and(|j| j.completed.contains("tech_survey"))
            })
            .unwrap_or(false);
        if unlocked {
            self.world(host, |w| {
                w.commands.push_back(format!(
                    "effect give {} minecraft:speed 3 0 true",
                    uuid(p.uuid)
                ))
            });
        }
    }
}
