//! Bounded, leaf-checked tree detection. Original implementation, not a bundled Java mod.
use std::collections::{BTreeSet, VecDeque};
pub const MAX_LOGS: usize = 64;
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Block {
    Log,
    Leaf,
    Other,
}
pub fn species(id: &str) -> Option<&str> {
    let (namespace, path) = id.split_once(':')?;
    let name = path.strip_suffix("_log")?;
    let known = if namespace == "ashen_frontier" {
        [
            "amberwood",
            "willow",
            "rosewood",
            "frostpine",
            "scarlet",
            "azurewood",
        ]
        .contains(&name)
    } else if namespace == "minecraft" {
        [
            "oak", "spruce", "birch", "jungle", "acacia", "dark_oak", "mangrove", "cherry",
            "pale_oak",
        ]
        .contains(&name)
    } else {
        false
    };
    known.then_some(name)
}
pub fn axe_durability(id: &str) -> Option<u32> {
    match id {
        "minecraft:wooden_axe" => Some(59),
        "minecraft:stone_axe" => Some(131),
        "minecraft:iron_axe" => Some(250),
        "minecraft:golden_axe" => Some(32),
        "minecraft:diamond_axe" => Some(1561),
        "minecraft:netherite_axe" => Some(2031),
        _ => None,
    }
}
pub fn ground(id: &str) -> bool {
    matches!(
        id,
        "minecraft:grass_block"
            | "minecraft:dirt"
            | "minecraft:coarse_dirt"
            | "minecraft:rooted_dirt"
            | "minecraft:podzol"
            | "minecraft:mud"
            | "minecraft:mangrove_roots"
            | "minecraft:muddy_mangrove_roots"
            | "minecraft:moss_block"
            | "minecraft:snow_block"
    )
}
/// Root may be virtual after the player's original block break. Return nothing on overflow.
pub fn scan(root: [i32; 3], mut read: impl FnMut([i32; 3]) -> Block) -> Option<Vec<[i32; 3]>> {
    let mut queue = VecDeque::from([root]);
    let mut logs = BTreeSet::from([root]);
    let mut leaves = BTreeSet::new();
    while let Some(p) = queue.pop_front() {
        for dx in -1i32..=1 {
            for dy in -1i32..=1 {
                for dz in -1i32..=1 {
                    if dx == 0 && dy == 0 && dz == 0 {
                        continue;
                    }
                    let at = [p[0] + dx, p[1] + dy, p[2] + dz];
                    if at[1] < root[1] {
                        continue;
                    }
                    match read(at) {
                        Block::Log => {
                            if (at[0] - root[0]).abs() > 6
                                || (at[2] - root[2]).abs() > 6
                                || at[1] > root[1] + 32
                            {
                                return None;
                            }
                            if logs.insert(at) {
                                if logs.len() > MAX_LOGS {
                                    return None;
                                }
                                queue.push_back(at);
                            }
                        }
                        Block::Leaf => {
                            leaves.insert(at);
                        }
                        Block::Other => {}
                    }
                }
            }
        }
    }
    if logs.len() < 2 || leaves.len() < 2 {
        return None;
    }
    let mut logs: Vec<_> = logs.into_iter().collect();
    logs.sort_by_key(|p| (std::cmp::Reverse(p[1]), p[0], p[2]));
    Some(logs)
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn recognizes_imperial_woods() {
        for name in [
            "amberwood",
            "willow",
            "rosewood",
            "frostpine",
            "scarlet",
            "azurewood",
        ] {
            let id = format!("ashen_frontier:{name}_log");
            assert_eq!(species(&id), Some(name));
        }
    }
    #[test]
    fn accepts_natural_tree_top_first() {
        let out = scan([0, 0, 0], |p| {
            if p[0] == 0 && p[2] == 0 && (0..4).contains(&p[1]) {
                Block::Log
            } else if p[1] == 3 && p[0].abs() <= 1 && p[2].abs() <= 1 {
                Block::Leaf
            } else {
                Block::Other
            }
        })
        .unwrap();
        assert_eq!(out.len(), 4);
        assert_eq!(out[0], [0, 3, 0]);
        assert_eq!(out[3], [0, 0, 0]);
    }
    #[test]
    fn bare_pillars_are_not_trees() {
        assert!(
            scan([0, 0, 0], |p| if p[0] == 0 && p[2] == 0 && p[1] < 4 {
                Block::Log
            } else {
                Block::Other
            })
            .is_none()
        );
    }
    #[test]
    fn rejects_large_network_instead_of_partial_felling() {
        assert!(
            scan([0, 0, 0], |p| if p[1] < 3 {
                Block::Log
            } else {
                Block::Leaf
            })
            .is_none()
        );
    }
    #[test]
    fn scan_stays_above_cut() {
        let out = scan([0, 0, 0], |p| {
            assert!(p[1] >= 0);
            if p[0] == 0 && p[2] == 0 && p[1] < 3 {
                Block::Log
            } else {
                Block::Leaf
            }
        })
        .unwrap();
        assert_eq!(out.len(), 3);
    }
    #[test]
    fn only_recognized_logs_and_axes() {
        assert_eq!(species("minecraft:oak_log"), Some("oak"));
        assert_eq!(species("minecraft:stripped_oak_log"), None);
        assert_eq!(species("ashen_frontier:cinderwood_beam"), None);
        assert_eq!(axe_durability("minecraft:iron_axe"), Some(250));
        assert_eq!(axe_durability("minecraft:iron_pickaxe"), None);
    }
}
