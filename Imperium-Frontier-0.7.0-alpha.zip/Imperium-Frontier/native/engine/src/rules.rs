//! Pure progression and deterministic structure layout; no game dependency.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct Progress {
    pub xp: u32,
    pub kills: u32,
    pub ready_at: i64,
}
pub fn level(xp: u32) -> u32 {
    1 + [40, 140, 350, 700].into_iter().filter(|n| xp >= *n).count() as u32
}
pub fn rank_name(xp: u32) -> &'static str {
    ["Tiro", "Miles", "Legionarius", "Centurio", "Legatus"][(level(xp) - 1) as usize]
}
pub fn reward(kind: &str) -> u32 {
    match kind {
        "ashen_frontier:forge_tyrant" => 120,
        "ashen_frontier:styx_judge" => 160,
        "ashen_frontier:astral_legate" => 200,
        "ashen_frontier:sol_avatar" => 250,
        "ashen_frontier:bandit" => 6,
        "ashen_frontier:raider" => 12,
        "ashen_frontier:cultist" => 8,
        "ashen_frontier:crypt_warden" => 80,
        "ashen_frontier:cinder_sovereign" => 160,
        "ashen_frontier:ashbound" => 8,
        "minecraft:zombie" | "minecraft:skeleton" | "minecraft:creeper" | "minecraft:spider"
        | "minecraft:husk" | "minecraft:drowned" => 3,
        _ => 0,
    }
}
pub fn hash(x: i32, z: i32) -> u64 {
    let mut v = (x as i64 as u64)
        .wrapping_mul(0x9e3779b185ebca87)
        .wrapping_add((z as i64 as u64).wrapping_mul(0xc2b2ae3d27d4eb4f))
        .wrapping_add(0x165667b19e3779f9);
    v ^= v >> 30;
    v = v.wrapping_mul(0xbf58476d1ce4e5b9);
    v ^ (v >> 27)
}
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Piece {
    pub at: [i32; 3],
    pub block: &'static str,
}
/// All pieces stay inside a single chunk's 12x12 centre.
pub fn site(variant: u64) -> Vec<Piece> {
    let mut out = Vec::new();
    let mut put = |x, y, z, block| {
        out.push(Piece {
            at: [x, y, z],
            block,
        })
    };
    for x in 0..11 {
        for z in 0..11 {
            put(
                x,
                0,
                z,
                if x == 0 || z == 0 || x == 10 || z == 10 {
                    "ashen_frontier:ashen_bricks"
                } else {
                    "ashen_frontier:relic_tiles"
                },
            );
            for y in 1..=5 {
                put(
                    x,
                    y,
                    z,
                    if variant == 2 && (x == 0 || z == 0 || x == 10 || z == 10 || y == 4) {
                        "ashen_frontier:carved_ashen_stone"
                    } else {
                        "minecraft:air"
                    },
                );
            }
        }
    }
    if variant == 2 {
        for (x, z) in [(3, 3), (7, 3), (3, 7), (7, 7)] {
            for y in 1..=3 {
                put(x, y, z, "ashen_frontier:roman_column");
            }
        }
        for z in 4..=6 {
            put(2, 1, z, "minecraft:smooth_quartz");
            put(8, 1, z, "minecraft:smooth_quartz");
        }
        put(2, 1, 2, "ashen_frontier:crypt_cache");
        put(8, 1, 8, "ashen_frontier:crypt_cache");
        put(5, 3, 5, "ashen_frontier:ember_lamp");
    } else {
        for (x, z) in [
            (1, 1),
            (1, 4),
            (1, 7),
            (1, 9),
            (9, 1),
            (9, 4),
            (9, 7),
            (9, 9),
        ] {
            for y in 1..=4 {
                put(x, y, z, "ashen_frontier:roman_column");
            }
            put(x, 5, z, "ashen_frontier:carved_ashen_stone");
        }
        if variant == 0 {
            for x in [3, 7] {
                for y in 1..=3 {
                    put(x, y, 0, "ashen_frontier:roman_column");
                }
            }
            for x in 3..=7 {
                put(x, 4, 0, "ashen_frontier:carved_ashen_stone");
            }
            put(5, 1, 8, "ashen_frontier:display_pedestal");
            put(5, 2, 8, "minecraft:gold_block");
            put(2, 1, 1, "ashen_frontier:legion_standard");
            put(4, 1, 8, "ashen_frontier:stone_bench");
            put(6, 1, 8, "ashen_frontier:stone_bench");
        } else {
            for x in 0..11 {
                for z in 0..11 {
                    if x < 3 || x > 7 || z < 3 || z > 7 {
                        put(x, 5, z, "ashen_frontier:roman_terracotta");
                    }
                }
            }
            for (x, z) in [(4, 5), (6, 5), (5, 4), (5, 6)] {
                put(x, 1, z, "ashen_frontier:ashen_bricks");
            }
            put(5, 1, 5, "minecraft:water");
            put(3, 1, 7, "ashen_frontier:cinderwood_table");
            put(3, 1, 8, "ashen_frontier:cinderwood_chair");
            put(1, 1, 8, "ashen_frontier:relic_shelf");
        }
        put(8, 1, 8, "ashen_frontier:ruin_cache");
        put(8, 1, 1, "ashen_frontier:ember_lamp");
    }
    out
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn imperial_rank_names() {
        assert_eq!(rank_name(0), "Tiro");
        assert_eq!(rank_name(700), "Legatus");
    }
    #[test]
    fn progression_boundaries() {
        assert_eq!(
            [0, 39, 40, 139, 140, 349, 350, 699, 700, u32::MAX].map(level),
            [1, 1, 2, 2, 3, 3, 4, 4, 5, 5]
        );
    }
    #[test]
    fn passive_farming_gives_no_xp() {
        assert_eq!(reward("minecraft:cow"), 0);
        assert_eq!(reward("ashen_frontier:crypt_warden"), 80);
    }
    #[test]
    fn structures_fit_and_have_treasure() {
        for v in 0..3 {
            let p = site(v);
            assert!(p.iter().all(|p| (0..=10).contains(&p.at[0])
                && (0..=10).contains(&p.at[2])
                && (0..=5).contains(&p.at[1])));
            assert!(p.iter().any(|p| p.block.ends_with("cache")));
            assert_eq!(p, site(v));
        }
    }
    #[test]
    fn hash_handles_negative_and_large_chunks() {
        assert_ne!(hash(-1, 1), hash(1, -1));
        assert_eq!(hash(i32::MIN, i32::MAX), hash(i32::MIN, i32::MAX));
    }
}
