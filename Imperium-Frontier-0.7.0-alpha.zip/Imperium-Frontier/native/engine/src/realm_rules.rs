#[derive(Clone, Copy, Debug)]
pub struct Realm {
    pub key: &'static str,
    pub title: &'static str,
    pub dimension: &'static str,
    pub center: [i32; 3],
    pub boss: &'static str,
    pub ore: &'static str,
    pub sigil: &'static str,
}
pub const REALMS: [Realm; 4] = [
    Realm {
        key: "vulcan",
        title: "Vulcan's Crucible",
        dimension: "minecraft:the_nether",
        center: [131072, 80, 131072],
        boss: "ashen_frontier:forge_tyrant",
        ore: "ashen_frontier:cindersteel_ore",
        sigil: "ashen_frontier:vulcan_sigil",
    },
    Realm {
        key: "dis",
        title: "Necropolis of Dis",
        dimension: "minecraft:the_nether",
        center: [196608, 80, 196608],
        boss: "ashen_frontier:styx_judge",
        ore: "ashen_frontier:stygian_ore",
        sigil: "ashen_frontier:dis_sigil",
    },
    Realm {
        key: "astra",
        title: "Capitol of Astra",
        dimension: "minecraft:the_end",
        center: [131072, 96, 131072],
        boss: "ashen_frontier:astral_legate",
        ore: "ashen_frontier:aetherium_ore",
        sigil: "ashen_frontier:astra_sigil",
    },
    Realm {
        key: "elysium",
        title: "Gardens of Elysium",
        dimension: "minecraft:overworld",
        center: [196608, 192, 196608],
        boss: "ashen_frontier:sol_avatar",
        ore: "ashen_frontier:elysian_ore",
        sigil: "ashen_frontier:elysium_sigil",
    },
];
pub fn inside(r: &Realm, dim: &str, p: [f64; 3]) -> bool {
    dim == r.dimension
        && (p[0] - r.center[0] as f64).abs() <= 26.
        && (p[2] - r.center[2] as f64).abs() <= 26.
        && (p[1] - r.center[1] as f64).abs() < 24.
}
pub fn can_enter(index: usize, stage: u8, emperor: bool) -> bool {
    index < REALMS.len() && emperor && index <= stage as usize
}
pub fn advance(stage: u8, boss: &str) -> u8 {
    if REALMS.get(stage as usize).is_some_and(|r| r.boss == boss) {
        stage + 1
    } else {
        stage
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn cannot_skip_realms() {
        assert!(!can_enter(2, 0, true));
        assert!(can_enter(0, 0, true));
        assert!(!can_enter(0, 0, false));
    }
    #[test]
    fn only_expected_boss_advances() {
        assert_eq!(advance(0, REALMS[1].boss), 0);
        assert_eq!(advance(0, REALMS[0].boss), 1);
        assert_eq!(advance(4, REALMS[3].boss), 4);
    }
    #[test]
    fn conquered_realms_remain_accessible() {
        assert!(can_enter(0, 3, true));
        assert!(!can_enter(4, 4, true));
    }
    #[test]
    fn region_check_uses_dimension_and_height() {
        let r = &REALMS[0];
        let p = r.center.map(|v| v as f64);
        assert!(inside(r, r.dimension, p));
        assert!(!inside(r, "minecraft:overworld", p));
        assert!(!inside(r, r.dimension, [p[0] + 100., p[1], p[2]]));
    }
    #[test]
    fn realms_never_overlap() {
        for (i, a) in REALMS.iter().enumerate() {
            for b in &REALMS[i + 1..] {
                assert!(!inside(a, b.dimension, b.center.map(|v| v as f64)));
            }
        }
    }
}
