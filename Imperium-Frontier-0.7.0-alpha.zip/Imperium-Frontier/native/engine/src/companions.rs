use super::companion_rules::{PETS, identity};
use super::*;
pub(super) fn pet(kind: &str) -> bool {
    kind.strip_prefix(PREFIX)
        .is_some_and(|k| PETS.iter().any(|p| p.0 == k))
}
impl Frontier {
    pub(super) fn pet_command(
        &self,
        host: &mut dyn Host,
        p: &NativeServerPlayer,
        args: &[&str],
    ) -> bool {
        match args.get(1).copied() {
            Some("pets") => {
                tell(
                    host,
                    "Roman companions: /frontier pet adopt <id>. One bonded pet per adventurer. Right-click to follow/wait; /frontier pet release frees the bond.",
                );
                for (id, title, stage, cost) in PETS {
                    tell(
                        host,
                        format!("{id}: {title}, {cost} denarii, Odyssey chapter {stage}."),
                    );
                }
                true
            }
            Some("pet") => {
                match args.get(2).copied() {
                    Some("release") => {
                        self.world(host, |w| {
                            w.pet_bonds.remove(&p.uuid);
                        });
                        self.persist(host);
                        tell(
                            host,
                            "Companion released. Its entity departs when next loaded.",
                        );
                    }
                    Some("adopt") => {
                        let Some(&(id, title, stage, cost)) =
                            args.get(3).and_then(|id| PETS.iter().find(|r| r.0 == *id))
                        else {
                            tell(host, "See /frontier pets for companion IDs.");
                            return true;
                        };
                        if p.game_mode != 0 {
                            tell(host, "Adoption currently requires Survival mode.");
                            return true;
                        }
                        let eligible = self
                            .world(host, |w| {
                                companion_rules::can_adopt(
                                    *w.campaign.entry(p.uuid).or_default(),
                                    stage,
                                    w.quests
                                        .get(&p.uuid)
                                        .is_some_and(|j| j.completed.contains("enlist")),
                                    w.pet_bonds.contains_key(&p.uuid),
                                )
                            })
                            .unwrap_or(false);
                        if !eligible {
                            tell(
                                host,
                                "Complete enlist and the required Odyssey chapter; release any existing bond first.",
                            );
                            return true;
                        }
                        if host.count_items("ashen_frontier:denarius") < cost {
                            tell(host, "Not enough denarii for this companion.");
                            return true;
                        }
                        let at = [p.position[0] + 2., p.position[1], p.position[2]];
                        let b = at.map(|v| v.floor() as i32);
                        if host.block(b) != "minecraft:air"
                            || host.block([b[0], b[1] + 1, b[2]]) != "minecraft:air"
                            || matches!(
                                host.block([b[0], b[1] - 1, b[2]]).as_str(),
                                "minecraft:air" | "minecraft:lava" | "minecraft:water"
                            )
                        {
                            tell(
                                host,
                                "Adoption needs clear solid ground two blocks to your side.",
                            );
                            return true;
                        }
                        let token = format!(
                            "{}-{}-{}",
                            p.uuid,
                            now(host),
                            std::time::SystemTime::now()
                                .duration_since(std::time::UNIX_EPOCH)
                                .unwrap_or_default()
                                .as_nanos()
                        );
                        let mut n = Compound::new();
                        if id == "jupiter_eagle" {
                            n.insert("NoGravity".into(), Tag::Byte(1));
                        }
                        n.insert(
                            "Tags".into(),
                            Tag::List(vec![
                                Tag::String(companion_rules::owner_tag(p.uuid).as_str().into()),
                                Tag::String(companion_rules::bond_tag(&token).as_str().into()),
                            ]),
                        );
                        n.insert("PersistenceRequired".into(), Tag::Byte(1));
                        n.insert("CustomName".into(), Tag::String(title.into()));
                        n.insert("CustomNameVisible".into(), Tag::Byte(1));
                        if host
                            .summon(&p.dimension, &format!("{PREFIX}{id}"), at, n)
                            .is_some()
                        {
                            host.take_items("ashen_frontier:denarius", cost);
                            self.world(host, |w| {
                                w.pet_bonds.insert(p.uuid, token);
                            });
                            self.persist(host);
                            tell(host, format!("{title} joins your expedition."));
                        }
                    }
                    _ => tell(
                        host,
                        "Use /frontier pet adopt <id> or /frontier pet release.",
                    ),
                }
                true
            }
            _ => false,
        }
    }
    pub(super) fn pet_interact(&self, host: &mut dyn Host, id: u32, kind: &str) -> bool {
        if !pet(kind) {
            return false;
        }
        let Some(p) = host.acting_player() else {
            return true;
        };
        let Some(e) = host.entity(id) else {
            return true;
        };
        let tags = host.entity_tags(e).unwrap_or_default();
        if identity(&tags).map(|p| p.0) != Some(p.uuid) {
            tell(host, "This companion is bonded to another adventurer.");
            return true;
        }
        let sit = !tags.iter().any(|s| s == "imperium.waiting");
        if sit {
            host.entity_add_tag(e, "imperium.waiting");
        } else {
            host.entity_remove_tag(e, "imperium.waiting");
        }
        tell(
            host,
            if sit {
                "Companion will wait here."
            } else {
                "Companion will follow."
            },
        );
        true
    }
    pub(super) fn pet_tick(&self, host: &mut dyn Host, e: &EntityTickPostEvent<'_>) -> bool {
        if !pet(e.kind) {
            return false;
        }
        let t = now(host);
        if t % 5 != 0 {
            return true;
        }
        let Some(entity) = host.entity(e.entity) else {
            return true;
        };
        let tags = host.entity_tags(entity).unwrap_or_default();
        let Some((owner, token)) = identity(&tags) else {
            return true;
        };
        let valid = self
            .world(host, |w| {
                companion_rules::valid_bond(w.pet_bonds.get(&owner).map(String::as_str), token)
            })
            .unwrap_or(false);
        if !valid {
            if let Some(id) = host.entity_uuid(entity) {
                host.run_command(&format!("execute in {} run kill {}", e.dimension, uuid(id)));
            }
            return true;
        }
        let Some(p) = host
            .server_players()
            .into_iter()
            .find(|p| p.uuid == owner && p.dimension == e.dimension && p.health > 0.)
        else {
            return true;
        };
        let Some(at) = host.entity_position(entity) else {
            return true;
        };
        let dx = p.position[0] - at[0];
        let dz = p.position[2] - at[2];
        let distance = dx.hypot(dz);
        let waiting = tags.iter().any(|s| s == "imperium.waiting");
        self.world(host, |w| {
            w.pet_entities
                .insert(owner, (e.entity, e.dimension.to_owned(), waiting));
        });
        let mut v = host.entity_velocity(entity).unwrap_or([0.; 3]);
        v[0] = 0.;
        v[2] = 0.;
        if !waiting && distance > 3. {
            if distance > 20. {
                let dest = [p.position[0] + 2., p.position[1], p.position[2]];
                let b = dest.map(|v| v.floor() as i32);
                if host.block(b) == "minecraft:air"
                    && host.block([b[0], b[1] + 1, b[2]]) == "minecraft:air"
                    && !matches!(
                        host.block([b[0], b[1] - 1, b[2]]).as_str(),
                        "minecraft:air" | "minecraft:lava" | "minecraft:water"
                    )
                {
                    host.teleport_mob(e.dimension, e.entity, dest);
                }
            } else {
                v[0] = dx / distance * 0.14;
                v[2] = dz / distance * 0.14;
            }
        }
        if e.kind.ends_with("jupiter_eagle") {
            v[1] = if waiting {
                0.
            } else {
                ((p.position[1] + 1.5 - at[1]) * 0.1).clamp(-0.15, 0.15)
            };
        }
        host.entity_set_velocity(entity, v);
        if distance < 8. && t % 600 == 0 {
            let (effect, seconds) = if e.kind.ends_with("lupa_hound") {
                ("strength", 6)
            } else if e.kind.ends_with("mars_boar") {
                ("resistance", 6)
            } else if e.kind.ends_with("diana_lynx") {
                ("speed", 8)
            } else {
                ("night_vision", 40)
            };
            host.run_command(&format!(
                "effect give {} minecraft:{effect} {seconds} 0 true",
                uuid(owner)
            ));
        }
        true
    }
    pub(super) fn pet_died(&self, host: &mut dyn Host, id: u32, kind: &str) {
        if !pet(kind) {
            return;
        }
        if let Some(tags) = host.entity(id).and_then(|e| host.entity_tags(e)) {
            if let Some((owner, token)) = identity(&tags) {
                self.world(host, |w| {
                    if w.pet_bonds.get(&owner).is_some_and(|b| b == token) {
                        w.pet_bonds.remove(&owner);
                        w.pet_entities.remove(&owner);
                    }
                });
                self.persist(host);
            }
        }
    }
    pub(super) fn following_pet(&self, host: &mut dyn Host, owner: u128) -> Option<(u128, String)> {
        let saved = self
            .world(host, |w| w.pet_entities.get(&owner).cloned())
            .flatten()?;
        if saved.2 {
            return None;
        }
        let entity = host.entity(saved.0)?;
        host.entity_uuid(entity).map(|id| (id, saved.1))
    }
}
