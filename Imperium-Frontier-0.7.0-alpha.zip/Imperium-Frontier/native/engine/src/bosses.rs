use super::*;
impl Frontier {
    pub(super) fn boss_tick(&self, host: &mut dyn Host, e: &EntityTickPostEvent<'_>) -> bool {
        let Some(def) = boss_rules::boss(e.kind) else {
            return false;
        };
        let t = now(host);
        if t % 2 != 0 {
            return true;
        }
        let Some(entity) = host.entity(e.entity) else {
            return true;
        };
        let Some(pos) = host.entity_position(entity) else {
            return true;
        };
        let health = host
            .entity_nbt(entity)
            .and_then(|n| match n.get(&"Health".into()) {
                Some(Tag::Float(v)) => Some(f32::from_bits(*v)),
                _ => None,
            })
            .unwrap_or(def.health);
        if health <= 0. {
            return true;
        }
        let players: Vec<_> = host
            .server_players()
            .into_iter()
            .filter(|p| {
                p.dimension == e.dimension
                    && matches!(p.game_mode, 0 | 2)
                    && p.health > 0.
                    && distance(p.position, pos) < 32. * 32.
            })
            .collect();
        let target = players
            .iter()
            .min_by(|a, b| distance(a.position, pos).total_cmp(&distance(b.position, pos)));
        let state = self.world(host, |w| {
            let f = w
                .bosses
                .entry(e.entity)
                .or_insert_with(|| boss_rules::Fight::new(t));
            let event = f.step(def, t, pos, target.map(|p| p.position), health);
            (event, f.clone())
        });
        let Some((event, f)) = state else {
            return true;
        };
        let mut velocity = host.entity_velocity(entity).unwrap_or([0.; 3]);
        velocity[0] = 0.;
        velocity[2] = 0.;
        if f.phase == boss_rules::Phase::Approach {
            if let Some(p) = target {
                let dx = p.position[0] - pos[0];
                let dz = p.position[2] - pos[2];
                let len = dx.hypot(dz);
                if len > 3. {
                    velocity[0] = dx / len * 0.18;
                    velocity[2] = dz / len * 0.18;
                }
            }
        }
        host.entity_set_velocity(entity, velocity);
        if event == boss_rules::Event::Warn {
            for p in &players {
                host.tell(
                    p.uuid,
                    Text::literal(format!(
                        "{}: {} ({:.1}s)",
                        def.title,
                        f.label(),
                        (f.until - t) as f32 / 20.
                    )),
                );
            }
        }
        if f.phase == boss_rules::Phase::Windup && t % 10 == 0 {
            let at = if f.pattern == boss_rules::Pattern::Brand {
                f.mark
            } else {
                f.origin
            };
            let radius = if f.pattern == boss_rules::Pattern::Brand {
                2.5
            } else if f.pattern == boss_rules::Pattern::Slam {
                3.5
            } else {
                4.5
            };
            for i in 0..12 {
                let angle = i as f64 * std::f64::consts::TAU / 12.;
                let point = [
                    at[0] + angle.sin() * radius,
                    at[1] + 0.15,
                    at[2] + angle.cos() * radius,
                ];
                if f.pattern != boss_rules::Pattern::Cleave || f.hits(point) {
                    host.run_command(&format!(
                        "execute in {} run particle minecraft:flame {} {} {} 0 0 0 0 1 force",
                        e.dimension, point[0], point[1], point[2]
                    ));
                }
            }
        }
        if event == boss_rules::Event::Strike {
            let Some(boss_uuid) = host.entity_uuid(entity) else {
                return true;
            };
            for p in &players {
                if f.hits(p.position) {
                    host.run_command(&format!(
                        "execute in {} run damage {} {} minecraft:mob_attack by {}",
                        e.dimension,
                        uuid(p.uuid),
                        def.damage,
                        uuid(boss_uuid)
                    ));
                }
            }
            for p in &players {
                host.action_bar(
                    p.uuid,
                    Text::literal(format!("{} recovering — attack now!", def.title)),
                );
            }
        }
        if t % 10 == 0 {
            for p in &players {
                host.action_bar(
                    p.uuid,
                    Text::literal(format!(
                        "{} {:.0}/{:.0} HP | {}",
                        def.title,
                        health,
                        def.health,
                        match f.phase {
                            boss_rules::Phase::Approach => "approaching",
                            boss_rules::Phase::Windup => f.label(),
                            boss_rules::Phase::Recovery => "RECOVERY — punish",
                        }
                    )),
                );
            }
        }
        true
    }
}
fn distance(a: [f64; 3], b: [f64; 3]) -> f64 {
    a.into_iter().zip(b).map(|(a, b)| (a - b).powi(2)).sum()
}
